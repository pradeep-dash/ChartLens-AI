# ChartLens AI — Phases 1, 2, 3, 4, 5

Analysis/decision-support only. This app never places trades, clicks buttons, or
interacts with any trading platform — it only reads the screen and displays
information.

This milestone covers **Phases 1-5 of 9**. Not yet present: the AI reasoning
layer (Phase 6) — the overlay and dashboard show a real directional
prediction now (Phase 5), but nothing has been sent to or interpreted by
an LLM.

---

## 0. Phase 5 — Prediction Engine (NEW)

- `PredictionEngine`: combines every evidence source Phases 2-4 now produce —
  trend, momentum, EMA alignment, RSI, MACD, support/resistance,
  candle patterns, recent candle sequence — into a weighted directional
  score. Never a single "will the next candle be green or red" ask to an LLM,
  per the spec's explicit requirement; each evidence source is its own pure
  function returning a score in [-1, 1] plus whether it had enough data to
  say anything at all.
- **NO_TRADE is a first-class, actively-sought output, not a fallback.**
  Every condition the spec lists — insufficient data/candles, conflicting
  evidence, low confidence, an unknown timeframe, a doji/chop candle, price
  sitting at an unbroken support/resistance level, elevated volatility (via
  Bollinger Band width) — is an independent hard gate. Any single one firing
  forces NO_TRADE regardless of how strong the other evidence looks; this was
  a deliberate redesign after an early draft only let some of these
  conditions softly reduce confidence rather than actively block a
  prediction, which undersold the spec's explicit "this is one of the most
  important design requirements" language.
- `PredictionResult.modelConfidence` is displayed as "Model Confidence:
  NN/100" everywhere in the UI — never as a percentage chance — per the
  spec's explicit requirement that a raw heuristic score must not be
  presented as a calibrated probability until real historical calibration
  exists (Phase 7, not built yet).
- Wired into `FrameAnalyzer`: every analyzed frame now produces a real
  prediction (or a NO_TRADE with reasons) from the last closed candle's real
  technical-analysis context. Both the overlay and dashboard show it — this
  is the first phase where the app displays an actual directional read.

**Not yet done**: weights and thresholds are reasonable starting points, not
calibrated values — Phase 7's prediction journal (recording real outcomes) is
what real calibration needs, and doesn't exist yet. This has also never run
against a real device — every test uses synthetic `TechnicalAnalysisResult`
fixtures, hand-verified by arithmetic, not real chart data.

---

## 1. What was implemented

### Phase 1 — Foundation (capture, overlay, permissions)
Full MediaProjection capture pipeline, foreground service, floating overlay,
permission orchestration. See git history / earlier notes for full detail —
unchanged since first shipped.

### Phase 2 — Vision (chart/candle detection)
Automatic chart-region detection, candle geometry detection (column clustering
+ row-coverage body/wick separation), candle pattern scoring, manual
chart-selection fallback. Pure Kotlin/Android pixel processing, not OpenCV (see
architecture note below). Verified working on two real charts (AUD/NZD and
USD/PHP OTC pairs on QX Broker) after two real bugs were found and fixed via
device testing — see git history for detail.

### Phase 3 — OCR, Price Mapping, Timeframe & Candle-Close Detection (NEW)
- `ocr/OcrEngine`: wraps ML Kit's on-device text recognizer (line-level
  granularity, fully on-device — no data leaves the device)
- `ocr/PriceTextParser`, `ocr/TimeTextParser`: pure-Kotlin, noise-tolerant
  parsing of OCR'd price and time-axis text — return `null` rather than a
  guessed value when text doesn't look like a real number/time
- `analysis/PriceScaleMapper`: fits a linear pixelY→price mapping via
  least-squares regression over OCR'd price-axis labels — not a fixed price
  increment, not just the first 2 labels found. A confidence score is derived
  from fit quality (R²) and sample count; a 2-point fit is deliberately capped
  at low confidence since any 2 points trivially fit a line perfectly
  regardless of whether the readings are actually correct
- `analysis/TimeframeDetector`: combines time-axis OCR (minutes-per-pixel) with
  Phase 2's candle pixel spacing to estimate minutes-per-candle, then snaps to
  a known interval (1/5/15/30/60m) only within tolerance — otherwise reports
  "Unknown" rather than guessing, per spec §8
- `analysis/CandleCloseTracker`: stateful, detects the forming→closed
  transition across consecutive frames by position-matching (not OCR-based —
  pure pixel geometry)
- **`FrameAnalyzer` fully rewired**: this is the first point where Phase 2's
  pixel geometry, Phase 3's price mapping, and Phase 4's technical analysis
  engine all connect end-to-end. When OCR successfully maps the price axis,
  closed candles are converted to real `PriceCandle`s and fed into
  `TechnicalAnalysisEngine` — genuinely computed indicator values, not
  synthetic test data, for the first time in this project.

**Why price-axis OCR runs on a much longer cache interval than chart-region
detection:** text recognition is meaningfully more expensive than the pixel
geometry work, and the visible price/time range changes far less often than
individual candles do. A stale price mapping (fitted from an old OCR pass) is
kept rather than blanked out if a later OCR pass finds nothing usable — a
single bad OCR pass on an otherwise-stable price axis shouldn't discard a good
mapping from moments ago.

**A real gap was found and fixed during this phase's own review** (not
device testing this time): `FrameAnalyzer.invalidateCache()` existed but was
never actually called when the user changes the manual chart-region selection
mid-session — meaning a price mapping fitted from the *old* region's price-axis
crop could linger for up to `ocrEveryNFrames` frames after a manual selection
change, silently producing prices computed from the wrong crop location.
Fixed by having `ScreenCaptureService` detect when the loaded manual region
changes between frames and invalidate the cache at that point.

**A second real bug was found on first real-device test of Phase 3's OCR**:
the price-axis crop was anchored to `region.right` (the rightmost detected
candle column) plus a fixed 130px width. Real charts often reserve blank chart
space between the last candle and the actual price axis (room for future
candles) — that gap varies per chart and per moment, and on the device test
chart it was wide enough that the crop landed entirely in blank space,
finding zero price text every single OCR pass despite candle detection
working perfectly (44/45 candles, 99% region confidence). Diagnosed via a
debug feature added specifically for this (`OcrDebugInfo`, surfacing raw OCR
text on the dashboard) rather than guessing — the debug output showed the
time-axis strip *did* find text (confirming ML Kit itself worked) while the
price-axis strip consistently found nothing, pointing straight at the crop
region rather than OCR itself. Fixed by anchoring the price-axis strip to the
bitmap's actual right edge instead of the detected chart region's edge, and
widening both axis-strip margins for safety margin.

**A third fix, made without confirmed root-cause data**: a later device test
showed `PriceScaleMapper` producing only 7% confidence from 9 successfully-OCR'd
labels — meaningfully worse than expected. The raw OCR text needed to pin down
the exact cause wasn't available, so rather than guess at a specific string fix,
`PriceScaleMapper` was rebuilt with two general-purpose robustness passes: (1)
X-position clustering, which discards any parsed number sitting at a different
horizontal position than the main cluster of axis labels — this specifically
targets floating price tooltips near the chart crosshair, visible in the device
screenshots, which sit at a different X than the actual right-aligned axis
labels but could still parse as a valid-looking price; (2) iterative outlier
removal using median (not mean) absolute residual as the baseline, since a
single outlier inflates the mean of the very residuals it's part of, diluting
the signal being measured for. Worth being direct about this: **this is a
principled improvement based on the most likely explanations, not a confirmed
fix** — the actual root cause on that specific device run is still unknown.
The next real-device test with the diagnostic `OcrDebugInfo` output (already
in place) will confirm whether this resolved it or whether the raw text points
to something else entirely.

**A fourth fix, from a genuinely different device/layout**: a later test on a
wider/landscape layout (with a persistent trade-panel sidebar occupying the
actual right edge of the screen) showed the price-axis crop reading sidebar
text ("Withdrawal", trade amounts) instead of the chart's own price labels —
because that crop was anchored to the screen's right edge (the previous fix,
which worked for a portrait mobile layout where the price axis WAS at the
screen edge). Neither a fixed offset from the candle region nor a fixed offset
from the screen edge holds up across layouts. Fixed by cropping generously —
from the candle region's right edge all the way to the screen's right edge,
with no fixed width — and relying on `PriceScaleMapper`'s X-position
clustering (already built for the previous fix) to find the real vertically-
aligned axis among whatever else gets swept into that wider net, rather than
trying to guess the right pixel width for yet another layout.

**A more serious gap, also found on that same test**: with the mapping fitted
from just 2 low-quality labels (capped at 50% confidence by design), the
pipeline still went ahead and computed technical indicators from it — and
displayed EMA values in the thousands on a chart where the real price was
around 0.69. Mathematically consistent with the bad mapping, obviously wrong
in reality, and nothing was stopping it from being computed and shown as if it
meant something. This is exactly the kind of falsely-precise output the
project's "never fabricate" principle exists to prevent, and the gate simply
didn't exist. Fixed: `FrameAnalyzer` now only converts to `PriceCandle`s and
runs `TechnicalAnalysisEngine` when the price mapping's confidence clears a
minimum threshold (0.6 by default) — below that, `priceCandles` stays empty
and `technicalAnalysis` stays null, same as if no mapping existed at all. The
UI now also explicitly distinguishes "no mapping yet" from "mapping exists but
is too weak to trust" rather than letting the two look similar.

### Phase 4 — Technical Analysis Engine
`EMA`/`RSI`/`MACD`/`ATR`/`BollingerBands`, `TrendAnalyzer` (swing-structure
based), `MomentumAnalyzer`, `SupportResistanceAnalyzer` (breakout/rejection
detection), `TechnicalAnalysisEngine`. Fully pure Kotlin, fully unit tested
against hand-calculated values where the math allows it. Built in the previous
milestone against a generic `PriceCandle` model — Phase 3 is what finally
legitimately wires it to live pixel data, once real (OCR'd) prices exist to
feed it, instead of leaving that wiring as a deferred TODO.

## 2. Architecture decisions worth knowing about

**Confirmed working on a real device, after four rounds of fixes.** A device
test produced the first fully trustworthy end-to-end result: 99%
price-mapping confidence from 6 OCR'd labels, correctly-scaled `EMA9`/`EMA21`
values matching the chart's actual visible price range (a direct contrast to
an earlier test that had shown EMA values in the thousands on a sub-1.0 price
chart — see the fourth fix below), a detected timeframe (5m) instead of
"Unknown", and a sane RSI value. This is the first point in the project where
Phase 2's pixel geometry, Phase 3's OCR, and Phase 4's technical analysis
engine have been confirmed working together against a real chart, not just
against each other's synthetic test data. Not yet cross-checked: whether the
detected 5m timeframe actually matches the platform's displayed setting.


**Phase 2 uses pure Kotlin, not OpenCV** (unchanged from the prior milestone):
getting Phase 1's CI build green took three real failures to resolve; adding
OpenCV means configuring its Maven repo or vendoring its SDK, a realistic
source of a similar build-failure loop for capability not needed at this
scale. The modular design means swapping in OpenCV later doesn't require
touching the surrounding pipeline.

**Price-axis and time-axis crop regions assume a specific layout convention**:
price labels along the right edge of the chart, time labels along the bottom
— the convention every trading app tested against so far actually uses. A
platform with price labels on the left would need this adjusted; it's a
constructor parameter on `FrameAnalyzer`, not something requiring a redesign,
but it isn't auto-detected.

**Real candle timestamps are still not computed.** `PriceCandle.timestampMillis`
stays `null` even after Phase 3 — deriving a real timestamp needs a reference
wall-clock time anchored to a specific candle, which OCR alone doesn't
reliably provide (a visible time-axis label doesn't necessarily align with the
current candle's actual close time). Left as `null` rather than a guessed
value; worth revisiting once Phase 5's prediction journal needs real
timestamps.

## 3. Project structure

```
app/src/main/java/com/chartlens/ai/
  common/            ColorMath, PixelBuffer, CaptureState(+Repository), LatestFrameHolder
  capture/           CapturedFrame, FrameChangeDetector, ScreenCaptureController
  service/           ScreenCaptureService
  overlay/           OverlayService, OverlayLifecycleOwner
  ui/                MainActivity, MainViewModel, DashboardScreen, ChartRegionSelectionScreen
  cv/                CandleColorProfile, ChartRegion, ChartDetector, FrameAnalyzer
  candle/            Candle, CandleDetector, CandlePattern(+Detector)
  settings/          NormalizedRect, ManualChartRegionStore
  ocr/               OcrTextBlock, OcrEngine, PriceTextParser, TimeTextParser
  indicators/        EMA, RSI, MACD, ATR, BollingerBands
  analysis/          PriceCandle, DataQuality, AnalysisFrame(+Repository),
                      PriceScaleMapper(+Mapping), TimeframeDetector, CandleCloseTracker,
                      TrendAnalyzer, MomentumAnalyzer, SupportResistanceAnalyzer,
                      TechnicalAnalysisEngine
  prediction/        PredictionEngine, PredictionModels, PredictionWeights, LastCandleContext
```

`ai/`, `data/`, `database/`, `replay/` remain unbuilt.

## 4. Configuring the build

- **Gradle wrapper**: pinned to Gradle 8.9 in `gradle/wrapper/`, jar not
  checked in — open in Android Studio or run `gradle wrapper --gradle-version
  8.9` once.
- **`gradle.properties`** must include `android.useAndroidX=true` (a real early
  build failure without it — see git history).
- **OpenCV**: still not a dependency, see architecture note above.
- **ML Kit text recognition** (`com.google.mlkit:text-recognition:16.0.1`) is
  active and used for the first time this phase — its transitive
  `androidx.exifinterface` dependency was the original trigger for the
  AndroidX/Jetifier build failure that `gradle.properties` now fixes.
- **KSP/Kotlin pairing**: `2.0.20-1.0.24` — verify against
  https://github.com/google/ksp/releases if bumping Kotlin.

## 5. How to build / install

```
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 6. Permissions required

Unchanged from Phase 1: `SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE` +
`FOREGROUND_SERVICE_MEDIA_PROJECTION`, `POST_NOTIFICATIONS`,
`INTERNET`/`ACCESS_NETWORK_STATE` (still reserved for Phase 6, unused). ML Kit
text recognition runs fully on-device — no new network permission needed for
it specifically.

## 7. Known limitations

- **The "zero price labels found" mystery from the previous round is now
  resolved, confirmed by the diagnostics added specifically to catch it —
  and the fix for it revealed a second, sneakier bug.** The `OcrDebugInfo`
  crop-size/error reporting immediately identified the exact cause: the
  price-axis crop had come out only 22 pixels wide (`region.right` landed
  just 22px from the bitmap's right edge on that chart state), and ML Kit
  hard-rejects any input under 32×32 with `MlKitException`, thrown on every
  OCR attempt. Fixed with a minimum-width floor. The first version of that
  floor (60px) stopped the crash but was still too narrow to capture full
  label text — a second device test showed "92.700" truncated down to just
  "700", and because the truncated fragments happened to still be evenly
  spaced relative to each other, `PriceScaleMapper` fit a clean, 87%-confidence
  line through completely wrong values. A confidently-wrong mapping is worse
  than an obviously-failed one. Fixed two ways: the floor is now 200px (wide
  enough for full multi-digit labels), and — as a durable, crop-geometry-
  independent safeguard — `PriceTextParser` now requires a decimal point to
  accept a value at all, since every real price label on these platforms has
  one and a bare truncated integer never should be treated as legitimate.
- **Chart layout varies more than expected across devices/orientations, and
  this has bitten OCR crop positioning twice already** — once on a portrait
  mobile layout (blank chart space before the price axis), once on a wide
  landscape layout (a sidebar occupying the screen edge). The current crop
  strategy (crop generously, let parsing/clustering filter noise) is more
  robust than either previous fixed-pixel guess, but "robust across every
  layout" hasn't been proven — only two real layouts have been tested.
- **Phase 3's unit tests still use only synthetic data** — the underlying
  math (`PriceScaleMapper`'s regression/clustering, `TimeframeDetector`) is
  unit tested against synthetic `OcrTextBlock`s, not literally re-verified
  against real ML Kit output in the test suite. The pipeline as a whole has
  now been confirmed working end-to-end on a real device (see section 2), but
  that's one confirmed run on one platform/instrument — not the same as broad
  verification across charts, themes, or instruments.
- **Price-axis/time-axis crop position is a fixed layout assumption** (right
  edge / bottom), not detected. A platform with a different layout won't be
  read correctly.
- **No timestamp on `PriceCandle`** — see architecture note above.
- **Midnight wraparound isn't handled** in `TimeframeDetector`'s time-label
  regression (documented in `TimeTextParser`'s doc comment).
- **US-thousands vs. European-decimal-comma ambiguity** in `PriceTextParser` —
  "61,400" is read as 61400, not 61.4, per the documented (and tested)
  heuristic. Could misparse a European-format platform.
- **OCR cache interval (30 analyzed frames) is an unverified guess**, same
  caveat as chart-region's 20-frame interval from Phase 2 — not tuned against
  real device timing.
- Everything else carried over from Phase 2's limitations list (manual
  selection is global not per-app, no accessibility-service app detection,
  etc.) still applies.

## 8. Tests performed

**Phases 1-2:** unchanged — `FrameChangeDetectorTest` (6), `CandleDetectorTest`
(6), `ChartDetectorTest` (4), `CandlePatternDetectorTest` (7).

**Phase 4:** unchanged — `EMATest` (4), `RSITest` (4), `ATRTest` (3),
`BollingerBandsTest` (3), `MACDTest` (4), `TrendAnalyzerTest` (4),
`MomentumAnalyzerTest` (5), `SupportResistanceAnalyzerTest` (4),
`TechnicalAnalysisEngineTest` (3).

**Phase 3 (new, all pure Kotlin):**
- `PriceTextParserTest` (7): simple decimals, whitespace trimming, US
  thousands-separator parsing, a documented ambiguity case locked in as a
  regression guard, unparseable text → null
- `TimeTextParserTest` (5): standard and single-digit-hour parsing,
  out-of-range hour/minute rejection, non-time text → null
- `PriceScaleMapperTest` (6): insufficient labels → null, exact 3-point linear
  fit with hand-calculated interpolated price, 2-point fit capped at lower
  confidence, an inconsistent label visibly lowering fit quality, unparseable
  labels correctly filtered out, same-Y labels correctly rejected
- `TimeframeDetectorTest` (4): exact interval match from hand-calculated
  minutes-per-pixel × candle spacing, an unmatched estimate still surfaced
  (not silently dropped), insufficient time labels / insufficient candles both
  correctly yield no result
- `CandleCloseTrackerTest` (5): first-update baseline (no event), a genuine
  forming→closed transition correctly reported, no event when nothing closed,
  a position-jump correctly NOT reported as a close, `reset()` correctness
- `DataQualityCalculatorTest` (5): baseline behavior preserved, a weak price
  mapping downgrading GOOD→FAIR, a strong mapping leaving GOOD unchanged, a
  weak mapping never upgrading an already-poor result

**Phase 5 (new, all pure Kotlin):**
- `PredictionEngineTest` (11 cases): a "clean bullish" fixture with every
  arithmetic step hand-computed in the test file's own doc comment (not just
  asserted against whatever the code happens to produce), its exact mirror for
  bearish, `null`/insufficient-candle/no-applicable-evidence early exits, and
  one isolated test per NO_TRADE gate (doji, unknown timeframe, price-at-level,
  confirmed-breakout NOT falsely flagged as stuck-at-level, elevated
  volatility, conflicting evidence, low confidence) — each confirming that
  gate alone forces NO_TRADE regardless of how strong the underlying evidence
  score was

`OcrEngine` and the rest of `FrameAnalyzer`'s Bitmap/ML-Kit-touching code
remain reviewed-by-hand rather than unit tested — same boundary as Phase 1-2's
capture/CV code.

## 9. Remaining work (next phases)

- **Phase 6** — AI backend + `AiAnalysisProvider`, structured request/response,
  explanation of the strongest/conflicting evidence in natural language
- **Phase 7** — Room prediction journal, outcome evaluation, accuracy
  analytics — this is what would let Phase 5's weights/thresholds move from
  "reasonable defaults" to genuinely calibrated
- **Phase 8** — Replay/backtest mode, look-ahead-bias prevention tests
- **Phase 9** — Battery/performance tuning, accessibility, polish

**Recommended immediate next step:** get Phase 5 running on a real device.
Every prediction so far has been verified against hand-built synthetic
`TechnicalAnalysisResult` fixtures — the same position Phase 2 and Phase 3
were each in before real device testing surfaced real bugs. Given that
pattern held twice already, it would be a mistake to assume this phase is
different without checking.
