package com.chartlens.ai.prediction

import com.chartlens.ai.analysis.BreakoutStatus
import com.chartlens.ai.analysis.MomentumDirection
import com.chartlens.ai.analysis.MomentumResult
import com.chartlens.ai.analysis.RejectionStatus
import com.chartlens.ai.analysis.SupportResistanceResult
import com.chartlens.ai.analysis.TechnicalAnalysisResult
import com.chartlens.ai.analysis.Trend
import com.chartlens.ai.analysis.TrendResult
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.candle.CandlePattern
import com.chartlens.ai.indicators.BollingerPoint
import com.chartlens.ai.indicators.MacdPoint

/** A clean, unambiguous bullish scenario: every applicable evidence source leans bullish,
 * no gate conditions triggered. Hand-verified in PredictionEngineTest's doc comment. */
fun cleanBullishTechnicalAnalysis(): TechnicalAnalysisResult = TechnicalAnalysisResult(
    candleCount = 30,
    trend = TrendResult(Trend.UPTREND, trendStrength = 0.9f, swingHighs = emptyList(), swingLows = emptyList(), isConsolidating = false),
    momentum = MomentumResult(MomentumDirection.BULLISH, consecutiveSameDirectionCandles = 4, rateOfChangePercent = 0.5, isAccelerating = true),
    ema9 = 1.010,
    ema21 = 1.005,
    ema50 = 1.000,
    rsi14 = 60.0,
    macd = MacdPoint(macd = 0.002, signal = 0.001, histogram = 0.001),
    atr = 0.01,
    bollinger = BollingerPoint(middle = 1.005, upper = 1.015, lower = 0.995),
    supportResistance = SupportResistanceResult(
        supportLevels = emptyList(),
        resistanceLevels = emptyList(),
        nearestSupport = 0.98,
        nearestResistance = 1.05,
        breakoutStatus = BreakoutStatus.NONE,
        rejectionStatus = RejectionStatus.NONE
    )
)

fun cleanBullishLastCandle(): LastCandleContext = LastCandleContext(
    closePrice = 1.008,
    direction = CandleDirection.BULLISH,
    upperWickPx = 2,
    lowerWickPx = 8,
    patterns = setOf(CandlePattern.BULLISH_ENGULFING)
)

/** Exact mirror of the bullish fixture, every value sign-flipped around its neutral point. */
fun cleanBearishTechnicalAnalysis(): TechnicalAnalysisResult = TechnicalAnalysisResult(
    candleCount = 30,
    trend = TrendResult(Trend.DOWNTREND, trendStrength = 0.9f, swingHighs = emptyList(), swingLows = emptyList(), isConsolidating = false),
    momentum = MomentumResult(MomentumDirection.BEARISH, consecutiveSameDirectionCandles = 4, rateOfChangePercent = -0.5, isAccelerating = true),
    ema9 = 1.000,
    ema21 = 1.005,
    ema50 = 1.010,
    rsi14 = 40.0,
    macd = MacdPoint(macd = -0.002, signal = -0.001, histogram = -0.001),
    atr = 0.01,
    bollinger = BollingerPoint(middle = 1.005, upper = 1.015, lower = 0.995),
    supportResistance = SupportResistanceResult(
        supportLevels = emptyList(),
        resistanceLevels = emptyList(),
        nearestSupport = 0.95,
        nearestResistance = 1.02,
        breakoutStatus = BreakoutStatus.NONE,
        rejectionStatus = RejectionStatus.NONE
    )
)

fun cleanBearishLastCandle(): LastCandleContext = LastCandleContext(
    closePrice = 1.002,
    direction = CandleDirection.BEARISH,
    upperWickPx = 8,
    lowerWickPx = 2,
    patterns = setOf(CandlePattern.BEARISH_ENGULFING)
)
