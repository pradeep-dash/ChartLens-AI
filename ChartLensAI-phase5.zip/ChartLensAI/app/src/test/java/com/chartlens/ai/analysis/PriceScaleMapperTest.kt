package com.chartlens.ai.analysis

import com.chartlens.ai.ocr.OcrTextBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PriceScaleMapperTest {

    private val mapper = PriceScaleMapper()

    @Test
    fun `fewer than two valid labels produces no mapping`() {
        val labels = listOf(OcrTextBlock("Deposit", centerX = 0, centerY = 100))
        assertNull(mapper.fit(labels))
    }

    @Test
    fun `three perfectly linear labels fit exactly with high confidence`() {
        // price decreases by 0.1 for every 100px of Y, matching real screen behavior
        // (higher on screen = smaller Y = higher price).
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 0, centerY = 200),
            OcrTextBlock("61.300", centerX = 0, centerY = 300)
        )
        val mapping = mapper.fit(labels)!!

        assertEquals(1.0, mapping.rSquared, 1e-6)
        assertEquals(3, mapping.sampleCount)
        assertTrue("a clean 3-point fit should be highly confident", mapping.confidence > 0.9f)
        assertEquals(61.45, mapping.priceAt(150.0), 1e-6)
    }

    @Test
    fun `a two-point fit is always geometrically perfect but capped at lower confidence`() {
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.300", centerX = 0, centerY = 300)
        )
        val mapping = mapper.fit(labels)!!

        assertEquals(1.0, mapping.rSquared, 1e-6) // any 2 points fit a line perfectly
        assertTrue("a 2-point fit should never be treated as fully confident", mapping.confidence <= 0.5f)
    }

    @Test
    fun `a single misread label among otherwise-clean data is detected and removed`() {
        // Regression test motivated by a real device result: 9 OCR'd labels produced
        // only 7% confidence. A single badly-misread label among several good ones
        // should now be dropped rather than silently dragging the fit down.
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 0, centerY = 200),
            OcrTextBlock("59.000", centerX = 0, centerY = 300), // badly misread
            OcrTextBlock("61.200", centerX = 0, centerY = 400),
            OcrTextBlock("61.100", centerX = 0, centerY = 500)
        )
        val mapping = mapper.fit(labels)!!

        assertEquals("the outlier should have been dropped", 4, mapping.sampleCount)
        assertTrue("the fit should be clean after removing the bad label", mapping.rSquared > 0.95)
        assertTrue("confidence should be high with 4 clean points", mapping.confidence > 0.9f)
    }

    @Test
    fun `natural OCR noise without a real outlier is not over-pruned`() {
        // Small, consistent jitter (not a dramatic misread) shouldn't trigger removal —
        // outlier detection should only fire on a genuinely inconsistent point.
        val labels = listOf(
            OcrTextBlock("61.501", centerX = 0, centerY = 100),
            OcrTextBlock("61.399", centerX = 0, centerY = 200),
            OcrTextBlock("61.302", centerX = 0, centerY = 300),
            OcrTextBlock("61.198", centerX = 0, centerY = 400),
            OcrTextBlock("61.100", centerX = 0, centerY = 500)
        )
        val mapping = mapper.fit(labels)!!
        assertEquals(5, mapping.sampleCount)
    }

    @Test
    fun `a stray value at a different X position is excluded from the fit`() {
        // Simulates a floating price tooltip near the chart crosshair (different X
        // position from the actual right-aligned axis labels) getting picked up by OCR
        // within the same crop strip — it should be excluded, not corrupt the mapping.
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 1150, centerY = 100),
            OcrTextBlock("61.400", centerX = 1152, centerY = 200),
            OcrTextBlock("61.300", centerX = 1148, centerY = 300),
            OcrTextBlock("61.377", centerX = 400, centerY = 250) // off-axis tooltip, different X entirely
        )
        val mapping = mapper.fit(labels)!!

        assertEquals("the off-axis tooltip should be excluded from fitting", 3, mapping.sampleCount)
        assertEquals(1.0, mapping.rSquared, 1e-6)
    }

    @Test
    fun `an inconsistent label among three is either removed or visibly lowers the fit`() {
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 0, centerY = 200),
            OcrTextBlock("59.000", centerX = 0, centerY = 300) // a badly misread label
        )
        val mapping = mapper.fit(labels)!!

        // With only 3 points, removing the outlier leaves just 2 — a valid line, but
        // one whose confidence is capped by the 2-point rule rather than by a poor R².
        // Either way, the bad label must not be allowed to produce a falsely-confident
        // 3-point "clean" result.
        assertTrue(mapping.sampleCount < 3 || mapping.rSquared < 0.95)
    }

    @Test
    fun `unparseable labels are ignored, valid ones still fit`() {
        val labels = listOf(
            OcrTextBlock("Deposit", centerX = 0, centerY = 50),
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("50%", centerX = 0, centerY = 150),
            OcrTextBlock("61.300", centerX = 0, centerY = 300)
        )
        val mapping = mapper.fit(labels)!!
        assertEquals(2, mapping.sampleCount)
    }

    @Test
    fun `labels all at the same Y position cannot fit a line`() {
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 10, centerY = 100)
        )
        assertNull(mapper.fit(labels))
    }
}
