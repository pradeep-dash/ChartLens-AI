package com.chartlens.ai.prediction

import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.candle.CandlePattern

/**
 * Just enough about the most recently closed candle for [PredictionEngine] to
 * use — not the full [com.chartlens.ai.candle.Candle], which carries pixel
 * geometry the prediction layer has no use for. The caller (FrameAnalyzer)
 * already has the full candle and its pattern matches; this is what it
 * distills for prediction purposes.
 */
data class LastCandleContext(
    val closePrice: Double,
    val direction: CandleDirection,
    val upperWickPx: Int,
    val lowerWickPx: Int,
    val patterns: Set<CandlePattern>
)
