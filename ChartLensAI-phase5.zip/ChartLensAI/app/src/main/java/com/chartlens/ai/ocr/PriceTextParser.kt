package com.chartlens.ai.ocr

/**
 * Extracts a price value from raw OCR text like "61.400", "0.19773", or noisy
 * variants OCR sometimes produces. Returns null rather than guessing when the
 * text doesn't contain a recognizable number — per the "if OCR confidence is
 * poor, explicitly mark price values as approximate rather than inventing
 * them" requirement, a failed parse must never become a fabricated 0.0 or
 * similar placeholder.
 *
 * Deliberately requires a decimal separator — a bare integer like "500" is
 * never accepted as a price, even though it's numerically well-formed. Added
 * after a real device test showed a too-narrow OCR crop truncating "92.700"
 * down to just "700": the truncated fragments were still evenly spaced
 * relative to each other, so the downstream linear fit (PriceScaleMapper)
 * produced a mathematically clean, high-confidence mapping built entirely on
 * wrong values — a confidently-wrong mapping is worse than an obviously
 * failed one. Every real price label on the trading platforms this project
 * targets includes a decimal component, so requiring one here is a cheap,
 * durable safeguard against this exact failure mode recurring on some future
 * layout/crop-width combination, independent of getting the crop geometry
 * exactly right.
 *
 * Known limitation: distinguishing a US-style thousands separator ("1,234.56")
 * from a European-style decimal comma ("1234,56") is genuinely ambiguous
 * without locale context. This class tries the thousands-separator pattern
 * first since it's the more common convention on the trading platforms this
 * project targets, but a European-format label could misparse. Worth revisiting
 * if real testing shows it matters for a given platform's locale.
 */
object PriceTextParser {

    private val thousandsPattern = Regex("""-?\d{1,3}(,\d{3})+(\.\d+)?""")
    private val decimalPattern = Regex("""-?\d+[.,]\d+""")

    fun parse(rawText: String): Double? {
        val cleaned = rawText.trim()

        thousandsPattern.find(cleaned)?.let { match ->
            return match.value.replace(",", "").toDoubleOrNull()
        }

        val match = decimalPattern.find(cleaned) ?: return null
        return match.value.replace(',', '.').toDoubleOrNull()
    }
}
