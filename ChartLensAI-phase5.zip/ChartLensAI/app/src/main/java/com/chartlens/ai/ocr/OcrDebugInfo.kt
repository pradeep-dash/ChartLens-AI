package com.chartlens.ai.ocr

/**
 * Diagnostic-only snapshot of what the last OCR pass actually saw, before any
 * price/time parsing. Exists purely to make remote debugging possible without
 * device log access — this distinguishes "ML Kit found zero text in the
 * cropped strip" (crop region or image quality problem) from "ML Kit found
 * text but none of it parsed as a price/time" (format/regex problem), which
 * otherwise look identical from the outside ("Price: unmapped").
 *
 * [priceAxisCropSize]/[timeAxisCropSize] and the [priceAxisError]/
 * [timeAxisError] fields exist for a third, previously-invisible case: a
 * crop or OCR call that outright fails (a degenerate/zero-size crop, an ML
 * Kit exception) looked identical to "OCR ran cleanly and legitimately found
 * nothing" from the outside, since both produced an empty raw-text list.
 * Added after a real device test showed 0 price-axis labels found across
 * three separate OCR passes over a full minute — a genuinely different, more
 * severe failure than earlier rounds (which always found *something*, even
 * if wrong), and one where the actual cause couldn't be determined from the
 * text list alone.
 */
data class OcrDebugInfo(
    val priceAxisRawTexts: List<String>,
    val timeAxisRawTexts: List<String>,
    val priceAxisCropSize: String? = null,
    val timeAxisCropSize: String? = null,
    val priceAxisError: String? = null,
    val timeAxisError: String? = null
)
