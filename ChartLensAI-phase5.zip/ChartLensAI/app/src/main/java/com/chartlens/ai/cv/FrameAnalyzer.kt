package com.chartlens.ai.cv

import android.graphics.Bitmap
import android.util.Log
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.CandleCloseTracker
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.analysis.DataQualityCalculator
import com.chartlens.ai.analysis.PriceCandle
import com.chartlens.ai.analysis.PriceScaleMapper
import com.chartlens.ai.analysis.PriceScaleMapping
import com.chartlens.ai.analysis.TechnicalAnalysisEngine
import com.chartlens.ai.analysis.TimeframeDetector
import com.chartlens.ai.analysis.TimeframeResult
import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDetector
import com.chartlens.ai.candle.CandlePatternDetector
import com.chartlens.ai.common.PixelBuffer
import com.chartlens.ai.ocr.OcrDebugInfo
import com.chartlens.ai.ocr.OcrEngine
import com.chartlens.ai.prediction.LastCandleContext
import com.chartlens.ai.prediction.PredictionEngine

/**
 * The only class in the pipeline that touches `android.graphics.Bitmap` or ML
 * Kit — everything downstream (ChartDetector, CandleDetector,
 * CandlePatternDetector, PriceScaleMapper, TimeframeDetector,
 * TechnicalAnalysisEngine) operates on pure-Kotlin models and is unit tested.
 * This class itself is reviewed by hand, same as the rest of the Bitmap/
 * MediaProjection/ML-Kit boundary.
 *
 * Performance notes (two independent caches, different intervals):
 *  - Chart-region detection is re-run every [rediscoverEveryNFrames] frames —
 *    the chart's on-screen position rarely moves between frames.
 *  - OCR (price + time axis) is re-run every [ocrEveryNFrames] frames, a
 *    longer interval than chart-region rediscovery, since text recognition is
 *    meaningfully more expensive than the pixel-geometry work and the visible
 *    price/time range changes far less often than individual candles do.
 * Neither interval has been tuned against real device measurements yet — see
 * README "Known limitations" for the Phase 9 follow-up.
 *
 * Price-axis/time-axis crop regions assume the common trading-app convention
 * this project was tested against: price labels along the right edge of the
 * screen, time labels along the bottom. The price-axis strip is anchored to
 * the bitmap's right edge (not the detected chart region's right edge) since
 * real charts often reserve blank space between the last candle and the
 * price axis — anchoring to the screen edge instead of the candle region
 * proved necessary after a real device test found the original region-relative
 * crop landing entirely in that blank space and finding zero text. A platform
 * using the opposite convention (price axis on the left) would need this
 * adjusted — documented as a known limitation, not silently handled.
 */
class FrameAnalyzer(
    private val chartDetector: ChartDetector = ChartDetector(),
    private val candleDetector: CandleDetector = CandleDetector(),
    private val patternDetector: CandlePatternDetector = CandlePatternDetector(),
    private val ocrEngine: OcrEngine = OcrEngine(),
    private val priceScaleMapper: PriceScaleMapper = PriceScaleMapper(),
    private val timeframeDetector: TimeframeDetector = TimeframeDetector(),
    private val technicalAnalysisEngine: TechnicalAnalysisEngine = TechnicalAnalysisEngine(),
    private val candleCloseTracker: CandleCloseTracker = CandleCloseTracker(),
    private val predictionEngine: PredictionEngine = PredictionEngine(),
    private val rediscoverEveryNFrames: Int = 20,
    private val ocrEveryNFrames: Int = 30,
    private val timeAxisStripHeightPx: Int = 150,
    private val minPriceMappingConfidenceForAnalysis: Float = 0.6f
) {
    private var cachedAutoRegion: ChartRegion? = null
    private var framesSinceRediscovery = 0

    private var cachedPriceScaleMapping: PriceScaleMapping? = null
    private var cachedTimeframeResult: TimeframeResult? = null
    private var cachedOcrDebug: OcrDebugInfo? = null
    private var framesSinceOcr = Int.MAX_VALUE // force an OCR pass on the first eligible frame

    suspend fun analyze(bitmap: Bitmap, manualRegion: ChartRegion?, timestampMillis: Long): AnalysisFrame {
        val fullBuffer = bitmap.toPixelBuffer()
        val region = manualRegion ?: resolveAutoRegion(fullBuffer)

        if (region == null || !region.isUsable()) {
            return AnalysisFrame(
                timestampMillis = timestampMillis,
                chartRegion = region,
                candles = emptyList(),
                patternMatches = emptyList(),
                dataQuality = DataQuality.INVALID
            )
        }

        val cropped = fullBuffer.crop(
            left = region.left.coerceIn(0, fullBuffer.width),
            top = region.top.coerceIn(0, fullBuffer.height),
            right = region.right.coerceIn(0, fullBuffer.width),
            bottom = region.bottom.coerceIn(0, fullBuffer.height)
        )

        val candles = candleDetector.detect(cropped)
        val patterns = patternDetector.detect(candles)
        val closeEvent = candleCloseTracker.update(candles)

        runOcrIfDue(bitmap, region, candles)

        val priceMapping = cachedPriceScaleMapping
        // Only convert to real prices and run technical analysis when the mapping is
        // trustworthy enough to be worth it. A weak mapping (e.g. fitted from only 2 poor
        // labels, capped at 50% confidence by design) can still produce a mathematically
        // valid-looking line — feeding it through would produce specific, precise-looking
        // indicator values (an exact RSI, exact EMA numbers) built on essentially
        // guesswork, which is exactly the kind of falsely-confident output the "never
        // fabricate" rules exist to prevent. This gate was added after a real device test
        // showed EMA values in the thousands on a chart where the real price was ~0.69 —
        // mathematically consistent with the (bad) mapping, but obviously wrong, and nothing
        // upstream was stopping it from being computed and displayed as if it meant something.
        val priceCandles = if (priceMapping != null && priceMapping.confidence >= minPriceMappingConfidenceForAnalysis) {
            candles.filterNot { it.isForming }.map { it.toPriceCandle(priceMapping) }
        } else {
            emptyList()
        }
        val technicalAnalysis = if (priceCandles.isNotEmpty()) {
            technicalAnalysisEngine.analyze(priceCandles)
        } else {
            null
        }

        val quality = DataQualityCalculator.calculate(region.confidence, candles, priceMapping?.confidence)

        val closedPixelCandles = candles.filterNot { it.isForming }
        val lastClosedCandle = closedPixelCandles.maxByOrNull { it.index }
        val lastClosedPriceCandle = priceCandles.maxByOrNull { it.index }
        val lastCandleContext = if (lastClosedCandle != null && lastClosedPriceCandle != null) {
            LastCandleContext(
                closePrice = lastClosedPriceCandle.close,
                direction = lastClosedCandle.direction,
                upperWickPx = lastClosedCandle.upperWickPx,
                lowerWickPx = lastClosedCandle.lowerWickPx,
                patterns = patterns.find { it.candleIndex == lastClosedCandle.index }?.patterns ?: emptySet()
            )
        } else {
            null
        }
        val prediction = predictionEngine.predict(
            technicalAnalysis = technicalAnalysis,
            closedCandleCount = closedPixelCandles.size,
            lastCandle = lastCandleContext,
            timeframe = cachedTimeframeResult?.timeframe
        )

        return AnalysisFrame(
            timestampMillis = timestampMillis,
            chartRegion = region,
            candles = candles,
            patternMatches = patterns,
            dataQuality = quality,
            priceScaleMapping = priceMapping,
            timeframeResult = cachedTimeframeResult,
            priceCandles = priceCandles,
            technicalAnalysis = technicalAnalysis,
            candleCloseEvent = closeEvent,
            ocrDebug = cachedOcrDebug,
            prediction = prediction
        )
    }

    /** Call when the user changes/clears the manual selection, or on a new capture session. */
    fun invalidateCache() {
        cachedAutoRegion = null
        framesSinceRediscovery = 0
        cachedPriceScaleMapping = null
        cachedTimeframeResult = null
        cachedOcrDebug = null
        framesSinceOcr = Int.MAX_VALUE
        candleCloseTracker.reset()
    }

    fun close() {
        ocrEngine.close()
    }

    private fun resolveAutoRegion(fullBuffer: PixelBuffer): ChartRegion? {
        val shouldRediscover = cachedAutoRegion == null || framesSinceRediscovery >= rediscoverEveryNFrames
        return if (shouldRediscover) {
            framesSinceRediscovery = 0
            chartDetector.detect(fullBuffer).also { cachedAutoRegion = it }
        } else {
            framesSinceRediscovery++
            cachedAutoRegion
        }
    }

    private suspend fun runOcrIfDue(bitmap: Bitmap, region: ChartRegion, candles: List<Candle>) {
        if (framesSinceOcr < ocrEveryNFrames) {
            framesSinceOcr++
            return
        }
        framesSinceOcr = 0

        val priceAxisBitmap = cropPriceAxisStrip(bitmap, region)
        val timeAxisBitmap = cropTimeAxisStrip(bitmap, region)

        var priceAxisError: String? = null
        var timeAxisError: String? = null

        val priceAxisLabels = try {
            if (priceAxisBitmap == null) {
                priceAxisError = "crop returned null (degenerate region)"
                emptyList()
            } else {
                ocrEngine.recognize(priceAxisBitmap)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Price-axis OCR failed", t)
            priceAxisError = "${t::class.simpleName}: ${t.message}"
            emptyList()
        }

        val timeAxisLabels = try {
            if (timeAxisBitmap == null) {
                timeAxisError = "crop returned null (degenerate region)"
                emptyList()
            } else {
                ocrEngine.recognize(timeAxisBitmap)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Time-axis OCR failed", t)
            timeAxisError = "${t::class.simpleName}: ${t.message}"
            emptyList()
        }

        cachedOcrDebug = OcrDebugInfo(
            priceAxisRawTexts = priceAxisLabels.map { it.text }.take(12),
            timeAxisRawTexts = timeAxisLabels.map { it.text }.take(12),
            priceAxisCropSize = priceAxisBitmap?.let { "${it.width}x${it.height}" },
            timeAxisCropSize = timeAxisBitmap?.let { "${it.width}x${it.height}" },
            priceAxisError = priceAxisError,
            timeAxisError = timeAxisError
        )

        priceScaleMapper.fit(priceAxisLabels)?.let { cachedPriceScaleMapping = it }
        // If fit() returns null (not enough usable labels this pass), keep the previous
        // mapping rather than blank it out — a single bad OCR pass on an otherwise
        // stable price axis shouldn't throw away a good mapping from moments ago.

        val timeframe = timeframeDetector.detect(timeAxisLabels, candles)
        if (timeframe.timeframe != null || cachedTimeframeResult == null) {
            // Same "don't blank out a good cached result on one bad pass" policy as
            // price mapping above — but only once we have any cached result at all;
            // the very first attempt should always be recorded, even if inconclusive,
            // so the UI shows "estimated but unmatched" rather than nothing at all.
            cachedTimeframeResult = timeframe
        }
    }

    private fun cropPriceAxisStrip(bitmap: Bitmap, region: ChartRegion): Bitmap? {
        // Spans the ENTIRE remaining width to the right of the candles, not a fixed
        // guessed width — a fixed width has now proven wrong in both directions on two
        // different real layouts: too narrow on a portrait layout with blank chart space
        // reserved after the last candle, and (anchoring to the screen edge instead)
        // wrong on a wide/landscape layout with a persistent sidebar occupying the actual
        // screen edge, which pulled in sidebar text ("Withdrawal", trade amounts) instead
        // of the chart's own price axis. Rather than keep guessing a pixel width that's
        // fundamentally layout-dependent, this crops generously and relies on
        // PriceScaleMapper's X-position clustering to find the real axis among whatever
        // else gets swept in — that logic is much better positioned to tell "a vertically
        // stacked column of prices" apart from scattered sidebar noise than a fixed guess
        // made without seeing the layout ever is.
        val left = region.right.coerceIn(0, bitmap.width)
        val right = bitmap.width
        val top = region.top.coerceIn(0, bitmap.height)
        val bottom = region.bottom.coerceIn(0, bitmap.height)
        if (right <= left || bottom <= top) return null
        return safeCrop(bitmap, left, top, right - left, bottom - top)
    }

    private fun cropTimeAxisStrip(bitmap: Bitmap, region: ChartRegion): Bitmap? {
        // Full bitmap width, generous height below the chart — same "crop wide, let the
        // strict HH:mm parser filter" reasoning as the price-axis strip above.
        val left = 0
        val right = bitmap.width
        val top = region.bottom.coerceIn(0, bitmap.height)
        val bottom = (region.bottom + timeAxisStripHeightPx).coerceIn(0, bitmap.height)
        if (right <= left || bottom <= top) return null
        return safeCrop(bitmap, left, top, right - left, bottom - top)
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, width: Int, height: Int): Bitmap? {
        return try {
            Bitmap.createBitmap(bitmap, x, y, width, height)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to crop OCR strip at ($x,$y,$width,$height)", t)
            null
        }
    }

    private fun Candle.toPriceCandle(mapping: PriceScaleMapping): PriceCandle = PriceCandle(
        index = index,
        timestampMillis = null, // real timestamps need timeframe + a reference clock — not derived here
        open = mapping.priceAt(openY.toDouble()),
        high = mapping.priceAt(highY.toDouble()),
        low = mapping.priceAt(lowY.toDouble()),
        close = mapping.priceAt(closeY.toDouble())
    )

    private fun Bitmap.toPixelBuffer(): PixelBuffer {
        val pixels = IntArray(width * height)
        getPixels(pixels, 0, width, 0, 0, width, height)
        return PixelBuffer(width, height, pixels)
    }

    private companion object {
        const val TAG = "FrameAnalyzer"
    }
}
