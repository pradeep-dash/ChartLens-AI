package com.chartlens.ai.prediction

import com.chartlens.ai.analysis.BreakoutStatus
import com.chartlens.ai.analysis.MomentumResult
import com.chartlens.ai.analysis.RejectionStatus
import com.chartlens.ai.analysis.SupportResistanceResult
import com.chartlens.ai.analysis.TechnicalAnalysisResult
import com.chartlens.ai.analysis.Timeframe
import com.chartlens.ai.analysis.Trend
import com.chartlens.ai.analysis.TrendResult
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.candle.CandlePattern
import com.chartlens.ai.indicators.MacdPoint
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Combines every evidence source Phases 2-4 now produce (trend, momentum, EMA
 * alignment, RSI, MACD, support/resistance, candle patterns, recent candle
 * sequence) into a weighted directional score — never a single "will the next
 * candle be green or red" ask to an LLM, per the spec's explicit requirement.
 *
 * Every evidence function below returns a score in [-1, 1] plus whether it
 * had enough data to say anything at all ([EvidenceSignal.applicable]).
 * Inapplicable evidence contributes nothing to the final weighted average —
 * it is never silently treated as neutral, which would be a different
 * (fabricated) claim than "we don't know."
 *
 * NO_TRADE is mandatory output, not an edge case (spec §12). Every condition
 * the spec lists — insufficient data/candles, conflicting evidence, low
 * confidence, an unknown timeframe, a doji/chop candle, price sitting right
 * at a support/resistance level without breaking through, elevated
 * volatility — is treated as an independent, standalone trigger: any single
 * one firing forces NO_TRADE, regardless of how strong the other evidence
 * looks. Multiple reasons can and often will apply to one NO_TRADE result.
 *
 * [PredictionResult.modelConfidence] is a raw heuristic score, not a
 * calibrated probability — see [PredictionResult]'s doc comment. All the
 * numeric thresholds and default weights below are reasonable starting
 * points, not calibrated values; real calibration needs Phase 7's historical
 * outcome journal, which doesn't exist yet.
 */
class PredictionEngine(
    private val weights: PredictionWeights = PredictionWeights(),
    private val minClosedCandles: Int = 15,
    private val directionalThreshold: Double = 0.15,
    private val minConfidencePercent: Int = 40,
    private val conflictRatioThreshold: Double = 0.6,
    private val nearLevelToleranceFraction: Double = 0.003,
    private val volatilityBandWidthFraction: Double = 0.02,
    private val momentumScaleDivisor: Double = 0.3,
    private val overboughtThreshold: Double = 70.0,
    private val oversoldThreshold: Double = 30.0
) {

    fun predict(
        technicalAnalysis: TechnicalAnalysisResult?,
        closedCandleCount: Int,
        lastCandle: LastCandleContext?,
        timeframe: Timeframe?
    ): PredictionResult {
        if (technicalAnalysis == null) {
            return noTrade(NoTradeReason.INSUFFICIENT_DATA)
        }
        if (closedCandleCount < minClosedCandles) {
            return noTrade(NoTradeReason.INSUFFICIENT_CANDLES)
        }

        val evidence = computeEvidence(technicalAnalysis, lastCandle)
        val applicable = evidence.filter { it.applicable }
        if (applicable.isEmpty()) {
            return noTrade(NoTradeReason.INSUFFICIENT_DATA, evidence)
        }

        val totalWeight = applicable.sumOf { it.weight }
        val normalizedScore = if (totalWeight > 0) {
            applicable.sumOf { it.score * it.weight } / totalWeight
        } else {
            0.0
        }

        val bullishWeight = applicable.filter { it.score > 0.05 }.sumOf { it.weight }
        val bearishWeight = applicable.filter { it.score < -0.05 }.sumOf { it.weight }
        val conflicting = bullishWeight > 0 && bearishWeight > 0 &&
            minOf(bullishWeight, bearishWeight) / maxOf(bullishWeight, bearishWeight) > conflictRatioThreshold

        val rawConfidence = (abs(normalizedScore) * 100).roundToInt().coerceIn(0, 100)
        val rawDirection = when {
            normalizedScore > directionalThreshold -> PredictionDirection.UP
            normalizedScore < -directionalThreshold -> PredictionDirection.DOWN
            else -> PredictionDirection.NO_TRADE
        }

        val dojiChop = lastCandle != null && lastCandle.patterns.contains(CandlePattern.DOJI)
        val nearKeyLevel = lastCandle != null &&
            isNearKeyLevel(technicalAnalysis.supportResistance, lastCandle.closePrice) &&
            technicalAnalysis.supportResistance.breakoutStatus == BreakoutStatus.NONE
        val abnormalVolatility = isAbnormalVolatility(technicalAnalysis)
        val unknownTimeframe = timeframe == null
        val lowConfidence = rawConfidence < minConfidencePercent

        // Every one of these is an independent, standalone gate — any single one
        // firing forces NO_TRADE regardless of how strong the others look. This is
        // deliberately not a points system where a strong trend can "outvote" a
        // doji candle or an unknown timeframe; the spec treats each as its own
        // legitimate reason to decline.
        val reasons = mutableListOf<NoTradeReason>()
        if (rawDirection == PredictionDirection.NO_TRADE || lowConfidence) {
            reasons += NoTradeReason.LOW_DIRECTIONAL_CONFIDENCE
        }
        if (conflicting) reasons += NoTradeReason.CONFLICTING_EVIDENCE
        if (unknownTimeframe) reasons += NoTradeReason.UNKNOWN_TIMEFRAME
        if (dojiChop) reasons += NoTradeReason.DOJI_CHOP
        if (nearKeyLevel) reasons += NoTradeReason.PRICE_NEAR_KEY_LEVEL
        if (abnormalVolatility) reasons += NoTradeReason.ABNORMAL_VOLATILITY

        val finalDirection = if (reasons.isNotEmpty()) PredictionDirection.NO_TRADE else rawDirection

        return PredictionResult(
            direction = finalDirection,
            modelConfidence = if (finalDirection == PredictionDirection.NO_TRADE) 0 else rawConfidence,
            evidence = evidence,
            noTradeReasons = if (finalDirection == PredictionDirection.NO_TRADE) reasons.distinct() else emptyList(),
            setup = if (finalDirection != PredictionDirection.NO_TRADE) classifySetup(evidence, finalDirection) else null
        )
    }

    private fun noTrade(reason: NoTradeReason, evidence: List<EvidenceSignal> = emptyList()) =
        PredictionResult(PredictionDirection.NO_TRADE, 0, evidence, listOf(reason), null)

    private fun computeEvidence(ta: TechnicalAnalysisResult, lastCandle: LastCandleContext?): List<EvidenceSignal> = listOf(
        trendEvidence(ta.trend),
        momentumEvidence(ta.momentum),
        emaAlignmentEvidence(ta.ema9, ta.ema21, ta.ema50),
        rsiEvidence(ta.rsi14),
        macdEvidence(ta.macd),
        supportResistanceEvidence(ta.supportResistance),
        candlePatternEvidence(lastCandle),
        recentSequenceEvidence(ta.momentum, lastCandle)
    )

    private fun trendEvidence(trend: TrendResult): EvidenceSignal {
        val applicable = trend.trend != Trend.UNKNOWN
        val score = when (trend.trend) {
            Trend.UPTREND -> trend.trendStrength.toDouble()
            Trend.DOWNTREND -> -trend.trendStrength.toDouble()
            else -> 0.0
        }
        return EvidenceSignal("trend", score.coerceIn(-1.0, 1.0), applicable, weights.trend)
    }

    private fun momentumEvidence(momentum: MomentumResult): EvidenceSignal {
        val roc = momentum.rateOfChangePercent
        if (roc == null) return EvidenceSignal("momentum", 0.0, false, weights.momentum)
        return EvidenceSignal("momentum", (roc / momentumScaleDivisor).coerceIn(-1.0, 1.0), true, weights.momentum)
    }

    private fun emaAlignmentEvidence(ema9: Double?, ema21: Double?, ema50: Double?): EvidenceSignal {
        if (ema9 == null || ema21 == null || ema50 == null) {
            return EvidenceSignal("ema_alignment", 0.0, false, weights.emaAlignment)
        }
        var sum = 0
        sum += pairwiseSign(ema9, ema21)
        sum += pairwiseSign(ema21, ema50)
        sum += pairwiseSign(ema9, ema50)
        return EvidenceSignal("ema_alignment", sum / 3.0, true, weights.emaAlignment)
    }

    private fun pairwiseSign(a: Double, b: Double): Int = when {
        a > b -> 1
        a < b -> -1
        else -> 0
    }

    private fun rsiEvidence(rsi: Double?): EvidenceSignal {
        if (rsi == null) return EvidenceSignal("rsi", 0.0, false, weights.rsi)
        val score = when {
            rsi >= overboughtThreshold ->
                -((rsi - overboughtThreshold) / (100 - overboughtThreshold)).coerceIn(0.0, 1.0)
            rsi <= oversoldThreshold ->
                ((oversoldThreshold - rsi) / oversoldThreshold).coerceIn(0.0, 1.0)
            else ->
                // Mild, deliberately weak continuation lean around the midline —
                // outside the overbought/oversold zones, RSI position relative to
                // 50 is a much softer signal than the reversal zones above.
                ((rsi - 50) / 50) * 0.3
        }
        return EvidenceSignal("rsi", score.coerceIn(-1.0, 1.0), true, weights.rsi)
    }

    private fun macdEvidence(macd: MacdPoint?): EvidenceSignal {
        if (macd == null) return EvidenceSignal("macd", 0.0, false, weights.macd)
        val score = when {
            macd.macd != 0.0 -> (macd.histogram / abs(macd.macd)).coerceIn(-1.0, 1.0)
            macd.histogram > 0.0 -> 0.3
            macd.histogram < 0.0 -> -0.3
            else -> 0.0
        }
        return EvidenceSignal("macd", score, true, weights.macd)
    }

    private fun supportResistanceEvidence(sr: SupportResistanceResult): EvidenceSignal {
        val applicable = sr.nearestSupport != null || sr.nearestResistance != null
        val score = when (sr.breakoutStatus) {
            BreakoutStatus.BROKE_ABOVE_RESISTANCE -> 0.8
            BreakoutStatus.BROKE_BELOW_SUPPORT -> -0.8
            BreakoutStatus.NONE -> when (sr.rejectionStatus) {
                RejectionStatus.REJECTED_AT_RESISTANCE -> -0.6
                RejectionStatus.REJECTED_AT_SUPPORT -> 0.6
                RejectionStatus.NONE -> 0.0
            }
        }
        return EvidenceSignal("support_resistance", score, applicable, weights.supportResistance)
    }

    private fun candlePatternEvidence(lastCandle: LastCandleContext?): EvidenceSignal {
        if (lastCandle == null || lastCandle.patterns.isEmpty()) {
            return EvidenceSignal("candle_pattern", 0.0, false, weights.candlePatterns)
        }
        val scores = lastCandle.patterns.map { pattern ->
            when (pattern) {
                CandlePattern.BULLISH_ENGULFING -> 0.8
                CandlePattern.BEARISH_ENGULFING -> -0.8
                CandlePattern.HAMMER -> 0.5
                CandlePattern.INVERTED_HAMMER -> 0.3
                CandlePattern.SHOOTING_STAR -> -0.5
                CandlePattern.STRONG_MOMENTUM -> if (lastCandle.direction == CandleDirection.BULLISH) 0.6 else -0.6
                CandlePattern.LONG_WICK_REJECTION ->
                    if (lastCandle.lowerWickPx > lastCandle.upperWickPx) 0.4 else -0.4
                CandlePattern.DOJI, CandlePattern.SPINNING_TOP, CandlePattern.INSIDE_BAR -> 0.0
            }
        }
        return EvidenceSignal("candle_pattern", scores.average().coerceIn(-1.0, 1.0), true, weights.candlePatterns)
    }

    private fun recentSequenceEvidence(momentum: MomentumResult, lastCandle: LastCandleContext?): EvidenceSignal {
        val streak = momentum.consecutiveSameDirectionCandles
        if (streak < 2 || lastCandle == null) {
            return EvidenceSignal("recent_sequence", 0.0, false, weights.recentCandleSequence)
        }
        val sign = if (lastCandle.direction == CandleDirection.BULLISH) 1.0 else -1.0
        val magnitude = (streak / 5.0).coerceIn(0.0, 1.0)
        return EvidenceSignal("recent_sequence", sign * magnitude * 0.6, true, weights.recentCandleSequence)
    }

    private fun isNearKeyLevel(sr: SupportResistanceResult, currentPrice: Double): Boolean {
        val nearResistance = sr.nearestResistance?.let { level ->
            level > 0 && abs(currentPrice - level) / level <= nearLevelToleranceFraction
        } ?: false
        val nearSupport = sr.nearestSupport?.let { level ->
            level > 0 && abs(currentPrice - level) / level <= nearLevelToleranceFraction
        } ?: false
        return nearResistance || nearSupport
    }

    private fun isAbnormalVolatility(ta: TechnicalAnalysisResult): Boolean {
        val bands = ta.bollinger ?: return false
        if (bands.middle <= 0) return false
        val widthFraction = (bands.upper - bands.lower) / bands.middle
        return widthFraction > volatilityBandWidthFraction
    }

    private fun classifySetup(evidence: List<EvidenceSignal>, direction: PredictionDirection): String {
        val dominant = evidence.filter { it.applicable }.maxByOrNull { abs(it.score) * it.weight }
        val trendSignal = evidence.first { it.name == "trend" }
        val srSignal = evidence.first { it.name == "support_resistance" }

        return when {
            srSignal.applicable && abs(srSignal.score) >= 0.6 -> "breakout_or_rejection"
            trendSignal.applicable && abs(trendSignal.score) >= 0.5 &&
                dominant?.name == "trend" -> "trend_continuation"
            dominant?.name == "candle_pattern" -> "pattern_reversal"
            else -> "mixed_evidence"
        }
    }
}
