package com.chartlens.ai.analysis

import com.chartlens.ai.ocr.OcrTextBlock
import com.chartlens.ai.ocr.PriceTextParser
import kotlin.math.abs

/**
 * pixelY -> price is linear (screen coordinates map to a price axis linearly
 * within the visible viewport), fitted as `price = slope * pixelY + intercept`.
 *
 * [confidence] combines fit quality (R²) with sample count: any 2 points fit a
 * line perfectly (R²=1.0) whether or not the OCR readings are actually
 * correct, so a 2-point fit is deliberately never treated as fully confident —
 * only 3+ points can reveal an inconsistent/misread label through a worse fit.
 */
data class PriceScaleMapping(
    val slope: Double,
    val intercept: Double,
    val rSquared: Double,
    val sampleCount: Int,
    val confidence: Float
) {
    fun priceAt(pixelY: Double): Double = slope * pixelY + intercept
}

/**
 * Fits a [PriceScaleMapping] from OCR'd price-axis labels using ordinary
 * least-squares linear regression — not a fixed price increment (per the "do
 * not assume a fixed price increment" requirement).
 *
 * Two robustness passes run before/during the fit, both added after a real
 * device test produced a 7% confidence mapping from 9 OCR'd labels:
 *
 *  1. **X-position clustering.** Real price-axis labels are vertically stacked
 *     along the same X position (right-aligned on the axis). Anything else
 *     that happens to parse as a number within the crop strip — a floating
 *     price tooltip near the chart crosshair, a stray UI value — usually sits
 *     at a different X. Only the largest X-aligned cluster of candidates is
 *     used for fitting; the rest are discarded before the line is even fit,
 *     rather than being allowed to corrupt it.
 *  2. **Iterative outlier removal.** After fitting, if one point's residual is
 *     much larger than the others' and removing it meaningfully improves the
 *     fit, it's dropped and the line is refit (up to [maxOutliersToDrop]
 *     times). This catches a genuinely misread single label among otherwise-
 *     good ones, which X-clustering alone wouldn't catch (a misread label is
 *     still at the right X position, just the wrong price).
 *
 * Pure Kotlin — every input here is already-recognized text with a pixel
 * position, so this is fully unit-testable without ML Kit, a Bitmap, or a
 * device. The only Android-touching part of price mapping is
 * [com.chartlens.ai.ocr.OcrEngine], which produces the [OcrTextBlock]s this
 * class consumes.
 */
class PriceScaleMapper(
    private val xClusterTolerancePx: Int = 40,
    private val outlierResidualMultiplier: Double = 3.0,
    private val maxOutliersToDrop: Int = 2
) {

    fun fit(labels: List<OcrTextBlock>): PriceScaleMapping? {
        val candidates = labels.mapNotNull { block ->
            PriceTextParser.parse(block.text)?.let { price ->
                Candidate(centerX = block.centerX, pixelY = block.centerY.toDouble(), price = price)
            }
        }
        if (candidates.size < 2) return null

        val axisAligned = selectDominantXCluster(candidates)
        if (axisAligned.size < 2) return null

        return fitWithOutlierRemoval(axisAligned)
    }

    private data class Candidate(val centerX: Int, val pixelY: Double, val price: Double)

    /** Keeps only the largest cluster of candidates whose X positions are within tolerance of each other. */
    private fun selectDominantXCluster(candidates: List<Candidate>): List<Candidate> {
        val sorted = candidates.sortedBy { it.centerX }
        val clusters = mutableListOf<MutableList<Candidate>>()

        for (candidate in sorted) {
            val lastCluster = clusters.lastOrNull()
            val lastClusterAvgX = lastCluster?.let { cluster -> cluster.sumOf { it.centerX } / cluster.size }
            if (lastCluster != null && lastClusterAvgX != null &&
                abs(candidate.centerX - lastClusterAvgX) <= xClusterTolerancePx
            ) {
                lastCluster += candidate
            } else {
                clusters += mutableListOf(candidate)
            }
        }

        return clusters.maxByOrNull { it.size } ?: emptyList()
    }

    private fun fitWithOutlierRemoval(initial: List<Candidate>): PriceScaleMapping? {
        var working = initial
        var current = leastSquares(working) ?: return null

        var dropped = 0
        while (dropped < maxOutliersToDrop && working.size > 2) {
            val residuals = working.map { abs(it.price - current.priceAt(it.pixelY)) }
            val medianAbsResidual = median(residuals)
            if (medianAbsResidual < NEGLIGIBLE_RESIDUAL) break // fit is already essentially perfect

            val worstIndex = residuals.indices.maxByOrNull { residuals[it] } ?: break
            if (residuals[worstIndex] <= outlierResidualMultiplier * medianAbsResidual) break // no clear outlier

            val reduced = working.toMutableList().also { it.removeAt(worstIndex) }
            val reducedFit = leastSquares(reduced) ?: break
            if (reducedFit.rSquared <= current.rSquared + 0.02) break // not a meaningful improvement

            working = reduced
            current = reducedFit
            dropped++
        }

        return current
    }

    /** Median is deliberately used over mean here: a single outlier inflates the mean of
     * the residuals it's itself part of, diluting the exact signal we're trying to detect. */
    private fun median(values: List<Double>): Double {
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
    }

    private fun leastSquares(points: List<Candidate>): PriceScaleMapping? {
        if (points.size < 2) return null
        val distinctPixelY = points.map { it.pixelY }.distinct().size
        if (distinctPixelY < 2) return null

        val n = points.size
        val meanPixelY = points.sumOf { it.pixelY } / n
        val meanPrice = points.sumOf { it.price } / n

        val ssYY = points.sumOf { (it.pixelY - meanPixelY) * (it.pixelY - meanPixelY) }
        val ssYPrice = points.sumOf { (it.pixelY - meanPixelY) * (it.price - meanPrice) }
        if (ssYY == 0.0) return null

        val slope = ssYPrice / ssYY
        val intercept = meanPrice - slope * meanPixelY

        val ssTot = points.sumOf { (it.price - meanPrice) * (it.price - meanPrice) }
        val ssRes = points.sumOf { p ->
            val predicted = slope * p.pixelY + intercept
            (p.price - predicted) * (p.price - predicted)
        }
        val rSquared = if (ssTot == 0.0) 1.0 else 1.0 - (ssRes / ssTot)

        // A 2-point fit is always a perfect line (R²=1.0) regardless of whether the
        // readings are correct, so it's capped well below full confidence; 3+ points
        // let a bad reading actually show up as a worse fit.
        val confidence = if (n >= 3) {
            rSquared.coerceIn(0.0, 1.0)
        } else {
            (rSquared * 0.5).coerceIn(0.0, 1.0)
        }.toFloat()

        return PriceScaleMapping(slope, intercept, rSquared, n, confidence)
    }

    private companion object {
        const val NEGLIGIBLE_RESIDUAL = 1e-6
    }
}
