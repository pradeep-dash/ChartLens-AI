package com.chartlens.ai.prediction

/**
 * Per-evidence-source importance multipliers. Defaults are reasonable
 * starting points, not calibrated values — real calibration needs historical
 * outcome data from Phase 7's prediction journal, which doesn't exist yet.
 */
data class PredictionWeights(
    val trend: Double = 1.0,
    val momentum: Double = 1.0,
    val emaAlignment: Double = 1.0,
    val rsi: Double = 0.8,
    val macd: Double = 0.8,
    val supportResistance: Double = 1.0,
    val candlePatterns: Double = 0.7,
    val recentCandleSequence: Double = 0.6
)
