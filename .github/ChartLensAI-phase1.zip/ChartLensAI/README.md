# ChartLens AI — Phase 1 (Foundation)

Analysis/decision-support only. This app never places trades, clicks buttons, or
interacts with any trading platform — it only reads the screen and displays
information.

This milestone covers **Phase 1 of 9** from the full project plan: project setup,
permissions, MediaProjection screen capture, the foreground service, and the
floating overlay. It does **not** yet include chart detection, candle detection,
technical analysis, predictions, or AI reasoning — see "What was implemented"
below for the exact boundary.

---

## 1. What was implemented

- Android project scaffold (Gradle version catalog, Hilt, Compose/Material 3, KSP)
- Full runtime permission sequence: `POST_NOTIFICATIONS` → `SYSTEM_ALERT_WINDOW`
  (overlay) → `MediaProjection` consent, orchestrated in `MainActivity`
- `ScreenCaptureService`: a foreground service (`FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION`)
  that owns the MediaProjection session, correctly sequenced for Android 14's
  requirement that the service be in foreground state *before* the projection is
  granted
- `ScreenCaptureController`: real `ImageReader` + `VirtualDisplay` frame acquisition,
  with row-stride-safe Bitmap conversion, frame-rate throttling (~5fps ceiling),
  and a `FrameChangeDetector` that skips downstream work when the screen hasn't
  materially changed
- Screen rotation handling (`onConfigurationChanged` tears down and recreates the
  capture surface at the new dimensions)
- `OverlayService`: a `WindowManager`-attached floating card (not hosted by an
  Activity) that is draggable, collapsible, has an opacity slider, and shows
  **real** capture status (resolution, frames analyzed, uptime) — no
  bias/confidence/pattern fields, because that layer doesn't exist yet
- Graceful handling of: permission denial at each step, the user stopping
  screen-sharing from system UI, and service teardown

## 2. What was deliberately NOT implemented (by design, this phase)

Everything downstream of "a frame was captured": chart-region detection, candle
detection, OCR, technical indicators, the prediction engine, the AI reasoning
layer, the overlay's bias/confidence display, Room persistence, and analytics.
The overlay and dashboard only ever show real capture-pipeline state — they do
not display placeholder or fabricated analysis, in line with the project's
no-fake-functionality rule.

## 3. Project structure

```
app/src/main/java/com/chartlens/ai/
  ChartLensApplication.kt      Hilt entry point
  common/
    CaptureState.kt            Sealed state model for the capture pipeline
    CaptureStateRepository.kt  Shared in-process StateFlow (Service ↔ Overlay ↔ UI)
  capture/
    CapturedFrame.kt
    FrameChangeDetector.kt     Pure Kotlin, unit tested
    ScreenCaptureController.kt MediaProjection/ImageReader/VirtualDisplay owner
  service/
    ScreenCaptureService.kt    Foreground service
  overlay/
    OverlayLifecycleOwner.kt   Manual Lifecycle/ViewModelStore/SavedStateRegistry
                                for a ComposeView with no Activity host
    OverlayService.kt          WindowManager-attached floating card
  ui/
    MainActivity.kt            Permission orchestration
    MainViewModel.kt
    DashboardScreen.kt
```

Empty package directories (`cv/`, `candle/`, `ocr/`, `analysis/`, `indicators/`,
`prediction/`, `ai/`, `data/`, `database/`, `settings/`, `analytics/`, `replay/`)
from the full architecture are not yet created — they'll be added as each phase
lands, per the modular pipeline design.

## 4. Configuring the build

### 4.1 Gradle wrapper
This environment couldn't generate the binary `gradle-wrapper.jar` (no network
access). `gradle/wrapper/gradle-wrapper.properties` is in place and pinned to
Gradle 8.9. To generate the jar, either:

- Open the project folder in **Android Studio** (Koala or newer) — it will offer
  to generate the wrapper automatically, or
- Run once from a machine with Gradle installed:
  ```
  gradle wrapper --gradle-version 8.9
  ```

### 4.2 OpenCV
`app/build.gradle.kts` declares `implementation(libs.opencv)`, but this Maven
coordinate only resolves if you either:
- add the OpenCV Maven repository (`https://maven.opencv.org`) to
  `settings.gradle.kts`, or
- vendor the OpenCV Android SDK as a local module (the more common approach in
  practice — download from https://opencv.org/releases/, import as a module).

Since Phase 1 doesn't use any CV code yet, you can safely comment out the OpenCV
dependency line until Phase 2 if you want a clean build sooner.

### 4.3 KSP/Kotlin version pairing
`gradle/libs.versions.toml` pins KSP to `2.0.20-1.0.24`. KSP releases are versioned
`<kotlin-version>-<ksp-patch>` and change frequently — verify the exact patch
against https://github.com/google/ksp/releases before building; a mismatch here
is a common source of confusing build failures unrelated to this project's code.

### 4.4 No secrets required yet
Phase 1 has no backend/AI calls, so there's nothing to configure in `local.properties`
for this milestone. When Phase 6 (AI backend) lands, the backend URL will be read
from `local.properties` / build config, never a hardcoded key in the APK, per the
security requirements in the original spec.

## 5. How to build

```
./gradlew assembleDebug
```
(after the wrapper jar exists — see 4.1). The debug APK will be at
`app/build/outputs/apk/debug/app-debug.apk`.

**Important:** none of this has been compiled in the environment that generated
it — there is no Android SDK or emulator available there. This has been reviewed
carefully by hand for API correctness (see notes below on things that were
actually caught and fixed this way), but the first `./gradlew assembleDebug` you
run is the first real compiler pass this code has ever had. Expect to fix a
handful of small issues — most likely Compose/Hilt/KSP version-alignment errors
rather than logic errors.

## 6. How to install on a device

```
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Or run directly from Android Studio with a device connected (USB debugging
enabled) or an emulator running **API 29+** with Google Play system image
(MediaProjection works on plain emulator images too, but overlay permission
UX is easiest to test on a real device).

## 7. Permissions required

| Permission | Why |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Draw the floating overlay above other apps |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Run the capture service while another app is in the foreground |
| `POST_NOTIFICATIONS` | Show the required foreground-service notification (Android 13+) |
| `INTERNET`, `ACCESS_NETWORK_STATE` | Reserved for Phase 6 (AI backend) — unused this phase |
| Screen capture itself | Granted at runtime via the system `MediaProjectionManager` dialog — there is no static manifest permission for it |

## 8. Known limitations

- **Not runnable as a real MVP yet** — this is the foundation phase only. There is
  no chart analysis of any kind.
- **Unverified build** — see section 5. Compose/Kotlin/KSP/Hilt version alignment
  in particular is the most likely first failure point; versions were chosen for
  mutual compatibility as of this writing but weren't verified against an actual
  Gradle sync.
- **MediaProjection consent is not persisted.** Every time the user taps "Start
  Analysis" after a full stop, Android will show the screen-capture consent
  dialog again — this is an OS-level restriction, not something the app can
  avoid.
- **Frame-change detection is coarse.** `FrameChangeDetector` does a whole-frame
  32×32 downsampled comparison. It's real, tested logic, but it's a placeholder
  for the chart-region-aware sampling that Phase 2's `ChartDetector` should do
  instead (comparing only the chart region, not the whole screen, will both be
  faster and more accurate).
- **No launcher icon art** — the mipmap/drawable icons are simple flat vector
  shapes so the project builds without needing binary PNG assets, not real
  branding.
- **Overlay manual selection / crop fallback** (spec section 5) isn't built yet —
  planned for Phase 2 alongside automatic chart detection.

## 9. Tests performed

- `FrameChangeDetectorTest` (6 cases): first-frame-always-changed, identical
  frames not flagged, sub-threshold noise not flagged, a large color-block change
  correctly flagged, a resolution change forcing a re-baseline, and `reset()`
  behavior. This is the only class in Phase 1 that's pure Kotlin logic and
  therefore genuinely unit-testable without an Android runtime or a device.
- Everything else in this phase (`ScreenCaptureController`, `ScreenCaptureService`,
  `OverlayService`) is fundamentally Android-framework-dependent (ImageReader,
  MediaProjection, WindowManager) and was reviewed by hand rather than
  build-verified. These are strong candidates for **instrumented tests**
  (`androidx.test`) once you have a device/emulator to run them on — not
  something that can be meaningfully faked with JVM unit tests.

## 10. Remaining work (next phases)

Per the original phase plan:
- **Phase 2** — Vision: chart-region detection, manual crop fallback, candle
  detection/tracking (OpenCV)
- **Phase 3** — Market reconstruction: OHLC, price-axis OCR mapping, timeframe
  detection, candle-close detection
- **Phase 4** — `TechnicalAnalysisEngine`: trend, momentum, EMA/RSI/MACD/ATR/
  Bollinger, support/resistance, candle patterns
- **Phase 5** — `PredictionEngine`: weighted scoring, confidence, NO-TRADE state
- **Phase 6** — AI backend + `AiAnalysisProvider`, structured request/response
- **Phase 7** — Room prediction journal, outcome evaluation, accuracy analytics
- **Phase 8** — Replay/backtest mode, look-ahead-bias prevention tests
- **Phase 9** — Battery/performance tuning, accessibility, polish

Recommended next step: Phase 4 (`TechnicalAnalysisEngine`) is pure Kotlin with no
Android dependency, so it can be built and fully unit-tested (RSI/MACD/EMA/ATR
against synthetic candle data) without needing a device at all — a good next
milestone if you want to keep making verifiable progress before tackling the
harder, device-dependent CV work in Phase 2.
