package com.chartlens.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.chartlens.ai.common.CaptureState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@Composable
fun DashboardScreen(
    state: CaptureState,
    onStartClick: () -> Unit,
    onStopClick: () -> Unit
) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "ChartLens AI",
                style = MaterialTheme.typography.headlineMedium
            )
            Text(
                text = "Real-time chart analysis assistant",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            StatusCard(state)

            Spacer(modifier = Modifier.height(24.dp))

            val isRunning = state is CaptureState.Capturing || state is CaptureState.AwaitingPermission

            if (isRunning) {
                OutlinedButton(
                    onClick = onStopClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Stop Analysis")
                }
            } else {
                Button(
                    onClick = onStartClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start Analysis")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Analysis/decision-support only. ChartLens AI never places trades " +
                    "or interacts with buttons on your screen.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun StatusCard(state: CaptureState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Status", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(6.dp))
            when (state) {
                is CaptureState.Idle ->
                    Text("Not analyzing. Tap Start Analysis to begin.")

                is CaptureState.AwaitingPermission ->
                    Text("Waiting for screen-capture permission…")

                is CaptureState.Capturing -> Column {
                    Text("Capturing — ${state.frameWidth}×${state.frameHeight}px")
                    Text("Frames analyzed: ${state.analyzedFrameCount} / ${state.capturedFrameCount} captured")
                    Text("Running for ${formatDuration(state.startedAtMillis)}")
                    Text("Last frame: ${formatTime(state.lastFrameAtMillis)}")
                }

                is CaptureState.Stopped ->
                    Text("Analysis stopped.")

                is CaptureState.Error -> Column {
                    Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
                    if (state.recoverable) {
                        Text(
                            "You can try Start Analysis again.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

private fun formatDuration(startedAtMillis: Long): String {
    val elapsedMs = (System.currentTimeMillis() - startedAtMillis).coerceAtLeast(0)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(elapsedMs)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(elapsedMs) % 60
    return if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"
}

private fun formatTime(millis: Long): String {
    if (millis <= 0) return "—"
    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return formatter.format(Date(millis))
}
