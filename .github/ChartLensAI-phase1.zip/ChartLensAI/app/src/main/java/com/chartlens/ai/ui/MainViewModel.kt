package com.chartlens.ai.ui

import androidx.lifecycle.ViewModel
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    captureStateRepository: CaptureStateRepository
) : ViewModel() {

    val captureState: StateFlow<CaptureState> = captureStateRepository.state
}
