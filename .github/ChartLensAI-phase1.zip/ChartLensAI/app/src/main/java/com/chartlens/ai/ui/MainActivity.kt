package com.chartlens.ai.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import com.chartlens.ai.overlay.OverlayService
import com.chartlens.ai.service.ScreenCaptureService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Hosts the Compose dashboard and owns every permission request that only an
 * Activity context can make (POST_NOTIFICATIONS, SYSTEM_ALERT_WINDOW settings screen,
 * MediaProjectionManager's screen-capture consent dialog). Once all three are
 * satisfied, it hands off to [ScreenCaptureService] and [OverlayService] and gets
 * out of the way — this Activity is not part of the capture pipeline itself.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var captureStateRepository: CaptureStateRepository

    private val viewModel: MainViewModel by viewModels()

    private lateinit var mediaProjectionManager: MediaProjectionManager

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Proceed regardless of grant — the foreground service still functions without
        // POST_NOTIFICATIONS on most OEMs, it just won't show the persistent notification,
        // which the user will notice and can fix in system settings.
        proceedToOverlayPermission()
    }

    private val overlaySettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        if (Settings.canDrawOverlays(this)) {
            proceedToProjectionRequest()
        } else {
            captureStateRepository.update(
                CaptureState.Error(
                    "Overlay permission is required to show live analysis on top of your trading app",
                    recoverable = true
                )
            )
        }
    }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            ScreenCaptureService.start(this, result.resultCode, data)
            OverlayService.start(this)
        } else {
            captureStateRepository.update(
                CaptureState.Error("Screen-capture permission was not granted", recoverable = true)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mediaProjectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        setContent {
            MaterialTheme {
                val state by viewModel.captureState.collectAsState()
                DashboardScreen(
                    state = state,
                    onStartClick = ::beginStartSequence,
                    onStopClick = ::stopAnalysis
                )
            }
        }
    }

    private fun beginStartSequence() {
        captureStateRepository.update(CaptureState.AwaitingPermission)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            proceedToOverlayPermission()
        }
    }

    private fun proceedToOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            proceedToProjectionRequest()
        } else {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
        }
    }

    private fun proceedToProjectionRequest() {
        projectionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun stopAnalysis() {
        ScreenCaptureService.stop(this)
        OverlayService.stop(this)
    }
}
