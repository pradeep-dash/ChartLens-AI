package com.chartlens.ai.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [PredictionEntity::class], version = 1, exportSchema = false)
abstract class ChartLensDatabase : RoomDatabase() {
    abstract fun predictionDao(): PredictionDao
}
