package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.ocr.OcrTextBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TimeframeDetectorTest {

    private val detector = TimeframeDetector()

    private fun candle(index: Int, xStart: Int, isForming: Boolean = false) = Candle(
        index = index,
        xStart = xStart,
        xEnd = xStart + 20,
        bodyTopY = 10,
        bodyBottomY = 20,
        wickTopY = 5,
        wickBottomY = 25,
        direction = CandleDirection.BULLISH,
        isForming = isForming,
        confidence = 1f
    )

    @Test
    fun `matching pixel spacing to a known interval detects the timeframe exactly`() {
        // 0.02 minutes (1.2 seconds) per pixel (10:00 at x=0, 10:10 at x=500), candles
        // spaced exactly 50px apart -> 1.2 * 50 = 60 seconds per candle -> exact M1 match.
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val candles = listOf(
            candle(0, xStart = 0),
            candle(1, xStart = 50),
            candle(2, xStart = 100),
            candle(3, xStart = 150),
            candle(4, xStart = 200, isForming = true)
        )

        val result = detector.detect(timeLabels, candles)

        assertEquals(Timeframe.M1, result.timeframe)
        assertEquals(60.0, result.estimatedSecondsPerCandle!!, 1e-6)
    }

    @Test
    fun `an estimate that falls between two known intervals returns null timeframe but keeps the estimate`() {
        // Same 1.2 sec/px, candles spaced 150px apart -> 180 sec/candle, which is too
        // far from both M1 (60s) and M5 (300s) to confidently snap to either.
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val candles = listOf(
            candle(0, xStart = 0),
            candle(1, xStart = 150),
            candle(2, xStart = 300),
            candle(3, xStart = 450, isForming = true)
        )

        val result = detector.detect(timeLabels, candles)

        assertNull(result.timeframe)
        assertNotNull("the estimate should still be surfaced even when unmatched", result.estimatedSecondsPerCandle)
        assertEquals(180.0, result.estimatedSecondsPerCandle!!, 1e-6)
    }

    @Test
    fun `fewer than two time labels yields no result`() {
        val candles = listOf(candle(0, 0), candle(1, 50), candle(2, 100, isForming = true))
        val result = detector.detect(listOf(OcrTextBlock("10:00", 0, 0)), candles)
        assertNull(result.timeframe)
        assertNull(result.estimatedSecondsPerCandle)
    }

    @Test
    fun `fewer than two closed candles yields no result`() {
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val result = detector.detect(timeLabels, listOf(candle(0, 0, isForming = true)))
        assertNull(result.timeframe)
    }

    @Test
    fun `a single badly misread time label among clean ones is detected and removed`() {
        // Regression test for a real device failure: TimeframeDetector reported 15m on a
        // chart that was actually 1m — a ~15x error a single bad OCR reading could plausibly
        // cause, and this class originally had zero outlier tolerance, unlike PriceScaleMapper.
        // 5 labels lie exactly on y=600+0.02x; one at x=400 is badly wrong (placed at a middle
        // X position deliberately — an outlier at an extreme X position gets disproportionate
        // regression leverage and paradoxically becomes harder to detect via residuals).
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),   // 600 min
            OcrTextBlock("10:04", centerX = 200, centerY = 0), // 604 min
            OcrTextBlock("23:20", centerX = 400, centerY = 0), // 1400 min — badly wrong
            OcrTextBlock("10:12", centerX = 600, centerY = 0), // 612 min
            OcrTextBlock("10:16", centerX = 800, centerY = 0), // 616 min
            OcrTextBlock("10:20", centerX = 1000, centerY = 0) // 620 min
        )
        val candles = listOf(
            candle(0, xStart = 0), candle(1, xStart = 50), candle(2, xStart = 100),
            candle(3, xStart = 150), candle(4, xStart = 200, isForming = true)
        )

        val result = detector.detect(timeLabels, candles)

        assertEquals(Timeframe.M1, result.timeframe)
    }

    @Test
    fun `a single anomalous candle-spacing gap does not skew the estimate the way a mean would`() {
        // A momentarily-missed candle creates one double-width gap; median spacing shrugs
        // it off, a mean-based calculation (the original implementation) would not.
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val candles = listOf(
            candle(0, xStart = 0), candle(1, xStart = 50), candle(2, xStart = 100),
            candle(3, xStart = 150), candle(4, xStart = 350), // one anomalous 200px gap here
            candle(5, xStart = 400, isForming = true)
        )

        val result = detector.detect(timeLabels, candles)

        assertEquals(Timeframe.M1, result.timeframe)
    }

    // --- Sub-minute Timeframe support (data model only — see Timeframe's class doc
    // comment for why TimeTextParser doesn't yet feed real seconds-precision OCR data
    // through this detector; these test the enum/formatting layer directly) ---------

    @Test
    fun `nearestOrNull snaps a confident estimate to S15`() {
        assertEquals(Timeframe.S15, Timeframe.nearestOrNull(15.0))
    }

    @Test
    fun `nearestOrNull snaps a confident estimate to S30`() {
        assertEquals(Timeframe.S30, Timeframe.nearestOrNull(30.0))
    }

    @Test
    fun `nearestOrNull does not confuse S15 and S30 for each other`() {
        // 22.5s is exactly equidistant from S15 and S30 in absolute terms (7.5s either
        // way); minByOrNull resolves the tie to S15 (first in declaration order), and
        // even then the relative error (7.5/15 = 0.5) exceeds the 0.25 tolerance — so
        // this correctly lands in the dead zone rather than guessing at whichever
        // happened to win the tie-break.
        assertNull(Timeframe.nearestOrNull(22.5))
    }

    @Test
    fun `displayLabel formats sub-minute, minute, and hour scale timeframes correctly`() {
        assertEquals("15s", Timeframe.S15.displayLabel())
        assertEquals("30s", Timeframe.S30.displayLabel())
        assertEquals("1m", Timeframe.M1.displayLabel())
        assertEquals("5m", Timeframe.M5.displayLabel())
        assertEquals("1h", Timeframe.H1.displayLabel())
    }
}
