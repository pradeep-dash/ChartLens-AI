# Debug keystore — deliberately committed

This is a fixed, checked-in debug-only signing key. It is **not** a secret
the way a release signing key is, and committing it is intentional — see
`app/build.gradle.kts`'s `signingConfigs` block for the full explanation.

**The problem this solves**: without a fixed keystore, every CI build
signs the debug APK with a different, randomly-generated key (a fresh
GitHub Actions runner has no pre-existing `~/.android/debug.keystore`, so
Android Gradle Plugin generates a new one from scratch every single run).
Android refuses to install an update over an app signed with a different
key, which meant every new build required uninstalling the app first
before reinstalling.

With this file committed and referenced explicitly in `signingConfigs`,
every build — on any machine, any CI runner — signs with the same key,
and normal in-place updates work as expected.

**Standard convention, nothing custom**: alias `androiddebugkey`, password
`android` for both the store and the key — the same defaults Android
Studio's own auto-generated debug keystore has always used. Valid until
2054.

**Do not use this for a release build.** A real release keystore is a
genuine secret (losing it means you can never update a published app
under the same signature) and must never be committed — see the
`.gitignore` entry immediately above the exception that allows this
specific file through.
