# ChartLens AI — reference backend

This is the piece the app deliberately doesn't contain: the real LLM
provider API key. The Android app never talks to Anthropic directly — it
talks to this backend, which holds the key server-side and does the actual
LLM call.

**There is no hosted default.** You must deploy this yourself.

## What this does

- Receives a small, structured JSON summary of the current chart state
  (trend, momentum, RSI, MACD, support/resistance, the local prediction
  engine's own bias) — never a screenshot, never raw price history.
- Builds a prompt encoding the spec's rules (never invent price levels,
  never claim certainty, prefer "no clear setup" over a fabricated call) and
  sends it to Claude.
- Validates the model's JSON response server-side before returning it —
  rejects anything malformed, out of range, or referencing a price level
  that isn't one of the ones actually supplied in the request.
- Checks a bearer-token auth header and applies basic per-IP rate limiting.

## Deploying it (free-tier friendly)

Any Node.js host works. Render, Railway, and Fly.io all have free tiers
suitable for personal use. Rough steps for any of them:

1. Push this `backend/` folder to its own Git repo (or a subfolder of one).
2. Create a new Web Service on your chosen platform, pointing at that repo.
3. Set the **start command** to `npm start` (or `node server.js`).
4. Set these **environment variables** in the platform's dashboard (never in
   code, never committed):
   - `ANTHROPIC_API_KEY` — your real Anthropic key
   - `CLIENT_AUTH_TOKEN` — a secret you make up (e.g. generate a long random
     string) — this is what goes in the app's "Auth token" field
5. Deploy. Note the public URL the platform gives you (e.g.
   `https://your-service.onrender.com`).
6. In the ChartLens AI app: **AI Backend Settings** → enter that URL as
   "Backend URL" and the same token as "Auth token" → Save.

The app will now call `POST <your-url>/v1/analyze` whenever a candle closes
with a real (non-NO_TRADE) local prediction.

## Known limitations — read before relying on this for anything beyond personal use

- **Rate limiting is in-memory and per-process.** It resets on every restart
  and doesn't share state across multiple instances. Fine for one person's
  phone hitting one server instance; not fine behind a load balancer or for
  multiple users. A real deployment would want a shared store (Redis, etc.)
  instead.
- **No persistent request logging or monitoring** beyond `console.error` —
  whatever your hosting platform captures from stdout/stderr is all you get.
- **No retry/backoff logic** for transient Anthropic API failures — a failed
  call just returns an error to the app, which shows "AI backend
  unavailable" and otherwise keeps working fine (Phase 5's local prediction
  never depends on this backend at all).
- **Single shared auth token**, not per-user accounts — appropriate for
  "just my own phone talks to my own backend," not a multi-user product.
- This has **not been run or tested** in the environment that wrote it (no
  network access, no Node runtime available there) — reviewed carefully by
  hand, but genuinely unverified until you actually deploy and hit it from
  the app.
