// ChartLens AI — reference backend.
//
// This is the piece the spec requires and the Android app deliberately does
// NOT contain: the actual LLM provider API key. Deploy this yourself
// (Render/Railway/Fly.io all have free tiers suitable for personal use) and
// point the app's "AI Backend Settings" screen at wherever you deploy it.
//
// Required environment variables (set these on your hosting platform, never
// commit them to source control):
//   ANTHROPIC_API_KEY   - your real Anthropic API key
//   CLIENT_AUTH_TOKEN    - a secret you make up; must match what you enter
//                          in the app's "Auth token" field
//
// This is a reference implementation for a personal/single-user deployment,
// not a production-hardened service — see README.md in this directory for
// the honest list of what's simplified here (in-memory rate limiting that
// resets on restart, no persistent request logging, etc.) and what you'd
// want to change before exposing this to more than one user.

const express = require('express');

const app = express();
app.use(express.json({ limit: '32kb' })); // structured market state is small; reject anything larger outright

const PORT = process.env.PORT || 3000;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const CLIENT_AUTH_TOKEN = process.env.CLIENT_AUTH_TOKEN;
const ANTHROPIC_MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5-20250929';

if (!ANTHROPIC_API_KEY) {
  console.error('FATAL: ANTHROPIC_API_KEY is not set. Refusing to start.');
  process.exit(1);
}
if (!CLIENT_AUTH_TOKEN) {
  console.error('FATAL: CLIENT_AUTH_TOKEN is not set. Refusing to start.');
  process.exit(1);
}

// --- Minimal in-memory rate limiting -----------------------------------
// A simple fixed-window counter per IP. Resets on process restart and does
// not share state across multiple server instances — genuinely fine for a
// personal single-user deployment, genuinely not fine if you ever put this
// behind a load balancer with multiple instances or open it to more users.
// See README.md for what a real deployment would need instead (Redis-backed
// limiter, etc.).
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX_REQUESTS = 20;
const requestCounts = new Map(); // ip -> { count, windowStart }

function isRateLimited(ip) {
  const now = Date.now();
  const entry = requestCounts.get(ip);
  if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    requestCounts.set(ip, { count: 1, windowStart: now });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT_MAX_REQUESTS;
}

// --- Auth ----------------------------------------------------------------
function checkAuth(req, res, next) {
  const header = req.get('Authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (token !== CLIENT_AUTH_TOKEN) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

// --- Request payload validation ------------------------------------------
// Mirrors the shape the Android client's AiAnalysisRequest sends. Rejects
// anything malformed outright rather than passing it through to the LLM —
// per the spec's "validate payloads" requirement for the backend.
function validateRequestBody(body) {
  const errors = [];
  const isString = (v) => typeof v === 'string';
  const isNumberOrNull = (v) => v === null || v === undefined || typeof v === 'number';
  const isNumberArray = (v) => Array.isArray(v) && v.every((x) => typeof x === 'number');

  if (!isString(body.instrument)) errors.push('instrument must be a string');
  if (!isString(body.timeframe)) errors.push('timeframe must be a string');
  if (!isString(body.trend)) errors.push('trend must be a string');
  if (typeof body.trendStrength !== 'number') errors.push('trendStrength must be a number');
  if (!isString(body.momentum)) errors.push('momentum must be a string');
  if (!isNumberArray(body.support)) errors.push('support must be a number array');
  if (!isNumberArray(body.resistance)) errors.push('resistance must be a number array');
  if (!isNumberOrNull(body.rsi)) errors.push('rsi must be a number or null');
  if (!isNumberOrNull(body.macdHistogram)) errors.push('macdHistogram must be a number or null');
  if (!isString(body.emaAlignment)) errors.push('emaAlignment must be a string');
  if (body.currentPattern !== null && body.currentPattern !== undefined && !isString(body.currentPattern)) {
    errors.push('currentPattern must be a string or null');
  }
  if (!isString(body.predictionEngineBias)) errors.push('predictionEngineBias must be a string');
  if (typeof body.modelConfidence !== 'number') errors.push('modelConfidence must be a number');
  if (!isString(body.dataQuality)) errors.push('dataQuality must be a string');

  return errors;
}

// --- Response validation (server-side defense in depth) ------------------
// The Android client validates too (AiResponseValidator.kt) — this is not
// redundant: never trust a single layer, and a malformed/fabricated response
// should be caught and logged here even if the client-side check would also
// catch it, so server logs reflect real LLM behavior over time.
const VALID_BIASES = new Set(['BULLISH', 'BEARISH', 'NO_CLEAR_SETUP']);
const VALID_DATA_QUALITY = new Set(['GOOD', 'FAIR', 'POOR', 'INVALID']);

function validateModelResponse(parsed, requestBody) {
  if (!parsed || typeof parsed !== 'object') return null;
  if (!VALID_BIASES.has(parsed.bias)) return null;
  if (typeof parsed.confidence !== 'number' || parsed.confidence < 0 || parsed.confidence > 100) return null;
  if (!VALID_DATA_QUALITY.has(parsed.dataQuality)) return null;
  if (!Array.isArray(parsed.reasoning) || parsed.reasoning.length === 0 || parsed.reasoning.length > 6) return null;
  if (parsed.reasoning.some((r) => typeof r !== 'string' || r.trim().length === 0 || r.length > 300)) return null;
  if (parsed.bias === 'NO_CLEAR_SETUP' && parsed.confidence > 50) return null;

  const knownLevels = [...(requestBody.support || []), ...(requestBody.resistance || [])];
  const isPlausibleLevel = (level) => {
    if (level === null || level === undefined) return true;
    if (typeof level !== 'number') return false;
    if (knownLevels.length === 0) return false;
    const closest = knownLevels.reduce((a, b) => (Math.abs(b - level) < Math.abs(a - level) ? b : a));
    if (closest === 0) return level === 0;
    return Math.abs(level - closest) / Math.abs(closest) <= 0.05;
  };
  if (!isPlausibleLevel(parsed.keyLevel)) return null;
  if (!isPlausibleLevel(parsed.invalidationLevel)) return null;

  return {
    bias: parsed.bias,
    confidence: parsed.confidence,
    setup: typeof parsed.setup === 'string' ? parsed.setup : null,
    keyLevel: typeof parsed.keyLevel === 'number' ? parsed.keyLevel : null,
    invalidationLevel: typeof parsed.invalidationLevel === 'number' ? parsed.invalidationLevel : null,
    reasoning: parsed.reasoning,
    dataQuality: parsed.dataQuality,
  };
}

// --- Prompt construction ---------------------------------------------------
// Encodes the spec's exact behavioral rules for the AI reasoning layer
// (§13): explain strongest evidence, identify conflicts, never invent
// indicators/price levels, never claim certainty or guaranteed profit, prefer
// NO_CLEAR_SETUP over fabricated confidence. The model receives ONLY the
// structured JSON below — never a screenshot, never raw price history beyond
// what's already been distilled into this summary.
function buildPrompt(body) {
  return `You are a technical-analysis assistant. You will be given a JSON object describing the current state of a live candlestick chart, already computed by a local, deterministic pipeline (trend detection, momentum, RSI, MACD, support/resistance, candle patterns, and a local prediction engine's own directional bias).

Your job is ONLY to interpret and explain this data — you cannot see the chart, you were not given raw price history, and you must never invent indicator values, price levels, or patterns that are not present in the JSON below.

Rules you must follow exactly:
1. Explain the strongest evidence for the prediction engine's bias, using only fields present in the JSON.
2. Identify any conflicting evidence, if present.
3. If you reference a support/resistance level, it MUST be one of the numbers already listed in "support" or "resistance" below — never a number you calculate or estimate yourself.
4. Never claim certainty. Never claim or imply guaranteed profit.
5. If the data quality is POOR or INVALID, or if the evidence in the JSON is weak or contradictory, you MUST return bias "NO_CLEAR_SETUP" rather than forcing a directional call.
6. Do not override or contradict the provided dataQuality field — treat it as ground truth about how reliable this data is.

Market state:
${JSON.stringify(body, null, 2)}

Respond with ONLY a single JSON object (no markdown code fences, no other text) matching exactly this shape:
{
  "bias": "BULLISH" | "BEARISH" | "NO_CLEAR_SETUP",
  "confidence": <integer 0-100, a heuristic score, never call it a "probability" in your reasoning text>,
  "setup": <short snake_case string describing the setup type, or null>,
  "keyLevel": <a number taken directly from the support/resistance arrays above, or null>,
  "invalidationLevel": <a number taken directly from the support/resistance arrays above, or null>,
  "reasoning": [<1 to 4 short strings explaining your reasoning>],
  "dataQuality": "GOOD" | "FAIR" | "POOR" | "INVALID"
}`;
}

function extractJson(text) {
  // Strip markdown code fences if the model added them despite instructions not to.
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  const candidate = fenced ? fenced[1] : text;
  try {
    return JSON.parse(candidate);
  } catch (e) {
    return null;
  }
}

async function callAnthropic(prompt) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: 600,
      messages: [{ role: 'user', content: prompt }],
    }),
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(`Anthropic API error ${response.status}: ${errorText}`);
  }

  const data = await response.json();
  const textBlock = (data.content || []).find((block) => block.type === 'text');
  if (!textBlock) throw new Error('Anthropic response had no text content');
  return textBlock.text;
}

// --- Routes ----------------------------------------------------------------
app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.post('/v1/analyze', checkAuth, async (req, res) => {
  const ip = req.ip || 'unknown';
  if (isRateLimited(ip)) {
    return res.status(429).json({ error: 'rate limit exceeded' });
  }

  const validationErrors = validateRequestBody(req.body || {});
  if (validationErrors.length > 0) {
    return res.status(400).json({ error: 'invalid request', details: validationErrors });
  }

  try {
    const prompt = buildPrompt(req.body);
    const rawText = await callAnthropic(prompt);
    const parsed = extractJson(rawText);
    const validated = validateModelResponse(parsed, req.body);

    if (!validated) {
      console.error('Model response failed validation, discarding:', rawText);
      return res.status(502).json({ error: 'model returned an invalid or unvalidatable response' });
    }

    return res.json(validated);
  } catch (err) {
    console.error('Error handling /v1/analyze:', err);
    return res.status(500).json({ error: 'internal error' });
  }
});

app.listen(PORT, () => {
  console.log(`ChartLens AI backend listening on port ${PORT}`);
});
