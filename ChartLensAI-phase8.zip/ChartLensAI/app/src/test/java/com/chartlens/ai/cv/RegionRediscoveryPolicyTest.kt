package com.chartlens.ai.cv

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RegionRediscoveryPolicyTest {

    private val policy = RegionRediscoveryPolicy(rediscoverEveryNFrames = 20, minCandlesBeforeForcedRediscovery = 5)

    @Test
    fun `with no cached region at all, always rediscover`() {
        assertTrue(policy.shouldRediscover(hasCachedRegion = false, framesSinceRediscovery = 0, lastCandleCount = 40))
    }

    @Test
    fun `a healthy cached region within its interval is reused, not re-detected`() {
        assertFalse(policy.shouldRediscover(hasCachedRegion = true, framesSinceRediscovery = 5, lastCandleCount = 40))
    }

    @Test
    fun `the normal interval still forces rediscovery even when the region is working fine`() {
        assertTrue(policy.shouldRediscover(hasCachedRegion = true, framesSinceRediscovery = 20, lastCandleCount = 40))
    }

    @Test
    fun `a cached region that has stopped producing candles is re-detected immediately`() {
        // The actual bug this exists for: previously this would keep serving the broken
        // cached region for the full 20-frame interval, and re-cache a similar one after,
        // leaving the count stuck at 0/1 for an entire session.
        assertTrue(policy.shouldRediscover(hasCachedRegion = true, framesSinceRediscovery = 3, lastCandleCount = 0))
        assertTrue(policy.shouldRediscover(hasCachedRegion = true, framesSinceRediscovery = 3, lastCandleCount = 4))
    }

    @Test
    fun `a region is never judged by the very frame it was detected on`() {
        // At framesSinceRediscovery == 0, lastCandleCount still describes the PREVIOUS
        // region's outcome — judging the new region on it would cause endless re-detection.
        assertFalse(policy.shouldRediscover(hasCachedRegion = true, framesSinceRediscovery = 0, lastCandleCount = 0))
    }

    @Test
    fun `a count at or above the threshold does not trigger forced rediscovery`() {
        assertFalse(policy.shouldRediscover(hasCachedRegion = true, framesSinceRediscovery = 3, lastCandleCount = 5))
    }
}
