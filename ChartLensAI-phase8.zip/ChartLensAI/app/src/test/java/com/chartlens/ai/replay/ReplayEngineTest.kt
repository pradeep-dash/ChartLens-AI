package com.chartlens.ai.replay

import com.chartlens.ai.database.CandleHistoryEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class ReplayEngineTest {

    private val engine = ReplayEngine()

    private fun candle(sessionId: Long, index: Int, close: Double) = CandleHistoryEntity(
        sessionId = sessionId,
        candleIndex = index,
        timestampMillis = index * 60_000L,
        open = close - 0.0005,
        high = close + 0.0008,
        low = close - 0.0012,
        close = close,
        direction = "BULLISH",
        upperWickPx = 2,
        lowerWickPx = 2,
        patterns = "",
        timeframeLabel = "1m",
        instrument = "TEST"
    )

    /** A gently oscillating uptrend, not a pure monotonic line — real up-and-down
     * movement keeps RSI in a moderate range instead of pinning near 100 from
     * never having a single down candle, which a perfectly straight line would do. */
    private fun oscillatingPrice(index: Int, driftPerCandle: Double = 0.0008): Double =
        1.0000 + index * driftPerCandle + 0.0015 * sin(index * 0.9)

    /**
     * The centerpiece test for this whole phase. Two histories are byte-for-byte
     * identical for indices 0..39, then diverge sharply — history A keeps its
     * gentle uptrend, history B crashes. If [ReplayEngine] ever let a later
     * candle influence an earlier step's prediction, this test would catch it:
     * every step whose candleIndex is within the shared prefix (<=39) must be
     * an exact match between the two runs, regardless of what happens after.
     */
    @Test
    fun `identical histories through a point produce identical predictions at every step through that point`() {
        val sessionIdA = 1L
        val sessionIdB = 2L
        val sharedPrefixEnd = 39 // indices 0..39 identical between A and B

        val historyA = (0..49).map { i ->
            val price = if (i <= sharedPrefixEnd) oscillatingPrice(i) else oscillatingPrice(i)
            candle(sessionIdA, i, price)
        }

        val historyB = (0..49).map { i ->
            val price = if (i <= sharedPrefixEnd) {
                oscillatingPrice(i)
            } else {
                // B crashes hard right after the shared prefix.
                oscillatingPrice(sharedPrefixEnd) - (i - sharedPrefixEnd) * 0.0100
            }
            candle(sessionIdB, i, price)
        }

        val resultA = engine.replay(sessionIdA, historyA)
        val resultB = engine.replay(sessionIdB, historyB)

        val sharedStepsA = resultA.steps.filter { it.candleIndex <= sharedPrefixEnd }
        val sharedStepsB = resultB.steps.filter { it.candleIndex <= sharedPrefixEnd }

        assertTrue(
            "expected at least one real (non-NO_TRADE) prediction within the shared prefix to compare " +
                "— if this fails, the synthetic price pattern needs adjusting, not necessarily a sign " +
                "of a real bug (see test file comment)",
            sharedStepsA.isNotEmpty()
        )
        assertEquals(sharedStepsA.size, sharedStepsB.size)

        sharedStepsA.zip(sharedStepsB).forEach { (stepA, stepB) ->
            assertEquals("candleIndex should match", stepA.candleIndex, stepB.candleIndex)
            assertEquals("prediction direction must be identical", stepA.prediction.direction, stepB.prediction.direction)
            assertEquals(
                "prediction confidence must be identical",
                stepA.prediction.modelConfidence,
                stepB.prediction.modelConfidence
            )
            assertEquals("entry price must be identical", stepA.entryPrice, stepB.entryPrice, 0.0)
        }
    }

    @Test
    fun `too few candles produces no steps at all`() {
        val history = (0 until 10).map { i -> candle(1L, i, oscillatingPrice(i)) }
        val result = engine.replay(1L, history)
        assertTrue(result.steps.isEmpty())
    }

    @Test
    fun `replay stops rather than guessing when there is no future candle left to evaluate against`() {
        // 25 candles, horizon=1 -> the last possible step is at index 23 (needs index 24 to evaluate).
        // Index 24 itself can never be a step, since there's nothing after it to check against.
        val history = (0 until 25).map { i -> candle(1L, i, oscillatingPrice(i)) }
        val result = engine.replay(1L, history)

        assertEquals(25, result.totalCandlesInSession)
        assertTrue(result.steps.all { it.candleIndex < 24 })
    }

    @Test
    fun `accuracy stats account for exactly the steps that were produced`() {
        val history = (0 until 40).map { i -> candle(1L, i, oscillatingPrice(i)) }
        val result = engine.replay(1L, history)

        val accountedFor = result.accuracyStats.wins + result.accuracyStats.losses +
            result.accuracyStats.neutral + result.accuracyStats.invalidData + result.accuracyStats.unresolved
        assertEquals(result.steps.size, accountedFor)
    }
}
