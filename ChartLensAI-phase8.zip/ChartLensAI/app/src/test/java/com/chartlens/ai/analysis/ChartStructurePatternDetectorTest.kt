package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChartStructurePatternDetectorTest {

    private val detector = ChartStructurePatternDetector()

    private fun swing(index: Int, price: Double, type: SwingType) = SwingPoint(index, price, type)

    private fun matchOf(pattern: ChartStructurePattern, highs: List<SwingPoint>, lows: List<SwingPoint>): ChartStructureMatch? =
        detector.detect(highs, lows).find { it.pattern == pattern }

    // --- Double Top ---------------------------------------------------------

    @Test
    fun `two nearly-equal peaks with a real valley between them is a clean double top`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(10, 100.0, SwingType.HIGH))
        val lows = listOf(swing(5, 90.0, SwingType.LOW))

        val match = matchOf(ChartStructurePattern.DOUBLE_TOP, highs, lows)

        assertEquals(1.0f, match!!.confidence, 0.001f)
    }

    @Test
    fun `peaks too far apart in price are not a double top`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(10, 110.0, SwingType.HIGH))
        val lows = listOf(swing(5, 90.0, SwingType.LOW))
        assertNull(matchOf(ChartStructurePattern.DOUBLE_TOP, highs, lows))
    }

    @Test
    fun `two equal peaks with no valley between them are not a double top`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(10, 100.0, SwingType.HIGH))
        assertNull(matchOf(ChartStructurePattern.DOUBLE_TOP, highs, emptyList()))
    }

    @Test
    fun `peaks too close together in time are not a double top`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(2, 100.0, SwingType.HIGH))
        val lows = listOf(swing(1, 90.0, SwingType.LOW))
        assertNull(matchOf(ChartStructurePattern.DOUBLE_TOP, highs, lows))
    }

    // --- Double Bottom -------------------------------------------------------

    @Test
    fun `two nearly-equal troughs with a real peak between them is a clean double bottom`() {
        val lows = listOf(swing(0, 100.0, SwingType.LOW), swing(10, 100.0, SwingType.LOW))
        val highs = listOf(swing(5, 110.0, SwingType.HIGH))

        val match = matchOf(ChartStructurePattern.DOUBLE_BOTTOM, highs, lows)

        assertEquals(1.0f, match!!.confidence, 0.001f)
    }

    // --- Head and Shoulders ----------------------------------------------------

    @Test
    fun `a clearly higher middle peak with matching shoulders and neckline is head and shoulders`() {
        val highs = listOf(
            swing(0, 100.0, SwingType.HIGH),
            swing(5, 110.0, SwingType.HIGH),
            swing(10, 100.0, SwingType.HIGH)
        )
        val lows = listOf(swing(2, 95.0, SwingType.LOW), swing(7, 95.0, SwingType.LOW))

        val match = matchOf(ChartStructurePattern.HEAD_AND_SHOULDERS, highs, lows)

        assertEquals(1.0f, match!!.confidence, 0.001f)
    }

    @Test
    fun `a middle peak that is not actually higher than both shoulders is not head and shoulders`() {
        val highs = listOf(
            swing(0, 100.0, SwingType.HIGH),
            swing(5, 100.0, SwingType.HIGH), // "head" no higher than either shoulder
            swing(10, 100.0, SwingType.HIGH)
        )
        val lows = listOf(swing(2, 95.0, SwingType.LOW), swing(7, 95.0, SwingType.LOW))
        assertNull(matchOf(ChartStructurePattern.HEAD_AND_SHOULDERS, highs, lows))
    }

    @Test
    fun `fewer than three swing highs cannot form head and shoulders`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(5, 110.0, SwingType.HIGH))
        assertNull(matchOf(ChartStructurePattern.HEAD_AND_SHOULDERS, highs, emptyList()))
    }

    // --- Inverse Head and Shoulders ---------------------------------------------

    @Test
    fun `a clearly lower middle trough with matching shoulders and neckline is inverse head and shoulders`() {
        val lows = listOf(
            swing(0, 100.0, SwingType.LOW),
            swing(5, 90.0, SwingType.LOW),
            swing(10, 100.0, SwingType.LOW)
        )
        val highs = listOf(swing(2, 105.0, SwingType.HIGH), swing(7, 105.0, SwingType.HIGH))

        val match = matchOf(ChartStructurePattern.INVERSE_HEAD_AND_SHOULDERS, highs, lows)

        assertEquals(1.0f, match!!.confidence, 0.001f)
    }

    // --- Triangles -------------------------------------------------------------

    @Test
    fun `flat highs with rising lows is an ascending triangle`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(5, 100.0, SwingType.HIGH), swing(10, 100.0, SwingType.HIGH))
        val lows = listOf(swing(0, 90.0, SwingType.LOW), swing(5, 95.0, SwingType.LOW), swing(10, 100.0, SwingType.LOW))

        val match = matchOf(ChartStructurePattern.ASCENDING_TRIANGLE, highs, lows)

        assertEquals(0.5f, match!!.confidence, 0.001f)
    }

    @Test
    fun `falling highs with flat lows is a descending triangle`() {
        val highs = listOf(swing(0, 110.0, SwingType.HIGH), swing(5, 105.0, SwingType.HIGH), swing(10, 100.0, SwingType.HIGH))
        val lows = listOf(swing(0, 90.0, SwingType.LOW), swing(5, 90.0, SwingType.LOW), swing(10, 90.0, SwingType.LOW))

        assertEquals(ChartStructurePattern.DESCENDING_TRIANGLE, matchOf(ChartStructurePattern.DESCENDING_TRIANGLE, highs, lows)?.pattern)
    }

    @Test
    fun `falling highs with rising lows is a symmetrical triangle`() {
        val highs = listOf(swing(0, 110.0, SwingType.HIGH), swing(5, 105.0, SwingType.HIGH), swing(10, 100.0, SwingType.HIGH))
        val lows = listOf(swing(0, 90.0, SwingType.LOW), swing(5, 95.0, SwingType.LOW), swing(10, 100.0, SwingType.LOW))

        assertEquals(
            ChartStructurePattern.SYMMETRICAL_TRIANGLE,
            matchOf(ChartStructurePattern.SYMMETRICAL_TRIANGLE, highs, lows)?.pattern
        )
    }

    @Test
    fun `both flat highs and lows is not any triangle`() {
        val highs = listOf(swing(0, 100.0, SwingType.HIGH), swing(5, 100.0, SwingType.HIGH), swing(10, 100.0, SwingType.HIGH))
        val lows = listOf(swing(0, 90.0, SwingType.LOW), swing(5, 90.0, SwingType.LOW), swing(10, 90.0, SwingType.LOW))

        val triangles = detector.detect(highs, lows).filter {
            it.pattern in setOf(
                ChartStructurePattern.ASCENDING_TRIANGLE,
                ChartStructurePattern.DESCENDING_TRIANGLE,
                ChartStructurePattern.SYMMETRICAL_TRIANGLE
            )
        }
        assertTrue(triangles.isEmpty())
    }

    @Test
    fun `no swing data at all produces no matches`() {
        assertTrue(detector.detect(emptyList(), emptyList()).isEmpty())
    }
}
