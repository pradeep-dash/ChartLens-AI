package com.chartlens.ai.cv

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDirection
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ViewShiftDetectorTest {

    private fun candle(wickTopY: Int, wickBottomY: Int, isForming: Boolean = false) = Candle(
        index = 0, xStart = 0, xEnd = 10,
        bodyTopY = wickTopY + 2, bodyBottomY = wickBottomY - 2,
        wickTopY = wickTopY, wickBottomY = wickBottomY,
        direction = CandleDirection.BULLISH, isForming = isForming, confidence = 1f
    )

    @Test
    fun `the first frame with data never reports a shift, having nothing to compare against`() {
        val detector = ViewShiftDetector()
        val result = detector.update(listOf(candle(100, 200)), regionTop = 0)
        assertFalse(result)
    }

    @Test
    fun `a stable, heavily-overlapping range across frames is not a shift`() {
        val detector = ViewShiftDetector()
        detector.update(listOf(candle(100, 200)), regionTop = 0)
        // Nearly identical range next frame — normal candle-to-candle progression.
        val result = detector.update(listOf(candle(98, 202)), regionTop = 0)
        assertFalse(result)
    }

    @Test
    fun `a large, non-overlapping jump in the visible range is a shift`() {
        val detector = ViewShiftDetector()
        detector.update(listOf(candle(100, 200)), regionTop = 0)
        // Completely different vertical range next frame — a real pan/zoom.
        val result = detector.update(listOf(candle(1000, 1100)), regionTop = 0)
        assertTrue(result)
    }

    @Test
    fun `a shift is still detected when the region's own top offset changes too`() {
        val detector = ViewShiftDetector()
        // Absolute range: 50..150 (regionTop 50 + candle 0..100)
        detector.update(listOf(candle(0, 100)), regionTop = 50)
        // Absolute range: 900..1000 (regionTop 900 + candle 0..100) — a real jump,
        // even though the candle's OWN relative coordinates look identical.
        val result = detector.update(listOf(candle(0, 100)), regionTop = 900)
        assertTrue(result)
    }

    @Test
    fun `only forming candles present is treated as no data, not a shift`() {
        val detector = ViewShiftDetector()
        detector.update(listOf(candle(100, 200)), regionTop = 0)
        val result = detector.update(listOf(candle(1000, 1100, isForming = true)), regionTop = 0)
        assertFalse(result)
    }

    @Test
    fun `reset clears prior state so the next frame is treated as the first again`() {
        val detector = ViewShiftDetector()
        detector.update(listOf(candle(100, 200)), regionTop = 0)
        detector.reset()
        // Would have been a huge jump if state had persisted — but reset() cleared it.
        val result = detector.update(listOf(candle(1000, 1100)), regionTop = 0)
        assertFalse(result)
    }
}
