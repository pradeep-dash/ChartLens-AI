package com.chartlens.ai.candle

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CandlePitchEstimatorTest {

    @Test
    fun `evenly spaced bars yield their spacing as the pitch`() {
        val starts = listOf(0, 12, 24, 36, 48)
        val widths = List(5) { 8 }
        assertEquals(12, CandlePitchEstimator.estimate(starts, widths))
    }

    @Test
    fun `merged runs do not corrupt the estimate, since they contribute larger multiples`() {
        // Starts 0, 12, 24 are single steps of 12; the jump from 24 to 72 is a merged run
        // spanning four pitches. A width-based estimator would be wrecked by that run's
        // width — a start-to-start estimator sees it as one large delta and ignores it.
        val starts = listOf(0, 12, 24, 72, 84)
        val widths = listOf(8, 8, 44, 8, 8)
        assertEquals(12, CandlePitchEstimator.estimate(starts, widths))
    }

    @Test
    fun `a single bar gives no pitch rather than a guess`() {
        assertNull(CandlePitchEstimator.estimate(listOf(5), listOf(100)))
    }

    @Test
    fun `no bars at all gives no pitch`() {
        assertNull(CandlePitchEstimator.estimate(emptyList(), emptyList()))
    }

    @Test
    fun `an implausibly small pitch is rejected rather than used to over-split`() {
        // 1px apart is anti-aliasing noise, not real candle spacing.
        assertNull(CandlePitchEstimator.estimate(listOf(0, 1, 2, 3), listOf(1, 1, 1, 1)))
    }

    @Test
    fun `a pitch narrower than the typical candle body is rejected as impossible`() {
        // Candles cannot overlap, so a pitch smaller than a typical body width means the
        // estimate is wrong — using it would fabricate candles.
        assertNull(CandlePitchEstimator.estimate(listOf(0, 6, 12), listOf(20, 20, 20)))
    }
}
