package com.chartlens.ai.ai

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AiResponseValidatorTest {

    private fun request(support: List<Double> = listOf(0.9870), resistance: List<Double> = listOf(1.0500)) =
        AiAnalysisRequest(
            instrument = "AUD/USD",
            timeframe = "1m",
            trend = "UPTREND",
            trendStrength = 0.8,
            momentum = "BULLISH",
            support = support,
            resistance = resistance,
            rsi = 55.0,
            macdHistogram = 0.001,
            emaAlignment = "BULLISH_ALIGNED",
            currentPattern = null,
            predictionEngineBias = "UP",
            modelConfidence = 70,
            dataQuality = "GOOD"
        )

    private fun response(
        bias: String = "BULLISH",
        confidence: Int = 64,
        keyLevel: Double? = null,
        invalidationLevel: Double? = null,
        reasoning: List<String> = listOf("Trend and momentum both bullish."),
        dataQuality: String = "GOOD"
    ) = AiAnalysisResponse(bias, confidence, "trend_continuation", keyLevel, invalidationLevel, reasoning, dataQuality)

    @Test
    fun `a well-formed response passes validation`() {
        assertNotNull(AiResponseValidator.validate(response(), request()))
    }

    @Test
    fun `an unrecognized bias value is rejected`() {
        assertNull(AiResponseValidator.validate(response(bias = "UP"), request()))
    }

    @Test
    fun `confidence outside 0 to 100 is rejected`() {
        assertNull(AiResponseValidator.validate(response(confidence = 150), request()))
        assertNull(AiResponseValidator.validate(response(confidence = -5), request()))
    }

    @Test
    fun `empty reasoning is rejected`() {
        assertNull(AiResponseValidator.validate(response(reasoning = emptyList()), request()))
    }

    @Test
    fun `too many reasoning items is rejected`() {
        val manyReasons = List(10) { "reason $it" }
        assertNull(AiResponseValidator.validate(response(reasoning = manyReasons), request()))
    }

    @Test
    fun `an unrecognized data quality value is rejected`() {
        assertNull(AiResponseValidator.validate(response(dataQuality = "PERFECT"), request()))
    }

    @Test
    fun `NO_CLEAR_SETUP with high confidence is internally inconsistent and rejected`() {
        assertNull(AiResponseValidator.validate(response(bias = "NO_CLEAR_SETUP", confidence = 80), request()))
    }

    @Test
    fun `NO_CLEAR_SETUP with low confidence is accepted`() {
        assertNotNull(AiResponseValidator.validate(response(bias = "NO_CLEAR_SETUP", confidence = 20), request()))
    }

    @Test
    fun `a key level close to a real known level is accepted`() {
        // support was 0.9870 — a value within 5% is a legitimate reference to it.
        assertNotNull(AiResponseValidator.validate(response(keyLevel = 0.9875), request()))
    }

    @Test
    fun `a fabricated key level far from any known level is rejected`() {
        // No known level anywhere near 5.0 — this must be treated as an invented price.
        assertNull(AiResponseValidator.validate(response(keyLevel = 5.0), request()))
    }

    @Test
    fun `a key level is rejected outright when the request supplied no levels at all`() {
        assertNull(
            AiResponseValidator.validate(
                response(keyLevel = 0.9870),
                request(support = emptyList(), resistance = emptyList())
            )
        )
    }

    @Test
    fun `a null key level is always acceptable`() {
        assertNotNull(AiResponseValidator.validate(response(keyLevel = null), request()))
    }
}
