package com.chartlens.ai.analytics

import com.chartlens.ai.database.PredictionEntity
import com.chartlens.ai.prediction.PredictionOutcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AccuracyAnalyticsTest {

    private fun entry(
        id: Long,
        timestampMillis: Long,
        outcome: PredictionOutcome,
        instrument: String = "AUD/USD",
        timeframe: String = "1m",
        confidence: Int = 65,
        setup: String? = "trend_continuation"
    ) = PredictionEntity(
        id = id,
        timestampMillis = timestampMillis,
        instrument = instrument,
        timeframe = timeframe,
        direction = "UP",
        modelConfidence = confidence,
        setup = setup,
        entryPrice = 1.0,
        candleIndexAtPrediction = id.toInt(),
        horizonCandles = 1,
        marketStateJson = "{}",
        outcome = outcome.name,
        evaluationTimestampMillis = if (outcome == PredictionOutcome.UNRESOLVED) null else timestampMillis + 60_000,
        evaluationPrice = if (outcome == PredictionOutcome.UNRESOLVED) null else 1.001
    )

    @Test
    fun `an empty journal produces zeroed stats and no accuracy claim`() {
        val stats = AccuracyAnalytics.compute(emptyList())
        assertEquals(0, stats.totalPredictions)
        assertNull(stats.overallAccuracyPercent)
        assertFalse(stats.hasEnoughDataForEdgeClaim)
    }

    @Test
    fun `overall accuracy counts only decisive outcomes, not neutral or invalid`() {
        val entries = listOf(
            entry(1, 1000, PredictionOutcome.WIN),
            entry(2, 2000, PredictionOutcome.WIN),
            entry(3, 3000, PredictionOutcome.LOSS),
            entry(4, 4000, PredictionOutcome.NEUTRAL),
            entry(5, 5000, PredictionOutcome.INVALID_DATA)
        )
        val stats = AccuracyAnalytics.compute(entries)

        assertEquals(66.66667f, stats.overallAccuracyPercent!!, 0.01f)
        assertEquals(5, stats.totalPredictions)
        assertEquals(5, stats.evaluatedPredictions)
    }

    @Test
    fun `pending unresolved predictions are counted in totals but excluded from accuracy`() {
        val entries = listOf(
            entry(1, 1000, PredictionOutcome.WIN),
            entry(2, 2000, PredictionOutcome.UNRESOLVED)
        )
        val stats = AccuracyAnalytics.compute(entries)

        assertEquals(2, stats.totalPredictions)
        assertEquals(1, stats.unresolved)
        assertEquals(100f, stats.overallAccuracyPercent!!, 0.01f)
    }

    @Test
    fun `fewer than the minimum decisive predictions does not claim an edge`() {
        val entries = (1..10L).map { entry(it, it * 1000, PredictionOutcome.WIN) }
        val stats = AccuracyAnalytics.compute(entries)
        assertTrue(entries.size < AccuracyAnalytics.MIN_EVALUATED_FOR_EDGE_CLAIM)
        assertFalse(stats.hasEnoughDataForEdgeClaim)
    }

    @Test
    fun `at or above the minimum decisive predictions allows an edge claim`() {
        val entries = (1..AccuracyAnalytics.MIN_EVALUATED_FOR_EDGE_CLAIM.toLong()).map {
            entry(it, it * 1000, if (it % 2 == 0L) PredictionOutcome.WIN else PredictionOutcome.LOSS)
        }
        val stats = AccuracyAnalytics.compute(entries)
        assertTrue(stats.hasEnoughDataForEdgeClaim)
    }

    @Test
    fun `current streak reflects the most recent chronological outcomes, unaffected by input order`() {
        val scrambled = listOf(
            entry(4, 4000, PredictionOutcome.WIN),
            entry(1, 1000, PredictionOutcome.WIN),
            entry(6, 6000, PredictionOutcome.WIN),
            entry(3, 3000, PredictionOutcome.LOSS),
            entry(2, 2000, PredictionOutcome.WIN),
            entry(5, 5000, PredictionOutcome.WIN)
        )
        val stats = AccuracyAnalytics.compute(scrambled)
        assertEquals(3, stats.currentStreak)
    }

    @Test
    fun `a current losing streak is represented as a negative number`() {
        val entries = listOf(
            entry(1, 1000, PredictionOutcome.WIN),
            entry(2, 2000, PredictionOutcome.LOSS),
            entry(3, 3000, PredictionOutcome.LOSS)
        )
        val stats = AccuracyAnalytics.compute(entries)
        assertEquals(-2, stats.currentStreak)
    }

    @Test
    fun `max winning and losing streaks are found correctly across the whole history`() {
        val outcomes = listOf(
            PredictionOutcome.WIN, PredictionOutcome.WIN, PredictionOutcome.LOSS, PredictionOutcome.LOSS,
            PredictionOutcome.LOSS, PredictionOutcome.WIN, PredictionOutcome.WIN, PredictionOutcome.WIN,
            PredictionOutcome.WIN, PredictionOutcome.LOSS
        )
        val entries = outcomes.mapIndexed { i, outcome -> entry(i.toLong(), i * 1000L, outcome) }
        val stats = AccuracyAnalytics.compute(entries)

        assertEquals(4, stats.maxWinningStreak)
        assertEquals(3, stats.maxLosingStreak)
    }

    @Test
    fun `bucketing by instrument groups and computes accuracy correctly per group`() {
        val entries = listOf(
            entry(1, 1000, PredictionOutcome.WIN, instrument = "AUD/USD"),
            entry(2, 2000, PredictionOutcome.LOSS, instrument = "AUD/USD"),
            entry(3, 3000, PredictionOutcome.WIN, instrument = "EUR/USD"),
            entry(4, 4000, PredictionOutcome.WIN, instrument = "EUR/USD")
        )
        val stats = AccuracyAnalytics.compute(entries)

        val audUsd = stats.accuracyByInstrument.first { it.label == "AUD/USD" }
        val eurUsd = stats.accuracyByInstrument.first { it.label == "EUR/USD" }
        assertEquals(50f, audUsd.accuracyPercent!!, 0.01f)
        assertEquals(100f, eurUsd.accuracyPercent!!, 0.01f)
    }

    @Test
    fun `confidence bucketing places entries into the correct range and labels 75+ correctly`() {
        val entries = listOf(
            entry(1, 1000, PredictionOutcome.WIN, confidence = 52),
            entry(2, 2000, PredictionOutcome.WIN, confidence = 88)
        )
        val stats = AccuracyAnalytics.compute(entries)

        assertTrue(stats.accuracyByConfidenceBucket.any { it.label == "50-54" })
        assertTrue(stats.accuracyByConfidenceBucket.any { it.label == "75+" })
    }

    @Test
    fun `a null setup is bucketed under unknown rather than crashing`() {
        val entries = listOf(entry(1, 1000, PredictionOutcome.WIN, setup = null))
        val stats = AccuracyAnalytics.compute(entries)
        assertTrue(stats.accuracyBySetup.any { it.label == "unknown" })
    }
}
