package com.chartlens.ai.candle

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChartStructureValidatorTest {

    private val validator = ChartStructureValidator()

    private fun candle(
        index: Int,
        xStart: Int,
        width: Int = 8,
        wickTopY: Int = 100,
        wickBottomY: Int = 200
    ) = Candle(
        index = index,
        xStart = xStart,
        xEnd = xStart + width,
        bodyTopY = wickTopY + 10,
        bodyBottomY = wickBottomY - 10,
        wickTopY = wickTopY,
        wickBottomY = wickBottomY,
        direction = CandleDirection.BULLISH,
        isForming = false,
        confidence = 1f
    )

    /** A realistic chart: 20 candles at a regular 12px pitch, similar widths,
     * all sharing a vertical price band with natural variation. */
    private fun realisticChart(): List<Candle> = (0 until 20).map { i ->
        val jitter = (i % 3) - 1 // -1, 0, +1 px — real rendering isn't pixel-perfect
        candle(
            index = i,
            xStart = i * 12 + jitter,
            width = 8,
            wickTopY = 100 + (i % 5) * 8,
            wickBottomY = 200 - (i % 4) * 6
        )
    }

    @Test
    fun `a realistic chart passes validation`() {
        val result = validator.validate(realisticChart())
        assertTrue("expected valid, got: ${result.reason}", result.isValidChart)
    }

    @Test
    fun `too few shapes is rejected`() {
        val result = validator.validate((0 until 5).map { candle(it, it * 12) })
        assertFalse(result.isValidChart)
        assertTrue(result.reason!!.contains("candle-like shapes"))
    }

    @Test
    fun `an empty list is rejected rather than crashing`() {
        assertFalse(validator.validate(emptyList()).isValidChart)
    }

    @Test
    fun `irregularly spaced shapes like text are rejected`() {
        // The real failure this exists for: colored text/UI elements scattered across a
        // screen with no consistent pitch. Positions here are deliberately erratic.
        val xs = listOf(0, 5, 40, 43, 120, 121, 300, 305, 306, 500, 640, 641)
        val shapes = xs.mapIndexed { i, x -> candle(i, x, width = 6) }

        val result = validator.validate(shapes)

        assertFalse("scattered text should not validate as a chart", result.isValidChart)
        assertTrue(result.reason!!.contains("irregular spacing"))
    }

    @Test
    fun `shapes with wildly varying widths are rejected`() {
        // Regular pitch but text-like width variation (glyphs, icons, buttons).
        val widths = listOf(2, 30, 4, 25, 3, 40, 2, 18, 5, 33, 3, 22)
        val shapes = widths.mapIndexed { i, w -> candle(i, i * 50, width = w) }

        val result = validator.validate(shapes)

        assertFalse(result.isValidChart)
        assertTrue(result.reason!!.contains("inconsistent widths"))
    }

    @Test
    fun `vertically scattered shapes are rejected even with regular pitch and width`() {
        // Uniform pitch and width, but each shape sits in its own vertical band with no
        // overlap — like evenly-spaced icons down a column, not candles in a price range.
        val shapes = (0 until 12).map { i ->
            candle(i, xStart = i * 12, width = 8, wickTopY = i * 60, wickBottomY = i * 60 + 20)
        }

        val result = validator.validate(shapes)

        assertFalse(result.isValidChart)
        assertTrue(result.reason!!.contains("scattered vertically"))
    }

    @Test
    fun `a chart with one unusual gap still validates`() {
        // Real charts can have an occasional irregularity (a missed candle, an edge
        // sliver). One anomaly among many regular gaps must not reject the whole chart.
        val candles = realisticChart().toMutableList()
        candles[10] = candle(10, xStart = 10 * 12 + 30, width = 8) // one displaced candle

        val result = validator.validate(candles)

        assertTrue("one anomaly shouldn't reject a real chart: ${result.reason}", result.isValidChart)
    }

    @Test
    fun `the rejection reason is null when valid and populated when not`() {
        assertEquals(null, validator.validate(realisticChart()).reason)
        assertTrue(validator.validate(emptyList()).reason != null)
    }
}
