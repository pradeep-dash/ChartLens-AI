package com.chartlens.ai.candle

import com.chartlens.ai.testutil.MutablePixelGrid
import com.chartlens.ai.testutil.MutablePixelGrid.Companion.BACKGROUND_COLOR
import com.chartlens.ai.testutil.MutablePixelGrid.Companion.BEARISH_COLOR
import com.chartlens.ai.testutil.MutablePixelGrid.Companion.BULLISH_COLOR
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CandleDetectorTest {

    private val detector = CandleDetector()

    @Test
    fun `empty buffer produces no candles`() {
        val buffer = MutablePixelGrid(30, 40, BACKGROUND_COLOR).toPixelBuffer()
        assertTrue(detector.detect(buffer).isEmpty())
    }

    @Test
    fun `two candles are detected with correct body-wick geometry and direction`() {
        val grid = MutablePixelGrid(30, 40, BACKGROUND_COLOR)

        // Bearish candle: columns 2..6, wick on column 4 spans rows 2..33, body spans rows 10..20.
        grid.fillRect(left = 4, top = 2, right = 5, bottom = 34, color = BEARISH_COLOR)
        grid.fillRect(left = 2, top = 10, right = 7, bottom = 21, color = BEARISH_COLOR)

        // Bullish candle: columns 12..16 (gap of 5 background columns separates the bars),
        // wick on column 14 spans rows 5..33, body spans rows 15..25.
        grid.fillRect(left = 14, top = 5, right = 15, bottom = 34, color = BULLISH_COLOR)
        grid.fillRect(left = 12, top = 15, right = 17, bottom = 26, color = BULLISH_COLOR)

        val candles = detector.detect(grid.toPixelBuffer())

        assertEquals(2, candles.size)

        val bearish = candles[0]
        assertEquals(CandleDirection.BEARISH, bearish.direction)
        assertEquals(10, bearish.bodyTopY)
        assertEquals(20, bearish.bodyBottomY)
        assertEquals(2, bearish.wickTopY)
        assertEquals(33, bearish.wickBottomY)
        assertFalse("only the last bar should be marked as forming", bearish.isForming)

        val bullish = candles[1]
        assertEquals(CandleDirection.BULLISH, bullish.direction)
        assertEquals(15, bullish.bodyTopY)
        assertEquals(25, bullish.bodyBottomY)
        assertEquals(5, bullish.wickTopY)
        assertEquals(33, bullish.wickBottomY)
        assertTrue("the rightmost detected bar should be marked as forming", bullish.isForming)
    }

    @Test
    fun `open close high low pixel semantics match direction`() {
        val grid = MutablePixelGrid(20, 40, BACKGROUND_COLOR)
        // Bullish candle: body 10..20, wick 2..33.
        grid.fillRect(left = 4, top = 2, right = 5, bottom = 34, color = BULLISH_COLOR)
        grid.fillRect(left = 2, top = 10, right = 7, bottom = 21, color = BULLISH_COLOR)

        val candle = detector.detect(grid.toPixelBuffer()).single()

        // Bullish: close is the higher price (smaller Y) -> closeY == bodyTopY, openY == bodyBottomY.
        assertEquals(candle.bodyTopY, candle.closeY)
        assertEquals(candle.bodyBottomY, candle.openY)
        assertEquals(candle.wickTopY, candle.highY)
        assertEquals(candle.wickBottomY, candle.lowY)
    }

    @Test
    fun `isForming correctly targets the last surviving bar even when an earlier bar is filtered out`() {
        val grid = MutablePixelGrid(30, 40, BACKGROUND_COLOR)

        // A 1px-wide sliver (below default minBarWidthPx=2) between two real candles —
        // regression guard for a bug where filtering short bars could desync "isForming"
        // from the actual last item in the filtered list.
        grid.fillRect(left = 2, top = 15, right = 7, bottom = 25, color = BEARISH_COLOR) // real candle
        grid.fillRect(left = 10, top = 15, right = 11, bottom = 16, color = BEARISH_COLOR) // 1px sliver, filtered out
        grid.fillRect(left = 20, top = 10, right = 25, bottom = 30, color = BULLISH_COLOR) // real candle, should be "forming"

        val candles = detector.detect(grid.toPixelBuffer())

        assertEquals(2, candles.size)
        assertFalse(candles[0].isForming)
        assertTrue("the last real candle must be marked forming, not the filtered sliver", candles[1].isForming)
    }

    @Test
    fun `directly adjacent candles of different colors with no gap are still split apart`() {
        // Regression test for a real bug found testing against an actual trading app:
        // touching candles (no background gap between them) were incorrectly merged
        // into a single bar, collapsing an entire row of candles into "0 closed candles".
        val grid = MutablePixelGrid(30, 40, BACKGROUND_COLOR)

        // Bearish candle: columns 2..6 (touches the next candle at column 7 with no gap).
        grid.fillRect(left = 4, top = 5, right = 5, bottom = 30, color = BEARISH_COLOR)
        grid.fillRect(left = 2, top = 10, right = 7, bottom = 20, color = BEARISH_COLOR)

        // Bullish candle: columns 7..11, immediately adjacent — column 7 is colored by
        // BOTH fillRect calls below, simulating zero-gap touching candles.
        grid.fillRect(left = 9, top = 3, right = 10, bottom = 32, color = BULLISH_COLOR)
        grid.fillRect(left = 7, top = 12, right = 12, bottom = 22, color = BULLISH_COLOR)

        val candles = detector.detect(grid.toPixelBuffer())

        assertEquals("touching candles must be detected as two separate candles, not merged", 2, candles.size)
        assertEquals(CandleDirection.BEARISH, candles[0].direction)
        assertEquals(CandleDirection.BULLISH, candles[1].direction)
    }

    @Test
    fun `a narrow single-column sliver below minimum width is ignored`() {
        val grid = MutablePixelGrid(20, 40, BACKGROUND_COLOR)
        // A single colored pixel run 1px wide — below CandleDetector's default minBarWidthPx.
        grid.fillRect(left = 5, top = 10, right = 6, bottom = 11, color = BEARISH_COLOR)

        val detector = CandleDetector(minBarWidthPx = 2)
        assertTrue(detector.detect(grid.toPixelBuffer()).isEmpty())
    }

    // --- Merged same-colored run splitting -------------------------------------

    @Test
    fun `a run of touching same-colored candles is split into individual candles`() {
        // Regression test for a real device bug: a chart with an extended same-direction
        // decline showed roughly 4x fewer candles detected than were actually visible.
        // clusterIntoBars only splits on a color change or a background gap — a run of
        // several consecutive SAME-colored candles with no gap between them (routine
        // during any sustained move) was silently merging into one bar.
        val grid = MutablePixelGrid(40, 30, BACKGROUND_COLOR)
        // Two reference candles of different colors, well separated — correctly detected
        // as-is, establishing a typical single-candle width of 4px.
        grid.fillRect(left = 0, top = 10, right = 4, bottom = 20, color = BULLISH_COLOR)
        grid.fillRect(left = 8, top = 10, right = 12, bottom = 20, color = BEARISH_COLOR)
        // Three same-colored candles glued together with no gap between them — exactly
        // the bug: this renders as one continuous 12px-wide bullish run.
        grid.fillRect(left = 16, top = 10, right = 28, bottom = 20, color = BULLISH_COLOR)

        val candles = detector.detect(grid.toPixelBuffer())

        assertEquals("2 reference candles + 3 split from the merged run", 5, candles.size)
        candles.drop(2).forEach { candle ->
            assertEquals("each split sub-candle should be ~4px wide", 4, candle.xEnd - candle.xStart)
            assertEquals(CandleDirection.BULLISH, candle.direction)
        }
    }

    @Test
    fun `a genuinely wide single candle that is not a clean multiple is not split`() {
        val grid = MutablePixelGrid(40, 30, BACKGROUND_COLOR)
        grid.fillRect(left = 0, top = 10, right = 4, bottom = 20, color = BULLISH_COLOR)  // width 4
        grid.fillRect(left = 8, top = 10, right = 12, bottom = 20, color = BEARISH_COLOR) // width 4
        // Width 6 — not close to any clean multiple of the 4px typical width (nearest
        // candidate is 2x=8, off by 2px, outside tolerance) — a real, single wider candle.
        grid.fillRect(left = 16, top = 10, right = 22, bottom = 20, color = BULLISH_COLOR)

        val candles = detector.detect(grid.toPixelBuffer())

        assertEquals("the wide candle should be left as one candle, not fabricated into two", 3, candles.size)
        assertEquals(6, candles[2].xEnd - candles[2].xStart)
    }

    @Test
    fun `fewer than three bars never attempts splitting, having no reliable width estimate`() {
        val grid = MutablePixelGrid(40, 30, BACKGROUND_COLOR)
        grid.fillRect(left = 0, top = 10, right = 4, bottom = 20, color = BULLISH_COLOR)
        // A wide bar that WOULD be a clean 3x multiple of the other candle's width — but
        // with only 2 bars total, there's no reliable typical-width estimate to split against.
        grid.fillRect(left = 8, top = 10, right = 20, bottom = 20, color = BEARISH_COLOR)

        val candles = detector.detect(grid.toPixelBuffer())

        assertEquals(2, candles.size)
    }
}
