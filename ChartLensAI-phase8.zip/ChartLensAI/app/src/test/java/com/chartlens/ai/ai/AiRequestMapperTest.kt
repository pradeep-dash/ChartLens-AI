package com.chartlens.ai.ai

import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.analysis.PriceCandle
import com.chartlens.ai.analysis.TechnicalAnalysisEngine
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.candle.CandlePattern
import com.chartlens.ai.prediction.LastCandleContext
import com.chartlens.ai.prediction.PredictionDirection
import com.chartlens.ai.prediction.PredictionResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AiRequestMapperTest {

    private fun baseFrame(
        technicalAnalysis: com.chartlens.ai.analysis.TechnicalAnalysisResult? =
            TechnicalAnalysisEngine().analyze(List(60) { i -> PriceCandle(i, null, 1.0 + i * 0.01, 1.0, 1.0, 1.0) }),
        prediction: PredictionResult? = PredictionResult(PredictionDirection.UP, 65, emptyList(), emptyList(), "trend_continuation"),
        lastCandleContext: LastCandleContext? = LastCandleContext(1.5, CandleDirection.BULLISH, 2, 5, setOf(CandlePattern.HAMMER))
    ) = AnalysisFrame(
        timestampMillis = 0L,
        chartRegion = null,
        candles = emptyList(),
        patternMatches = emptyList(),
        dataQuality = DataQuality.GOOD,
        technicalAnalysis = technicalAnalysis,
        prediction = prediction,
        lastCandleContext = lastCandleContext
    )

    @Test
    fun `returns null when there is no technical analysis`() {
        assertNull(AiRequestMapper.buildRequest(baseFrame(technicalAnalysis = null)))
    }

    @Test
    fun `returns null when there is no prediction`() {
        assertNull(AiRequestMapper.buildRequest(baseFrame(prediction = null)))
    }

    @Test
    fun `maps prediction bias and confidence directly`() {
        val request = AiRequestMapper.buildRequest(baseFrame())!!
        assertEquals("UP", request.predictionEngineBias)
        assertEquals(65, request.modelConfidence)
        assertEquals("GOOD", request.dataQuality)
    }

    @Test
    fun `maps the last candle's patterns into a comma-joined string`() {
        val request = AiRequestMapper.buildRequest(baseFrame())!!
        assertEquals("HAMMER", request.currentPattern)
    }

    @Test
    fun `a candle with no patterns maps to a null currentPattern, not an empty string`() {
        val request = AiRequestMapper.buildRequest(
            baseFrame(lastCandleContext = LastCandleContext(1.5, CandleDirection.BULLISH, 2, 5, emptySet()))
        )!!
        assertNull(request.currentPattern)
    }

    @Test
    fun `ema alignment describes bullish ordering correctly`() {
        // A steadily rising price series produces ema9 > ema21 > ema50.
        val ta = TechnicalAnalysisEngine().analyze(List(60) { i -> PriceCandle(i, null, 100.0 + i, 100.0 + i, 100.0 + i, 100.0 + i) })
        val request = AiRequestMapper.buildRequest(baseFrame(technicalAnalysis = ta))!!
        assertEquals("BULLISH_ALIGNED", request.emaAlignment)
    }

    @Test
    fun `unknown timeframe maps to the literal string Unknown`() {
        val request = AiRequestMapper.buildRequest(baseFrame())!!
        assertEquals("Unknown", request.timeframe)
    }
}
