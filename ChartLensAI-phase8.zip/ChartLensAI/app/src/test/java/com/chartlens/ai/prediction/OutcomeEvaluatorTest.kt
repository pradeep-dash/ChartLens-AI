package com.chartlens.ai.prediction

import org.junit.Assert.assertEquals
import org.junit.Test

class OutcomeEvaluatorTest {

    @Test
    fun `an UP prediction where price rose is a WIN`() {
        assertEquals(
            PredictionOutcome.WIN,
            OutcomeEvaluator.evaluate(PredictionDirection.UP, entryPrice = 1.0000, evaluationPrice = 1.0050)
        )
    }

    @Test
    fun `an UP prediction where price fell is a LOSS`() {
        assertEquals(
            PredictionOutcome.LOSS,
            OutcomeEvaluator.evaluate(PredictionDirection.UP, entryPrice = 1.0000, evaluationPrice = 0.9950)
        )
    }

    @Test
    fun `a DOWN prediction where price fell is a WIN`() {
        assertEquals(
            PredictionOutcome.WIN,
            OutcomeEvaluator.evaluate(PredictionDirection.DOWN, entryPrice = 1.0000, evaluationPrice = 0.9950)
        )
    }

    @Test
    fun `a DOWN prediction where price rose is a LOSS`() {
        assertEquals(
            PredictionOutcome.LOSS,
            OutcomeEvaluator.evaluate(PredictionDirection.DOWN, entryPrice = 1.0000, evaluationPrice = 1.0050)
        )
    }

    @Test
    fun `a negligible price move is NEUTRAL regardless of direction`() {
        assertEquals(
            PredictionOutcome.NEUTRAL,
            OutcomeEvaluator.evaluate(PredictionDirection.UP, entryPrice = 1.00000, evaluationPrice = 1.00001)
        )
        assertEquals(
            PredictionOutcome.NEUTRAL,
            OutcomeEvaluator.evaluate(PredictionDirection.DOWN, entryPrice = 1.00000, evaluationPrice = 0.99999)
        )
    }

    @Test
    fun `NO_TRADE is never a valid direction to evaluate`() {
        assertEquals(
            PredictionOutcome.INVALID_DATA,
            OutcomeEvaluator.evaluate(PredictionDirection.NO_TRADE, entryPrice = 1.0, evaluationPrice = 1.1)
        )
    }

    @Test
    fun `a zero or negative entry price is invalid data, not a division by zero crash`() {
        assertEquals(
            PredictionOutcome.INVALID_DATA,
            OutcomeEvaluator.evaluate(PredictionDirection.UP, entryPrice = 0.0, evaluationPrice = 1.0)
        )
        assertEquals(
            PredictionOutcome.INVALID_DATA,
            OutcomeEvaluator.evaluate(PredictionDirection.UP, entryPrice = -1.0, evaluationPrice = 1.0)
        )
    }
}
