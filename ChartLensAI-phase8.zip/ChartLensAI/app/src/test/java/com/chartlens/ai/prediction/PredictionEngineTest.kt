package com.chartlens.ai.prediction

import com.chartlens.ai.analysis.BreakoutStatus
import com.chartlens.ai.analysis.RejectionStatus
import com.chartlens.ai.analysis.Timeframe
import com.chartlens.ai.candle.CandlePattern
import com.chartlens.ai.indicators.BollingerPoint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The "clean bullish" fixture's expected math, hand-computed here so the
 * baseline test is a genuine check rather than "whatever the code produces":
 *
 * trend: score=0.9, weight=1.0 -> 0.9
 * momentum: roc=0.5/divisor(0.3)=1.667 clamped to 1.0, weight=1.0 -> 1.0
 * ema_alignment: 9>21>50 all agree, score=1.0, weight=1.0 -> 1.0
 * rsi: 60 -> (60-50)/50*0.3=0.06, weight=0.8 -> 0.048
 * macd: 0.001/0.002=0.5, weight=0.8 -> 0.4
 * support_resistance: no active breakout/rejection -> INAPPLICABLE (excluded from both
 *   numerator and denominator, not "applicable with score 0" — see supportResistanceEvidence's
 *   doc comment for why this matters: a level merely existing isn't itself evidence of
 *   anything, and counting it anyway was diluting confidence on nearly every real frame)
 * candle_pattern: BULLISH_ENGULFING=0.8, weight=0.7 -> 0.56
 * recent_sequence: streak=4, sign=+1, mag=4/5=0.8, 1*0.8*0.6=0.48, weight=0.6 -> 0.288
 *
 * totalWeight = 1.0+1.0+1.0+0.8+0.8+0.7+0.6 = 5.9 (support_resistance excluded)
 * weightedSum = 0.9+1.0+1.0+0.048+0.4+0.56+0.288 = 4.196
 * normalizedScore = 4.196/5.9 = 0.7112 -> confidence round(71.12) = 71, direction UP
 * bearishWeight = 0 (nothing scores below -0.05) -> not conflicting
 */
class PredictionEngineTest {

    private val engine = PredictionEngine()

    @Test
    fun `clean bullish evidence produces UP with the hand-calculated confidence`() {
        val result = engine.predict(
            cleanBullishTechnicalAnalysis(), closedCandleCount = 30, cleanBullishLastCandle(), Timeframe.M1
        )

        assertEquals(PredictionDirection.UP, result.direction)
        assertEquals(71, result.modelConfidence)
        assertTrue(result.noTradeReasons.isEmpty())
        assertTrue(result.setup != null)
        // No gate blocked anything here — the actual direction already says everything a
        // "lean" would, so there's nothing to add.
        assertEquals(null, result.directionalLean)
    }

    @Test
    fun `clean bearish evidence produces DOWN`() {
        val result = engine.predict(
            cleanBearishTechnicalAnalysis(), closedCandleCount = 30, cleanBearishLastCandle(), Timeframe.M1
        )

        assertEquals(PredictionDirection.DOWN, result.direction)
        assertTrue(result.modelConfidence > 0)
        assertTrue(result.noTradeReasons.isEmpty())
    }

    @Test
    fun `no technical analysis at all is NO_TRADE with INSUFFICIENT_DATA`() {
        val result = engine.predict(null, closedCandleCount = 30, cleanBullishLastCandle(), Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertEquals(0, result.modelConfidence)
        assertEquals(listOf(NoTradeReason.INSUFFICIENT_DATA), result.noTradeReasons)
        // Nothing to lean toward when there's no evidence at all to compute it from.
        assertEquals(null, result.directionalLean)
    }

    @Test
    fun `too few closed candles is NO_TRADE with INSUFFICIENT_CANDLES even with strong evidence`() {
        val result = engine.predict(
            cleanBullishTechnicalAnalysis(), closedCandleCount = 5, cleanBullishLastCandle(), Timeframe.M1
        )

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertEquals(listOf(NoTradeReason.INSUFFICIENT_CANDLES), result.noTradeReasons)
    }

    @Test
    fun `a doji last candle forces NO_TRADE even with otherwise strong bullish evidence`() {
        val dojiCandle = cleanBullishLastCandle().copy(patterns = setOf(CandlePattern.DOJI))
        val result = engine.predict(cleanBullishTechnicalAnalysis(), closedCandleCount = 30, dojiCandle, Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertTrue(result.noTradeReasons.contains(NoTradeReason.DOJI_CHOP))
    }

    @Test
    fun `an unknown timeframe forces NO_TRADE even with otherwise strong bullish evidence`() {
        val result = engine.predict(
            cleanBullishTechnicalAnalysis(), closedCandleCount = 30, cleanBullishLastCandle(), timeframe = null
        )

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertTrue(result.noTradeReasons.contains(NoTradeReason.UNKNOWN_TIMEFRAME))
    }

    @Test
    fun `price sitting right at an unbroken resistance level forces NO_TRADE`() {
        val ta = cleanBullishTechnicalAnalysis()
        val candle = cleanBullishLastCandle().copy(closePrice = 1.0498) // within 0.15% of resistance at 1.05
        val result = engine.predict(ta, closedCandleCount = 30, candle, Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertTrue(result.noTradeReasons.contains(NoTradeReason.PRICE_NEAR_KEY_LEVEL))
        // The gate blocked a call, but the underlying (otherwise strongly bullish) evidence
        // still had a real, honest lean worth surfacing as informational context.
        assertEquals(PredictionDirection.UP, result.directionalLean?.direction)
        assertTrue("expected a real positive raw score", (result.directionalLean?.rawScore ?: 0) > 0)
    }

    @Test
    fun `having already broken the level does not trigger the near-level gate`() {
        val ta = cleanBullishTechnicalAnalysis().let {
            it.copy(supportResistance = it.supportResistance.copy(breakoutStatus = BreakoutStatus.BROKE_ABOVE_RESISTANCE))
        }
        val candle = cleanBullishLastCandle().copy(closePrice = 1.0498) // same "close to the level" price as above
        val result = engine.predict(ta, closedCandleCount = 30, candle, Timeframe.M1)

        assertTrue(
            "a confirmed breakout at that price should not also be flagged as 'stuck at the level'",
            !result.noTradeReasons.contains(NoTradeReason.PRICE_NEAR_KEY_LEVEL)
        )
    }

    @Test
    fun `elevated volatility (wide Bollinger Bands) forces NO_TRADE`() {
        val ta = cleanBullishTechnicalAnalysis().copy(
            bollinger = BollingerPoint(middle = 1.005, upper = 1.055, lower = 0.955) // width/middle ~ 10%, well above 2% threshold
        )
        val result = engine.predict(ta, closedCandleCount = 30, cleanBullishLastCandle(), Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertTrue(result.noTradeReasons.contains(NoTradeReason.ABNORMAL_VOLATILITY))
    }

    @Test
    fun `roughly balanced bullish and bearish evidence is flagged as conflicting`() {
        // Strong bullish trend/momentum, but strongly bearish RSI/MACD/pattern — genuinely
        // mixed evidence, not a case that should confidently pick a direction.
        val ta = cleanBullishTechnicalAnalysis().copy(
            rsi14 = 85.0, // deep overbought -> strongly bearish reversal signal
            macd = MacdPoint(macd = -0.002, signal = -0.0005, histogram = -0.0015)
        )
        val candle = cleanBullishLastCandle().copy(patterns = setOf(CandlePattern.SHOOTING_STAR))
        val result = engine.predict(ta, closedCandleCount = 30, candle, Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertTrue(result.noTradeReasons.contains(NoTradeReason.CONFLICTING_EVIDENCE))
    }

    @Test
    fun `near-neutral evidence across the board is NO_TRADE with low confidence`() {
        val ta = cleanBullishTechnicalAnalysis().copy(
            trend = cleanBullishTechnicalAnalysis().trend.copy(trendStrength = 0f),
            momentum = cleanBullishTechnicalAnalysis().momentum.copy(rateOfChangePercent = 0.01),
            ema9 = 1.000, ema21 = 1.000, ema50 = 1.000,
            rsi14 = 50.0,
            macd = MacdPoint(macd = 0.0, signal = 0.0, histogram = 0.0)
        )
        val candle = cleanBullishLastCandle().copy(patterns = emptySet())
        val result = engine.predict(ta, closedCandleCount = 30, candle, Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertTrue(result.noTradeReasons.contains(NoTradeReason.LOW_DIRECTIONAL_CONFIDENCE))
    }

    @Test
    fun `evidence with no data at all for any source is NO_TRADE`() {
        val ta = cleanBullishTechnicalAnalysis().copy(
            trend = cleanBullishTechnicalAnalysis().trend.copy(trendStrength = 0f).let {
                com.chartlens.ai.analysis.TrendResult(com.chartlens.ai.analysis.Trend.UNKNOWN, 0f, emptyList(), emptyList(), false)
            },
            momentum = cleanBullishTechnicalAnalysis().momentum.copy(rateOfChangePercent = null),
            ema9 = null, ema21 = null, ema50 = null,
            rsi14 = null,
            macd = null,
            supportResistance = cleanBullishTechnicalAnalysis().supportResistance.copy(nearestSupport = null, nearestResistance = null)
        )
        val result = engine.predict(ta, closedCandleCount = 30, lastCandle = null, timeframe = Timeframe.M1)

        assertEquals(PredictionDirection.NO_TRADE, result.direction)
        assertEquals(listOf(NoTradeReason.INSUFFICIENT_DATA), result.noTradeReasons)
    }

    @Test
    fun `support-resistance evidence is inapplicable with nothing active, applicable when something is`() {
        // A level merely existing isn't itself directional evidence — only an active
        // breakout or rejection is. Direct regression test for the fix behind the clean
        // bullish baseline's confidence rising from 61 to 71 (see this file's top comment).
        val noActiveEvent = engine.predict(
            cleanBullishTechnicalAnalysis(), closedCandleCount = 30, cleanBullishLastCandle(), Timeframe.M1
        )
        val srSignalInactive = noActiveEvent.evidence.first { it.name == "support_resistance" }
        assertTrue("should be inapplicable with no active breakout/rejection", !srSignalInactive.applicable)

        val withActiveBreakout = engine.predict(
            cleanBullishTechnicalAnalysis().let {
                it.copy(supportResistance = it.supportResistance.copy(breakoutStatus = BreakoutStatus.BROKE_ABOVE_RESISTANCE))
            },
            closedCandleCount = 30,
            cleanBullishLastCandle(),
            Timeframe.M1
        )
        val srSignalActive = withActiveBreakout.evidence.first { it.name == "support_resistance" }
        assertTrue("should be applicable once a breakout is actually happening", srSignalActive.applicable)
        assertEquals(0.8, srSignalActive.score, 0.001)
    }
}
