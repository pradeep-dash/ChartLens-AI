package com.chartlens.ai.ocr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PriceTextParserTest {

    @Test
    fun `parses a simple decimal price`() {
        assertEquals(61.4, PriceTextParser.parse("61.400")!!, 1e-9)
    }

    @Test
    fun `parses a small decimal price with leading zero`() {
        assertEquals(0.19773, PriceTextParser.parse("0.19773")!!, 1e-9)
    }

    @Test
    fun `parses a three-digit-before-decimal price`() {
        assertEquals(194.2, PriceTextParser.parse("194.200")!!, 1e-9)
    }

    @Test
    fun `trims surrounding whitespace`() {
        assertEquals(61.4, PriceTextParser.parse("  61.400  ")!!, 1e-9)
    }

    @Test
    fun `finds the price within a longer string with extra noise around it`() {
        // OCR sometimes glues stray fragments onto the real number, e.g. a
        // misread digit or label bleeding into the same line.
        assertEquals(1.65061, PriceTextParser.parse("33 1.65061")!!, 1e-9)
    }

    @Test
    fun `text with no recognizable number returns null`() {
        assertNull(PriceTextParser.parse("Deposit"))
        assertNull(PriceTextParser.parse(""))
    }

    @Test
    fun `a bare integer with no decimal point is rejected, not accepted as a truncated price`() {
        // Regression test for a real device failure: a too-narrow OCR crop truncated
        // "92.700" down to just "700", and because bare integers used to be accepted,
        // a run of such truncated fragments produced a mathematically clean but
        // completely wrong price mapping. Every real price label on the platforms this
        // project targets has a decimal point — a bare integer is never legitimate.
        assertNull(PriceTextParser.parse("500"))
        assertNull(PriceTextParser.parse("21"))
        assertNull(PriceTextParser.parse("07"))
    }

    @Test
    fun `comma-grouped numbers are rejected outright, not parsed as thousands or as a decimal comma`() {
        // Regression test for a real device failure: "19,500" (a payout amount) parsed
        // as a valid price via the old thousands-separator support and, since it wasn't
        // caught by X-position clustering on that layout, distorted the price mapping
        // badly (EMA values over 2000 on a chart where the real price was ~1.65). Every
        // real price label observed in testing uses a plain period with no thousands
        // grouping — comma-adjacent digits on these platforms have only ever meant a
        // UI monetary figure, never a price, so this is rejected unconditionally now.
        assertNull(PriceTextParser.parse("19,500"))
        assertNull(PriceTextParser.parse("974,500.00"))
        assertNull(PriceTextParser.parse("61,400"))
    }
}
