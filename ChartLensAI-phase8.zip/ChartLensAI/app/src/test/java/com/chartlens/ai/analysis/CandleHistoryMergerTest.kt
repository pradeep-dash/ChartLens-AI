package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class CandleHistoryMergerTest {

    private fun candle(index: Int, close: Double) = PriceCandle(index, null, close, close, close, close)

    @Test
    fun `with no recorded history, the current frame's candles are used as-is`() {
        val current = listOf(candle(0, 1.0), candle(1, 1.1))
        val result = CandleHistoryMerger.merge(recordedHistory = emptyList(), currentFrameCandles = current)
        assertEquals(current, result)
    }

    @Test
    fun `with no current-frame candles at all, the recorded history is returned unchanged`() {
        val history = listOf(candle(0, 1.0), candle(1, 1.1))
        val result = CandleHistoryMerger.merge(recordedHistory = history, currentFrameCandles = emptyList())
        assertEquals(history, result)
    }

    @Test
    fun `a genuinely new closed candle not yet in recorded history gets appended`() {
        val history = listOf(candle(0, 1.0), candle(1, 1.1))
        // The current frame's latest close (1.2) doesn't match history's latest (1.1) —
        // this candle closed after the recorder last wrote, so it's genuinely new.
        val current = listOf(candle(5, 1.05), candle(6, 1.1), candle(7, 1.2))

        val result = CandleHistoryMerger.merge(history, current)

        assertEquals(3, result.size)
        assertEquals(1.2, result.last().close, 0.0)
    }

    @Test
    fun `a candle already represented in recorded history is not appended again`() {
        val history = listOf(candle(0, 1.0), candle(1, 1.1))
        // The current frame's latest close (1.1) matches history's latest exactly —
        // this is the same candle the recorder already wrote, not a new one.
        val current = listOf(candle(5, 1.05), candle(6, 1.1))

        val result = CandleHistoryMerger.merge(history, current)

        assertEquals(2, result.size)
        assertSame(history, result)
    }

    @Test
    fun `a tiny floating point difference in the same candle's close still counts as already represented`() {
        val history = listOf(candle(0, 1.0), candle(1, 1.10000001))
        val current = listOf(candle(5, 1.05), candle(6, 1.10000002))

        val result = CandleHistoryMerger.merge(history, current)

        assertEquals(2, result.size)
    }
}
