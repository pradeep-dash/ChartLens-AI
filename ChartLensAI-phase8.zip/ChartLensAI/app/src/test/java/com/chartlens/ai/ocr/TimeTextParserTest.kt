package com.chartlens.ai.ocr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimeTextParserTest {

    @Test
    fun `parses a standard HH-mm label`() {
        assertEquals(21 * 60 + 36, TimeTextParser.parseMinutesSinceMidnight("21:36"))
    }

    @Test
    fun `parses a single-digit hour`() {
        assertEquals(9 * 60 + 5, TimeTextParser.parseMinutesSinceMidnight("9:05"))
    }

    @Test
    fun `rejects an out-of-range hour`() {
        assertNull(TimeTextParser.parseMinutesSinceMidnight("25:00"))
    }

    @Test
    fun `rejects an out-of-range minute`() {
        assertNull(TimeTextParser.parseMinutesSinceMidnight("12:75"))
    }

    @Test
    fun `text with no time pattern returns null`() {
        assertNull(TimeTextParser.parseMinutesSinceMidnight("Beginning of trade"))
    }

    @Test
    fun `a countdown timer display is rejected outright, not parsed as a clock time`() {
        // Regression test for a real device failure: "00:01:00" is the 1-minute trade
        // countdown timer, not a chart time-axis label, but a naive HH:mm regex still
        // finds "00:01" inside it and would parse it as 12:01am — a wildly wrong value
        // (1 minute) mixed in among genuine ~600-minute readings, with nothing
        // downstream to catch it. The whole string must be rejected, not partially
        // extracted from.
        assertNull(TimeTextParser.parseMinutesSinceMidnight("00:01:00"))
        assertNull(TimeTextParser.parseMinutesSinceMidnight("00:00:45"))
    }
}
