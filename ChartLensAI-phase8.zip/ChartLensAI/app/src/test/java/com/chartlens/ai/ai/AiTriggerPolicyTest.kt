package com.chartlens.ai.ai

import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.CandleCloseEvent
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.analysis.PriceCandle
import com.chartlens.ai.analysis.TechnicalAnalysisEngine
import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.prediction.PredictionDirection
import com.chartlens.ai.prediction.PredictionResult
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiTriggerPolicyTest {

    private fun candle(index: Int) = Candle(
        index = index, xStart = 0, xEnd = 10, bodyTopY = 0, bodyBottomY = 10,
        wickTopY = 0, wickBottomY = 10, direction = CandleDirection.BULLISH,
        isForming = false, confidence = 1f
    )

    private fun frame(
        closeEventIndex: Int? = 5,
        direction: PredictionDirection = PredictionDirection.UP,
        hasTechnicalAnalysis: Boolean = true
    ): AnalysisFrame {
        val prediction = PredictionResult(direction, 70, emptyList(), emptyList(), "trend_continuation")
        return AnalysisFrame(
            timestampMillis = 0L,
            chartRegion = null,
            candles = emptyList(),
            patternMatches = emptyList(),
            dataQuality = DataQuality.GOOD,
            candleCloseEvent = closeEventIndex?.let { CandleCloseEvent(candle(it)) },
            technicalAnalysis = if (hasTechnicalAnalysis) {
                TechnicalAnalysisEngine().analyze(
                    List(20) { i -> PriceCandle(i, null, 1.0, 1.0, 1.0, 1.0) }
                )
            } else null,
            prediction = prediction
        )
    }

    @Test
    fun `triggers on a fresh candle close with a real directional prediction`() {
        assertTrue(AiTriggerPolicy.shouldTrigger(frame(closeEventIndex = 5), lastTriggeredCandleIndex = null))
    }

    @Test
    fun `does not trigger without a candle close event`() {
        assertFalse(AiTriggerPolicy.shouldTrigger(frame(closeEventIndex = null), lastTriggeredCandleIndex = null))
    }

    @Test
    fun `does not trigger for a NO_TRADE prediction`() {
        assertFalse(
            AiTriggerPolicy.shouldTrigger(
                frame(direction = PredictionDirection.NO_TRADE),
                lastTriggeredCandleIndex = null
            )
        )
    }

    @Test
    fun `does not trigger again for the same candle index already triggered`() {
        assertFalse(AiTriggerPolicy.shouldTrigger(frame(closeEventIndex = 5), lastTriggeredCandleIndex = 5))
    }

    @Test
    fun `triggers for a new candle index even if a previous one already triggered`() {
        assertTrue(AiTriggerPolicy.shouldTrigger(frame(closeEventIndex = 6), lastTriggeredCandleIndex = 5))
    }

    @Test
    fun `does not trigger without technical analysis`() {
        assertFalse(
            AiTriggerPolicy.shouldTrigger(
                frame(hasTechnicalAnalysis = false),
                lastTriggeredCandleIndex = null
            )
        )
    }
}
