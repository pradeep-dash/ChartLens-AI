package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NewCandleFinderTest {

    private fun candle(index: Int, close: Double) = PriceCandle(index, null, close, close, close, close)

    @Test
    fun `with no last recorded close, every currently-visible candle is new`() {
        val visible = listOf(candle(0, 1.0), candle(1, 1.1), candle(2, 1.2))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = null, currentlyVisible = visible)
        assertEquals(visible, result)
    }

    @Test
    fun `no currently-visible candles means nothing new, regardless of prior state`() {
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = emptyList())
        assertTrue(result.isEmpty())
    }

    @Test
    fun `normal one-candle-at-a-time progression finds exactly the single new candle`() {
        // Last recorded was 1.1 (still visible); one new candle (1.2) closed since.
        val visible = listOf(candle(0, 1.0), candle(1, 1.1), candle(2, 1.2))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.1, currentlyVisible = visible)
        assertEquals(listOf(candle(2, 1.2)), result)
    }

    @Test
    fun `a catch-up scroll revealing several missed closes backfills all of them at once`() {
        // The last thing recorded was 1.0, from before the chart got "stuck". A scroll
        // just revealed 1.1, 1.2, 1.3 as newly-visible, already-closed candles that were
        // never individually caught while off-screen — all three must be backfilled.
        val visible = listOf(candle(0, 1.0), candle(1, 1.1), candle(2, 1.2), candle(3, 1.3))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = visible)
        assertEquals(listOf(candle(1, 1.1), candle(2, 1.2), candle(3, 1.3)), result)
    }

    @Test
    fun `nothing new since the last recording returns an empty list, not a re-recording`() {
        val visible = listOf(candle(0, 1.0), candle(1, 1.1))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.1, currentlyVisible = visible)
        assertTrue(result.isEmpty())
    }

    @Test
    fun `when the last recorded price is not found anywhere visible, the whole window is treated as new`() {
        // The last recorded candle scrolled off entirely — an accepted risk of possibly
        // re-recording something, preferred over silently recording nothing.
        val visible = listOf(candle(0, 5.0), candle(1, 5.1))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = visible)
        assertEquals(visible, result)
    }

    @Test
    fun `a repeated price level matches the most recent occurrence, not the first`() {
        // 1.1 appears twice; the last recorded candle should anchor to the LATER
        // occurrence, so only the genuinely-new candle after it is returned.
        val visible = listOf(candle(0, 1.1), candle(1, 1.2), candle(2, 1.1), candle(3, 1.3))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.1, currentlyVisible = visible)
        assertEquals(listOf(candle(3, 1.3)), result)
    }
}
