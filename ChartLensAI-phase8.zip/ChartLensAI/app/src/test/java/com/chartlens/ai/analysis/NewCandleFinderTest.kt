package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NewCandleFinderTest {

    private fun candle(index: Int, close: Double) = PriceCandle(index, null, close, close, close, close)

    @Test
    fun `with no last recorded close, every currently-visible candle is new`() {
        val visible = listOf(candle(0, 1.0), candle(1, 1.1), candle(2, 1.2))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = null, currentlyVisible = visible)
        assertEquals(visible, result)
    }

    @Test
    fun `no currently-visible candles means nothing new, regardless of prior state`() {
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = emptyList())
        assertTrue(result.isEmpty())
    }

    @Test
    fun `normal one-candle-at-a-time progression finds exactly the single new candle`() {
        // Last recorded was 1.1 (still visible); one new candle (1.2) closed since.
        val visible = listOf(candle(0, 1.0), candle(1, 1.1), candle(2, 1.2))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.1, currentlyVisible = visible)
        assertEquals(listOf(candle(2, 1.2)), result)
    }

    @Test
    fun `a catch-up scroll revealing several missed closes backfills all of them at once`() {
        // The last thing recorded was 1.0, from before the chart got "stuck". A scroll
        // just revealed 1.1, 1.2, 1.3 as newly-visible, already-closed candles that were
        // never individually caught while off-screen — all three must be backfilled.
        val visible = listOf(candle(0, 1.0), candle(1, 1.1), candle(2, 1.2), candle(3, 1.3))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = visible)
        assertEquals(listOf(candle(1, 1.1), candle(2, 1.2), candle(3, 1.3)), result)
    }

    @Test
    fun `nothing new since the last recording returns an empty list, not a re-recording`() {
        val visible = listOf(candle(0, 1.0), candle(1, 1.1))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.1, currentlyVisible = visible)
        assertTrue(result.isEmpty())
    }

    @Test
    fun `when the last recorded price is not found anywhere visible, the whole window is treated as new`() {
        // The last recorded candle scrolled off entirely — an accepted risk of possibly
        // re-recording something, preferred over silently recording nothing.
        val visible = listOf(candle(0, 5.0), candle(1, 5.1))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = visible)
        assertEquals(visible, result)
    }

    @Test
    fun `a repeated price level matches the most recent occurrence, not the first`() {
        // 1.1 appears twice; the last recorded candle should anchor to the LATER
        // occurrence, so only the genuinely-new candle after it is returned.
        val visible = listOf(candle(0, 1.1), candle(1, 1.2), candle(2, 1.1), candle(3, 1.3))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.1, currentlyVisible = visible)
        assertEquals(listOf(candle(3, 1.3)), result)
    }

    // --- Regression tests for the 5478-row corruption bug -----------------------

    @Test
    fun `a real device bug- when the match keeps failing, the fallback no longer floods with the whole window`() {
        // The actual corruption this exists to prevent: a real session recorded 5478
        // rows for roughly 20-25 real candles, because a never-matching lastRecordedClose
        // (from detection jitter shifting the computed price slightly every frame) made
        // the OLD code treat the entire visible window as new, every single frame. Here a
        // 90-candle window (a plausible dense real chart) with a non-matching last close
        // must be capped, not returned whole.
        val visible = (0 until 90).map { candle(it, 100.0 + it) }
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = -1.0, currentlyVisible = visible)

        assertEquals(NewCandleFinder.DEFAULT_MAX_BACKFILL, result.size)
    }

    @Test
    fun `the capped fallback keeps the most recent candles, not the oldest`() {
        // If the chart genuinely did just catch up from a scroll, the MOST RECENT
        // candles are the ones actually worth keeping — the tail of the window, not
        // stale ones from near the start.
        val visible = (0 until 90).map { candle(it, 100.0 + it) }
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = -1.0, currentlyVisible = visible)

        assertEquals(visible.takeLast(NewCandleFinder.DEFAULT_MAX_BACKFILL), result)
    }

    @Test
    fun `a small window under the cap is returned in full, unaffected by the fix`() {
        // The pre-existing "whole window treated as new" test still behaves identically
        // for realistic small windows — the cap only ever engages once the fallback
        // would otherwise return more than DEFAULT_MAX_BACKFILL candles.
        val visible = listOf(candle(0, 5.0), candle(1, 5.1))
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 1.0, currentlyVisible = visible)
        assertEquals(visible, result)
    }

    @Test
    fun `a genuinely large legitimate backfill is also capped, not just the no-match fallback`() {
        // Applies the same cap even on the "match found, backfill everything since it"
        // path — a 200-candle jump in one frame is itself far more likely to be a
        // detection artifact than a real scroll gap, so it's capped for the same
        // damage-control reason rather than trusted just because a match was found.
        val visible = (0..200).map { candle(it, it.toDouble()) } // 0.0 .. 200.0, index 0 matches close 0.0
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = 0.0, currentlyVisible = visible)

        assertEquals(NewCandleFinder.DEFAULT_MAX_BACKFILL, result.size)
        assertEquals(visible.takeLast(NewCandleFinder.DEFAULT_MAX_BACKFILL), result)
    }

    @Test
    fun `with no last recorded close, an oversized first window is also capped`() {
        val visible = (0 until 50).map { candle(it, it.toDouble()) }
        val result = NewCandleFinder.findNewSuffix(lastRecordedClose = null, currentlyVisible = visible)

        assertEquals(NewCandleFinder.DEFAULT_MAX_BACKFILL, result.size)
        assertEquals(visible.takeLast(NewCandleFinder.DEFAULT_MAX_BACKFILL), result)
    }
}
