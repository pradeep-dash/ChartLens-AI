package com.chartlens.ai.cv

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StructuralRejectionDebouncerTest {

    private val debouncer = StructuralRejectionDebouncer(consecutiveRejectionsBeforeSurfacing = 3)

    @Test
    fun `a valid frame is never surfaced as a rejection`() {
        assertFalse(debouncer.onFrameResult(isValidChart = true))
    }

    @Test
    fun `one or two isolated bad frames are coasted through, not surfaced`() {
        // The actual real-device complaint this fixes: a single transient bad frame
        // (a zoom mid-transition, a momentary render glitch) must not immediately flip
        // the whole UI to "no chart detected."
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertFalse(debouncer.onFrameResult(isValidChart = false))
    }

    @Test
    fun `a sustained run of bad frames is surfaced once it reaches the threshold`() {
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertTrue(debouncer.onFrameResult(isValidChart = false))
    }

    @Test
    fun `rejections keep being surfaced for as long as the failure continues`() {
        repeat(2) { debouncer.onFrameResult(isValidChart = false) }
        assertTrue(debouncer.onFrameResult(isValidChart = false))
        assertTrue(debouncer.onFrameResult(isValidChart = false))
        assertTrue(debouncer.onFrameResult(isValidChart = false))
    }

    @Test
    fun `a single good frame in the middle of a bad run resets the count`() {
        debouncer.onFrameResult(isValidChart = false)
        debouncer.onFrameResult(isValidChart = false)
        assertFalse(debouncer.onFrameResult(isValidChart = true)) // recovers before hitting 3
        // A fresh run of bad frames needs the full threshold again, not just one more.
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertTrue(debouncer.onFrameResult(isValidChart = false))
    }

    @Test
    fun `reset clears an in-progress bad run`() {
        debouncer.onFrameResult(isValidChart = false)
        debouncer.onFrameResult(isValidChart = false)
        debouncer.reset()
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertFalse(debouncer.onFrameResult(isValidChart = false))
        assertTrue(debouncer.onFrameResult(isValidChart = false))
    }
}
