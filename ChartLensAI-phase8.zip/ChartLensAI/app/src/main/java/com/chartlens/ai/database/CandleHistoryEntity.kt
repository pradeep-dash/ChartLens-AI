package com.chartlens.ai.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.chartlens.ai.analysis.PriceCandle

/** Shared by [com.chartlens.ai.replay.ReplayEngine] and the live analysis pipeline
 * ([com.chartlens.ai.cv.FrameAnalyzer]) — both need the same real recorded history
 * reshaped into the domain model [TechnicalAnalysisEngine][com.chartlens.ai.analysis.TechnicalAnalysisEngine]
 * actually consumes. */
fun CandleHistoryEntity.toPriceCandle(): PriceCandle = PriceCandle(
    index = candleIndex,
    timestampMillis = null,
    open = open,
    high = high,
    low = low,
    close = close
)

/**
 * One real, historically-closed candle recorded during a live capture
 * session — this is what Phase 8's replay engine loads and replays. Only
 * ever written when a candle closed with a trusted price mapping (see
 * [com.chartlens.ai.replay.CandleHistoryRecorder]); there is no synthetic or
 * fabricated data source. A real, disclosed consequence: [candleIndex]
 * sequences can have gaps when price mapping was too weak to trust at the
 * moment a candle closed — the recorded history is real but not always
 * perfectly contiguous.
 */
@Entity(tableName = "candle_history")
data class CandleHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Groups candles from one continuous capture session — the session's own startedAtMillis. */
    val sessionId: Long,
    val candleIndex: Int,
    val timestampMillis: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val direction: String,
    val upperWickPx: Int,
    val lowerWickPx: Int,
    /** Comma-joined CandlePattern names flagged on this candle, empty string if none. */
    val patterns: String,
    /** The detected timeframe label at record time (e.g. "1m"), or null if unknown then. */
    val timeframeLabel: String?,
    val instrument: String
)
