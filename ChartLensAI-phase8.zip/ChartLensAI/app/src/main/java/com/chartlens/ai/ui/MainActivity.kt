package com.chartlens.ai.ui

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import com.chartlens.ai.common.LatestFrameHolder
import com.chartlens.ai.database.CandleHistoryRepository
import com.chartlens.ai.database.PredictionJournalRepository
import com.chartlens.ai.overlay.OverlayService
import com.chartlens.ai.service.ScreenCaptureService
import com.chartlens.ai.settings.AiBackendSettingsStore
import com.chartlens.ai.settings.ManualChartRegionStore
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Hosts the Compose dashboard and owns every permission request that only an
 * Activity context can make (POST_NOTIFICATIONS, SYSTEM_ALERT_WINDOW settings screen,
 * MediaProjectionManager's screen-capture consent dialog). Once all three are
 * satisfied, it hands off to [ScreenCaptureService] and [OverlayService] and gets
 * out of the way — this Activity is not part of the capture pipeline itself.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var captureStateRepository: CaptureStateRepository
    @Inject lateinit var latestFrameHolder: LatestFrameHolder
    @Inject lateinit var manualChartRegionStore: ManualChartRegionStore
    @Inject lateinit var aiBackendSettingsStore: AiBackendSettingsStore
    @Inject lateinit var predictionJournalRepository: PredictionJournalRepository
    @Inject lateinit var candleHistoryRepository: CandleHistoryRepository

    private val viewModel: MainViewModel by viewModels()

    private lateinit var mediaProjectionManager: MediaProjectionManager

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Proceed regardless of grant — the foreground service still functions without
        // POST_NOTIFICATIONS on most OEMs, it just won't show the persistent notification,
        // which the user will notice and can fix in system settings.
        proceedToOverlayPermission()
    }

    private val overlaySettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        if (Settings.canDrawOverlays(this)) {
            proceedToProjectionRequest()
        } else {
            captureStateRepository.update(
                CaptureState.Error(
                    "Overlay permission is required to show live analysis on top of your trading app",
                    recoverable = true
                )
            )
        }
    }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            ScreenCaptureService.start(this, result.resultCode, data)
            OverlayService.start(this)
        } else {
            captureStateRepository.update(
                CaptureState.Error("Screen-capture permission was not granted", recoverable = true)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mediaProjectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        if (intent?.getBooleanExtra(EXTRA_AUTO_START, false) == true) {
            // Consumed immediately: otherwise a later recreation of this Activity (a
            // rotation, a process restart) would see the same flag still set on the same
            // Intent object and re-run the whole permission chain unexpectedly.
            intent.removeExtra(EXTRA_AUTO_START)
            beginStartSequence()
        }

        setContent {
            MaterialTheme {
                var screen by remember { mutableStateOf(Screen.Dashboard) }

                when (screen) {
                    Screen.ChartRegionSelection -> {
                        val previewBitmap by latestFrameHolder.preview.collectAsState()
                        ChartRegionSelectionScreen(
                            previewBitmap = previewBitmap,
                            existingSelection = remember { manualChartRegionStore.load() },
                            onSave = { rect ->
                                manualChartRegionStore.save(rect)
                                screen = Screen.Dashboard
                            },
                            onClear = {
                                manualChartRegionStore.clear()
                                screen = Screen.Dashboard
                            },
                            onBack = { screen = Screen.Dashboard }
                        )
                    }

                    Screen.AiSettings -> {
                        AiSettingsScreen(
                            currentBaseUrl = remember { aiBackendSettingsStore.loadBaseUrl().orEmpty() },
                            currentAuthToken = remember { aiBackendSettingsStore.loadAuthToken().orEmpty() },
                            onSave = { baseUrl, authToken ->
                                aiBackendSettingsStore.saveBaseUrl(baseUrl)
                                aiBackendSettingsStore.saveAuthToken(authToken)
                                screen = Screen.Dashboard
                            },
                            onBack = { screen = Screen.Dashboard }
                        )
                    }

                    Screen.Journal -> {
                        val entries by predictionJournalRepository.observeAll().collectAsState(initial = emptyList())
                        JournalScreen(
                            entries = entries,
                            onBack = { screen = Screen.Dashboard }
                        )
                    }

                    Screen.Replay -> {
                        ReplayScreen(
                            loadSessions = {
                                candleHistoryRepository.getSessionIds().map { id ->
                                    ReplaySessionSummary(id, candleHistoryRepository.countForSession(id))
                                }
                            },
                            runReplay = { sessionId ->
                                val history = candleHistoryRepository.getSession(sessionId)
                                com.chartlens.ai.replay.ReplayEngine().replay(sessionId, history)
                            },
                            onBack = { screen = Screen.Dashboard }
                        )
                    }

                    Screen.Dashboard -> {
                        val state by viewModel.captureState.collectAsState()
                        DashboardScreen(
                            state = state,
                            analysisFrame = viewModel.analysisFrame.collectAsState().value,
                            aiInsight = viewModel.aiInsight.collectAsState().value,
                            onStartClick = ::beginStartSequence,
                            onStopClick = ::stopAnalysis,
                            onResumeClick = ::resumeAnalysis,
                            onSelectChartRegionClick = { screen = Screen.ChartRegionSelection },
                            onAiSettingsClick = { screen = Screen.AiSettings },
                            onJournalClick = { screen = Screen.Journal },
                            onReplayClick = { screen = Screen.Replay }
                        )
                    }
                }
            }
        }
    }

    private enum class Screen { Dashboard, ChartRegionSelection, AiSettings, Journal, Replay }

    private fun beginStartSequence() {
        captureStateRepository.update(CaptureState.AwaitingPermission)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            proceedToOverlayPermission()
        }
    }

    private fun proceedToOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            proceedToProjectionRequest()
        } else {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
        }
    }

    private fun proceedToProjectionRequest() {
        projectionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun stopAnalysis() {
        // Pauses rather than fully stopping — kept consistent with the overlay's own
        // Stop button (see CaptureState.Paused's doc comment for the reasoning and the
        // tradeoff accepted). Deliberately does NOT also call OverlayService.stop(): the
        // overlay persists across a pause so it can offer a Start button, regardless of
        // whether the pause was triggered from here or from the overlay's own control.
        // Only an explicit Dismiss on the overlay itself does a genuine full stop.
        ScreenCaptureService.pause(this)
    }

    /** Resumes a paused session directly — no consent dialog, no permission chain,
     * since the MediaProjection grant from before the pause is still valid. Mirrors
     * OverlayService.onStartRequested()'s same check-then-resume path, so the Dashboard
     * and the overlay behave identically rather than one silently re-prompting. */
    private fun resumeAnalysis() {
        ScreenCaptureService.resume(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // MainActivity is launchMode="singleTop" — a second launch (e.g. tapping Start
        // on the overlay while this Activity is already the top of the back stack)
        // arrives here instead of a fresh onCreate, so auto-start must be handled in
        // both places.
        if (intent.getBooleanExtra(EXTRA_AUTO_START, false)) {
            intent.removeExtra(EXTRA_AUTO_START)
            beginStartSequence()
        }
    }

    companion object {
        /** Set by OverlayService's Start button — see its doc comment for why launching
         * an Activity is unavoidable here (MediaProjection consent can only be requested
         * from an Activity, never from a bare Service). */
        const val EXTRA_AUTO_START = "com.chartlens.ai.EXTRA_AUTO_START"
    }
}
