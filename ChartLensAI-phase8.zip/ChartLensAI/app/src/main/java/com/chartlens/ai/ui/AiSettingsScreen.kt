package com.chartlens.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * There is no default AI backend baked into this app — the user must deploy
 * their own (see `/backend` in the project source) and enter its URL here.
 * The auth token is a shared secret between this app and that backend, never
 * an LLM provider API key (which lives only on the backend server).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettingsScreen(
    currentBaseUrl: String,
    currentAuthToken: String,
    onSave: (baseUrl: String, authToken: String) -> Unit,
    onBack: () -> Unit
) {
    var baseUrl by remember { mutableStateOf(currentBaseUrl) }
    var authToken by remember { mutableStateOf(currentAuthToken) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("AI Backend Settings") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text(
                "ChartLens AI never embeds an AI provider key in the app. To get " +
                    "AI-written explanations for BULLISH/BEARISH predictions, deploy the " +
                    "reference backend in /backend yourself and enter its URL below.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Backend URL") },
                placeholder = { Text("https://your-backend.example.com") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = authToken,
                onValueChange = { authToken = it },
                label = { Text("Auth token") },
                placeholder = { Text("shared secret, matches backend's CLIENT_AUTH_TOKEN") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                "Without this configured, ChartLens AI's local prediction engine " +
                    "(Phase 5) still works fully — this only adds an AI-written " +
                    "explanation on top of it.",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text("Back")
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = { onSave(baseUrl.trim(), authToken.trim()) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }
        }
    }
}
