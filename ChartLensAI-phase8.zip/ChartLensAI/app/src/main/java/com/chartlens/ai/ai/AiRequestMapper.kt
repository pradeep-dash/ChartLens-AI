package com.chartlens.ai.ai

import com.chartlens.ai.analysis.AnalysisFrame

/**
 * Builds the structured [AiAnalysisRequest] from an [AnalysisFrame] — every
 * field is something the local pipeline already computed (Phases 2-5); this
 * class only reshapes it into the request DTO's vocabulary, it never derives
 * new information. Returns null when there's nothing meaningful to ask about
 * (no technical analysis or no prediction yet), consistent with
 * [AiTriggerPolicy] already gating on the same conditions.
 */
object AiRequestMapper {

    fun buildRequest(frame: AnalysisFrame): AiAnalysisRequest? {
        val ta = frame.technicalAnalysis ?: return null
        val prediction = frame.prediction ?: return null

        return AiAnalysisRequest(
            // Instrument-name OCR isn't implemented yet — there's no reliable local
            // source for this field. Sent as "Unknown" rather than guessed; see
            // README "Known limitations" for the honest status of this gap.
            instrument = "Unknown",
            timeframe = frame.timeframeResult?.timeframe?.let { "${it.minutes}m" } ?: "Unknown",
            trend = ta.trend.trend.name,
            trendStrength = ta.trend.trendStrength.toDouble(),
            momentum = ta.momentum.direction.name,
            support = ta.supportResistance.supportLevels.map { it.price },
            resistance = ta.supportResistance.resistanceLevels.map { it.price },
            rsi = ta.rsi14,
            macdHistogram = ta.macd?.histogram,
            emaAlignment = describeEmaAlignment(ta.ema9, ta.ema21, ta.ema50),
            currentPattern = frame.lastCandleContext?.patterns
                ?.takeIf { it.isNotEmpty() }
                ?.joinToString(",") { it.name },
            predictionEngineBias = prediction.direction.name,
            modelConfidence = prediction.modelConfidence,
            dataQuality = frame.dataQuality.name
        )
    }

    private fun describeEmaAlignment(ema9: Double?, ema21: Double?, ema50: Double?): String {
        if (ema9 == null || ema21 == null || ema50 == null) return "UNKNOWN"
        return when {
            ema9 > ema21 && ema21 > ema50 -> "BULLISH_ALIGNED"
            ema9 < ema21 && ema21 < ema50 -> "BEARISH_ALIGNED"
            else -> "MIXED"
        }
    }
}
