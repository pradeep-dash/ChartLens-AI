package com.chartlens.ai.analysis

import kotlin.math.abs

/**
 * Merges the persistently-recorded session history with the current frame's
 * freshly-detected candles — the fix for a real gap: without this, the live
 * pipeline's technical analysis was silently bounded by however many candles
 * happen to fit on screen at once, "forgetting" everything that scrolled out
 * of view even though [com.chartlens.ai.replay.CandleHistoryRecorder] was
 * already persisting it in the background for Phase 8's replay feature.
 *
 * The merge is deliberately conservative: recorded history is always
 * authoritative for everything except the very newest candle, since the
 * recorder only writes a candle *after* [com.chartlens.ai.cv.FrameAnalyzer]
 * finishes analyzing the frame that closed it — so the current frame's most
 * recently closed candle may exist in the live detection a moment before it
 * exists in the recorded history. Only that one candle is ever appended, and
 * only if it isn't already represented.
 *
 * Known limitation, disclosed rather than silently handled: candles are
 * matched by closing price rather than a stable identity, since neither the
 * recorded history's positional `candleIndex` nor the current frame's
 * positional `index` is a reliable cross-frame identifier (both are assigned
 * fresh, left-to-right, from whatever's currently visible). Two genuinely
 * different candles sharing the exact same close price (or a mapping-
 * precision difference making the same candle look very slightly different
 * between when it was recorded and now) could in principle dedupe
 * incorrectly — an accepted tradeoff given there's no stable identity system
 * to match on instead.
 */
object CandleHistoryMerger {

    private const val PRICE_EPSILON = 1e-6

    fun merge(recordedHistory: List<PriceCandle>, currentFrameCandles: List<PriceCandle>): List<PriceCandle> {
        val latestCurrent = currentFrameCandles.lastOrNull() ?: return recordedHistory
        if (recordedHistory.isEmpty()) return currentFrameCandles

        val latestRecorded = recordedHistory.last()
        val alreadyRepresented = abs(latestRecorded.close - latestCurrent.close) < PRICE_EPSILON

        return if (alreadyRepresented) recordedHistory else recordedHistory + latestCurrent
    }
}
