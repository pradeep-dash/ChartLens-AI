package com.chartlens.ai.ai

import kotlinx.serialization.Serializable

/**
 * The structured market-state payload sent to the AI backend — never a raw
 * screenshot or continuous frame stream, per the spec's explicit requirement
 * ("do not send every captured frame to an LLM... only send compact
 * structured market-state information"). Every field here is something the
 * local pipeline has already computed; the AI is being asked to reason about
 * and explain this data, not to see the chart itself.
 */
@Serializable
data class AiAnalysisRequest(
    val instrument: String,
    val timeframe: String,
    val trend: String,
    val trendStrength: Double,
    val momentum: String,
    val support: List<Double>,
    val resistance: List<Double>,
    val rsi: Double? = null,
    val macdHistogram: Double? = null,
    val emaAlignment: String,
    val currentPattern: String? = null,
    val predictionEngineBias: String,
    val modelConfidence: Int,
    val dataQuality: String
)
