package com.chartlens.ai.cv

import com.chartlens.ai.candle.Candle

/**
 * Detects a large, sudden shift in which candles are visible between two
 * consecutive frames — the signal used to catch a manual chart scroll/pan/zoom
 * so [FrameAnalyzer] can force an immediate cache invalidation and disclose
 * the shift, instead of silently serving stale region/OCR caches or looking
 * like arbitrary prediction instability.
 *
 * A heuristic, not a perfect signal — this pipeline has no persistent
 * per-candle identity or real timestamps to compare against, so "did the view
 * change" is inferred from the visible candles' vertical pixel extent
 * overlapping (or not) with the previous frame's. A genuine, very sharp price
 * spike could in principle also trip this; an accepted false-positive rate,
 * since the cost of a wrongly-triggered re-verification (one extra region/OCR
 * pass) is small compared to the cost of silently trusting a stale cache
 * after a real shift.
 */
class ViewShiftDetector(private val overlapThreshold: Double = 0.30) {

    private var previousRange: IntRange? = null

    /** [regionTop] converts each candle's crop-relative Y coordinates to absolute
     * bitmap-relative coordinates, so the comparison stays valid even if the
     * detected chart region's own position shifts slightly between frames. */
    fun update(candles: List<Candle>, regionTop: Int): Boolean {
        val closed = candles.filterNot { it.isForming }
        if (closed.isEmpty()) return false

        val top = closed.minOf { it.wickTopY } + regionTop
        val bottom = closed.maxOf { it.wickBottomY } + regionTop
        val currentRange = top..bottom
        val previous = previousRange
        previousRange = currentRange

        if (previous == null) return false // first frame with data — nothing to compare yet

        val currentHeight = (bottom - top).coerceAtLeast(1)
        val previousHeight = (previous.last - previous.first).coerceAtLeast(1)
        val overlapStart = maxOf(top, previous.first)
        val overlapEnd = minOf(bottom, previous.last)
        val overlap = (overlapEnd - overlapStart).coerceAtLeast(0)
        val smallerHeight = minOf(currentHeight, previousHeight)

        return overlap.toDouble() / smallerHeight < overlapThreshold
    }

    fun reset() {
        previousRange = null
    }
}
