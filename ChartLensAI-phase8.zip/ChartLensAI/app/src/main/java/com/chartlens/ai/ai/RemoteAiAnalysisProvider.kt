package com.chartlens.ai.ai

import com.chartlens.ai.settings.AiBackendSettingsStore
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Builds a Retrofit client lazily from the user's configured backend URL
 * (Settings screen), rather than a compile-time constant — there is no
 * default backend baked into the app, since nothing hosts one for this
 * project; the user must deploy `/backend` themselves and point the app at
 * it. Returns a clear, specific failure (never a crash) when nothing is
 * configured yet or a request fails for any reason — this is a best-effort
 * remote call, and Phase 5's local prediction remains fully functional with
 * or without it.
 *
 * Every successful response is run through [AiResponseValidator] before
 * being returned — this class never hands a raw, unvalidated response
 * upstream, regardless of whether the backend did its own validation.
 */
class RemoteAiAnalysisProvider @Inject constructor(
    private val settingsStore: AiBackendSettingsStore
) : AiAnalysisProvider {

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun analyze(request: AiAnalysisRequest): Result<AiAnalysisResponse> {
        val baseUrl = settingsStore.loadBaseUrl()
        if (baseUrl.isNullOrBlank()) {
            return Result.failure(IllegalStateException("No AI backend URL configured — set one in Settings"))
        }
        val token = settingsStore.loadAuthToken().orEmpty()

        return try {
            val api = buildApi(baseUrl)
            val response = api.analyze("Bearer $token", request)
            val validated = AiResponseValidator.validate(response, request)
                ?: return Result.failure(IllegalStateException("AI response failed validation — discarded, not shown"))
            Result.success(validated)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    private fun buildApi(baseUrl: String): AiAnalysisApi {
        val normalizedUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            // 45s, not a shorter default: free-tier hosts (Render, etc. — see
            // /backend/README.md) spin down an idle service and can take 30-50+
            // seconds to wake up on the first request after inactivity. A shorter
            // timeout would make the very first AI call after any idle period look
            // like a failure when it's actually just a slow, real cold start.
            .readTimeout(45, TimeUnit.SECONDS)
            .build()
        val contentType = "application/json".toMediaType()
        return Retrofit.Builder()
            .baseUrl(normalizedUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
            .create(AiAnalysisApi::class.java)
    }
}
