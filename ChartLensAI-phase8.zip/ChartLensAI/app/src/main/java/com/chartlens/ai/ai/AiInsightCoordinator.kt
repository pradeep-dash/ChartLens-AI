package com.chartlens.ai.ai

import com.chartlens.ai.analysis.AnalysisFrame
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Watches each analyzed frame and, per [AiTriggerPolicy], decides whether to
 * fire a real AI call — never blocking the fast, local frame-analysis
 * pipeline on network I/O. Each triggered call runs in its own coroutine
 * launched into the caller-supplied scope; [AiInsightRepository] is updated
 * with Loading, then Success or Error, independently of the frame pipeline's
 * own cadence.
 */
@Singleton
class AiInsightCoordinator @Inject constructor(
    private val aiAnalysisProvider: AiAnalysisProvider,
    private val aiInsightRepository: AiInsightRepository
) {
    private var lastTriggeredCandleIndex: Int? = null

    fun onNewFrame(frame: AnalysisFrame, scope: CoroutineScope) {
        if (!AiTriggerPolicy.shouldTrigger(frame, lastTriggeredCandleIndex)) return
        val request = AiRequestMapper.buildRequest(frame) ?: return

        lastTriggeredCandleIndex = frame.candleCloseEvent?.closedCandle?.index
        aiInsightRepository.update(AiInsight.Loading)

        scope.launch {
            val result = aiAnalysisProvider.analyze(request)
            result.fold(
                onSuccess = { response ->
                    aiInsightRepository.update(AiInsight.Success(response, System.currentTimeMillis()))
                },
                onFailure = { error ->
                    aiInsightRepository.update(AiInsight.Error(error.message ?: "AI request failed"))
                }
            )
        }
    }

    /** Call on a new capture session so a stale candle index doesn't suppress a real trigger. */
    fun reset() {
        lastTriggeredCandleIndex = null
        aiInsightRepository.update(AiInsight.Idle)
    }
}
