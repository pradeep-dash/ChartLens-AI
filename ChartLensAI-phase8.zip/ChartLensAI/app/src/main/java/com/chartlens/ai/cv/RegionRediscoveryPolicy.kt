package com.chartlens.ai.cv

/**
 * Decides when the cached chart region should be re-detected. Extracted as a
 * pure class (rather than left inline in [FrameAnalyzer], which takes an
 * Android Bitmap and so can't be unit tested here) so this logic is directly
 * verifiable — consistent with how [ViewShiftDetector] was handled.
 *
 * The "cache looks broken" condition is the fix for a real, long-running
 * device bug that took several wrong guesses to pin down: candle counts would
 * stick at 0/1 or 4/5 for an entire session with region confidence still
 * reading 98-99%, never recovering on their own even after a minute idle,
 * but sometimes jumping to a correct 37/38 after the user zoomed around
 * (which triggers [ViewShiftDetector] and forces an invalidation), then
 * resetting to broken again on a chart change.
 *
 * The cause: a stale or subtly-wrong cached region can still score high
 * confidence, because [ChartDetector] scores candle-color density *within
 * whatever region it found* — a region that has drifted onto a narrow or
 * unrepresentative slice genuinely does contain candle-colored pixels and
 * scores well, while containing almost no complete, detectable candles.
 * Nothing ever re-evaluated whether the cached region was actually WORKING,
 * so a bad one persisted for the entire session.
 */
class RegionRediscoveryPolicy(
    private val rediscoverEveryNFrames: Int = 20,
    /** Far below any plausible real chart's candle count — a "this region has clearly
     * stopped working" threshold, not a quality bar, so a genuinely sparse-but-correct
     * region isn't thrashed unnecessarily. */
    private val minCandlesBeforeForcedRediscovery: Int = 5
) {

    fun shouldRediscover(
        hasCachedRegion: Boolean,
        framesSinceRediscovery: Int,
        lastCandleCount: Int
    ): Boolean {
        if (!hasCachedRegion) return true
        if (framesSinceRediscovery >= rediscoverEveryNFrames) return true
        // framesSinceRediscovery > 0 guard: never judge a region by the very frame it was
        // detected on, since lastCandleCount then still refers to the PREVIOUS region's
        // outcome — without this, one bad frame could trigger endless re-detection.
        return framesSinceRediscovery > 0 && lastCandleCount < minCandlesBeforeForcedRediscovery
    }
}
