package com.chartlens.ai.journal

import com.chartlens.ai.ai.AiAnalysisRequest
import com.chartlens.ai.ai.AiRequestMapper
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.database.PredictionEntity
import com.chartlens.ai.database.PredictionJournalRepository
import com.chartlens.ai.prediction.OutcomeEvaluator
import com.chartlens.ai.prediction.PredictionDirection
import com.chartlens.ai.prediction.PredictionOutcome
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Records a new journal entry whenever the local prediction engine produces a
 * real (non-NO_TRADE) call on a freshly-closed candle, and evaluates pending
 * entries once their horizon has actually been reached — never early, never
 * guessed. Deliberately separate from
 * [com.chartlens.ai.ai.AiInsightCoordinator]: journaling happens regardless
 * of whether an AI backend is configured at all, since Phase 5's local
 * predictions are what's actually being scored here.
 *
 * The market-state snapshot reuses [AiRequestMapper]'s output — it's already
 * exactly the structured shape spec §16 wants for `marketStateJson`, and
 * reusing it means this class never re-derives information Phase 6 already
 * computed correctly.
 *
 * Evaluation is index-based, not wall-clock based (see [PredictionEntity]'s
 * doc comment). A target candle that never reappears within a generous
 * buffer after its horizon (likely scrolled out of the visible/cropped chart
 * region) is marked INVALID_DATA rather than left UNRESOLVED forever — a
 * real, disclosed limitation of index-based tracking, not silently ignored.
 */
@Singleton
class JournalCoordinator @Inject constructor(
    private val repository: PredictionJournalRepository
) {
    private val json = Json { ignoreUnknownKeys = true }
    private var lastRecordedCandleIndex: Int? = null

    suspend fun onNewFrame(frame: AnalysisFrame, horizonCandles: Int = 1) {
        maybeRecordPrediction(frame, horizonCandles)
        maybeEvaluatePending(frame)
    }

    private suspend fun maybeRecordPrediction(frame: AnalysisFrame, horizonCandles: Int) {
        val closeEvent = frame.candleCloseEvent ?: return
        val prediction = frame.prediction ?: return
        if (prediction.direction == PredictionDirection.NO_TRADE) return
        if (closeEvent.closedCandle.index == lastRecordedCandleIndex) return

        val entryPrice = frame.priceCandles.lastOrNull { it.index == closeEvent.closedCandle.index }?.close ?: return
        val marketState = AiRequestMapper.buildRequest(frame) ?: return

        lastRecordedCandleIndex = closeEvent.closedCandle.index

        repository.record(
            PredictionEntity(
                timestampMillis = frame.timestampMillis,
                instrument = marketState.instrument,
                timeframe = marketState.timeframe,
                direction = prediction.direction.name,
                modelConfidence = prediction.modelConfidence,
                setup = prediction.setup,
                entryPrice = entryPrice,
                candleIndexAtPrediction = closeEvent.closedCandle.index,
                horizonCandles = horizonCandles,
                marketStateJson = json.encodeToString(AiAnalysisRequest.serializer(), marketState)
            )
        )
    }

    private suspend fun maybeEvaluatePending(frame: AnalysisFrame) {
        val currentMaxClosedIndex = frame.priceCandles.maxOfOrNull { it.index } ?: return
        val pending = repository.getUnresolved()

        for (entry in pending) {
            val targetIndex = entry.candleIndexAtPrediction + entry.horizonCandles
            val candlesElapsed = currentMaxClosedIndex - entry.candleIndexAtPrediction
            if (candlesElapsed < entry.horizonCandles) continue // horizon not reached yet

            val targetCandle = frame.priceCandles.find { it.index == targetIndex }
            if (targetCandle != null) {
                val direction = PredictionDirection.valueOf(entry.direction)
                val outcome = OutcomeEvaluator.evaluate(direction, entry.entryPrice, targetCandle.close)
                repository.recordOutcome(entry.id, outcome, System.currentTimeMillis(), targetCandle.close)
            } else if (candlesElapsed > entry.horizonCandles + STALE_BUFFER_CANDLES) {
                repository.recordOutcome(entry.id, PredictionOutcome.INVALID_DATA, System.currentTimeMillis(), null)
            }
        }
    }

    /** Call on a new capture session so a stale candle index doesn't suppress a real record. */
    fun reset() {
        lastRecordedCandleIndex = null
    }

    private companion object {
        const val STALE_BUFFER_CANDLES = 15
    }
}
