package com.chartlens.ai.ai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AiInsightRepository @Inject constructor() {

    private val _insight = MutableStateFlow<AiInsight>(AiInsight.Idle)
    val insight: StateFlow<AiInsight> = _insight.asStateFlow()

    fun update(insight: AiInsight) {
        _insight.value = insight
    }
}
