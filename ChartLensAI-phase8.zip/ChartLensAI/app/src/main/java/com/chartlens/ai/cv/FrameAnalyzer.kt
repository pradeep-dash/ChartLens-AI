package com.chartlens.ai.cv

import android.graphics.Bitmap
import android.util.Log
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.CandleCloseTracker
import com.chartlens.ai.analysis.CandleHistoryMerger
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.analysis.DataQualityCalculator
import com.chartlens.ai.analysis.PriceCandle
import com.chartlens.ai.analysis.PriceScaleMapper
import com.chartlens.ai.analysis.PriceScaleMapping
import com.chartlens.ai.analysis.TechnicalAnalysisEngine
import com.chartlens.ai.analysis.TimeframeDetector
import com.chartlens.ai.analysis.TimeframeResult
import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDetector
import com.chartlens.ai.candle.CandlePatternDetector
import com.chartlens.ai.candle.ChartStructureValidator
import com.chartlens.ai.common.PixelBuffer
import com.chartlens.ai.ocr.OcrDebugInfo
import com.chartlens.ai.ocr.OcrEngine
import com.chartlens.ai.prediction.LastCandleContext
import com.chartlens.ai.prediction.PredictionEngine

/**
 * The only class in the pipeline that touches `android.graphics.Bitmap` or ML
 * Kit — everything downstream (ChartDetector, CandleDetector,
 * CandlePatternDetector, PriceScaleMapper, TimeframeDetector,
 * TechnicalAnalysisEngine) operates on pure-Kotlin models and is unit tested.
 * This class itself is reviewed by hand, same as the rest of the Bitmap/
 * MediaProjection/ML-Kit boundary.
 *
 * Performance notes (two independent caches, different intervals):
 *  - Chart-region detection is re-run every [rediscoverEveryNFrames] frames —
 *    the chart's on-screen position rarely moves between frames.
 *  - OCR (price + time axis) is re-run every [ocrEveryNFrames] frames, a
 *    longer interval than chart-region rediscovery, since text recognition is
 *    meaningfully more expensive than the pixel-geometry work and the visible
 *    price/time range changes far less often than individual candles do.
 * Neither interval has been tuned against real device measurements yet — see
 * README "Known limitations" for the Phase 9 follow-up.
 *
 * The technical-analysis input can optionally be extended beyond just what's
 * currently on screen via [sessionHistoryProvider] — see [com.chartlens.ai.analysis.CandleHistoryMerger]'s
 * doc comment for why this exists: without it, indicators were silently
 * bounded by whatever fits on screen at once, "forgetting" anything that had
 * scrolled out of view even though it was already being recorded elsewhere
 * for Phase 8's replay feature.
 *
 * Price-axis/time-axis crop regions assume the common trading-app convention
 * this project was tested against: price labels along the right edge of the
 * screen, time labels along the bottom. The price-axis strip is anchored to
 * the bitmap's right edge (not the detected chart region's right edge) since
 * real charts often reserve blank space between the last candle and the
 * price axis — anchoring to the screen edge instead of the candle region
 * proved necessary after a real device test found the original region-relative
 * crop landing entirely in that blank space and finding zero text. A platform
 * using the opposite convention (price axis on the left) would need this
 * adjusted — documented as a known limitation, not silently handled.
 */
class FrameAnalyzer(
    private val chartDetector: ChartDetector = ChartDetector(),
    private val candleDetector: CandleDetector = CandleDetector(),
    private val patternDetector: CandlePatternDetector = CandlePatternDetector(),
    private val ocrEngine: OcrEngine = OcrEngine(),
    private val priceScaleMapper: PriceScaleMapper = PriceScaleMapper(),
    private val timeframeDetector: TimeframeDetector = TimeframeDetector(),
    private val technicalAnalysisEngine: TechnicalAnalysisEngine = TechnicalAnalysisEngine(),
    private val candleCloseTracker: CandleCloseTracker = CandleCloseTracker(),
    private val predictionEngine: PredictionEngine = PredictionEngine(),
    private val rediscoverEveryNFrames: Int = 20,
    private val ocrEveryNFrames: Int = 30,
    private val minPriceMappingConfidenceForAnalysis: Float = 0.6f,
    private val regionRediscoveryPolicy: RegionRediscoveryPolicy =
        RegionRediscoveryPolicy(rediscoverEveryNFrames = rediscoverEveryNFrames),
    private val chartStructureValidator: ChartStructureValidator = ChartStructureValidator(),
    // Optional: supplies the full recorded history for this session (see
    // CandleHistoryRecorder/CandleHistoryRepository), so technical analysis isn't
    // silently bounded by however many candles happen to fit on screen at once. Null
    // by default (and in every existing unit test) — falls back to exactly the prior
    // on-screen-only behavior when no session/database is available to supply it.
    private val sessionHistoryProvider: (suspend () -> List<PriceCandle>)? = null
) {
    private var cachedAutoRegion: ChartRegion? = null
    private var framesSinceRediscovery = 0
    private val viewShiftDetector = ViewShiftDetector()

    private var cachedPriceScaleMapping: PriceScaleMapping? = null
    private var cachedTimeframeResult: TimeframeResult? = null
    private var cachedOcrDebug: OcrDebugInfo? = null
    private var framesSinceOcr = Int.MAX_VALUE // force an OCR pass on the first eligible frame
    private var lastCandleCount = Int.MAX_VALUE // MAX_VALUE so the very first frame never looks "broken"
    private val structuralRejectionDebouncer = StructuralRejectionDebouncer()
    private var lastGoodFrame: AnalysisFrame? = null

    suspend fun analyze(bitmap: Bitmap, manualRegion: ChartRegion?, timestampMillis: Long): AnalysisFrame {
        val fullBuffer = bitmap.toPixelBuffer()
        val region = manualRegion ?: resolveAutoRegion(fullBuffer, lastCandleCount)

        if (region == null || !region.isUsable()) {
            lastCandleCount = 0 // an unusable region yielded nothing; don't leave a stale count behind
            return AnalysisFrame(
                timestampMillis = timestampMillis,
                chartRegion = region,
                candles = emptyList(),
                patternMatches = emptyList(),
                dataQuality = DataQuality.INVALID
            )
        }

        val cropped = fullBuffer.crop(
            left = region.left.coerceIn(0, fullBuffer.width),
            top = region.top.coerceIn(0, fullBuffer.height),
            right = region.right.coerceIn(0, fullBuffer.width),
            bottom = region.bottom.coerceIn(0, fullBuffer.height)
        )

        val candles = candleDetector.detect(cropped)
        lastCandleCount = candles.count { !it.isForming }

        // Structural gate — see ChartStructureValidator's doc comment. If what was
        // detected doesn't actually look like a candlestick chart (the real case that
        // motivated this: a text conversation on screen reporting "60/61 candles ·
        // quality GOOD"), stop here and report nothing rather than feeding screen noise
        // into indicators and producing a confident-looking prediction from it.
        val structureResult = chartStructureValidator.validate(candles)
        if (!structureResult.isValidChart) {
            val shouldSurface = structuralRejectionDebouncer.onFrameResult(isValidChart = false)
            val coastCandidate = lastGoodFrame
            if (!shouldSurface && coastCandidate != null) {
                // A single (or a couple of) bad frames coast on the last known-good
                // result instead of flashing "no chart detected" — see
                // StructuralRejectionDebouncer's doc comment for the real device
                // report this fixes. Only the timestamp changes; the analysis itself
                // is a genuine result from an earlier frame, not fabricated here.
                return coastCandidate.copy(timestampMillis = timestampMillis)
            }
            return AnalysisFrame(
                timestampMillis = timestampMillis,
                chartRegion = region,
                candles = emptyList(),
                patternMatches = emptyList(),
                dataQuality = DataQuality.INVALID,
                candleDetectionDebug = candleDetector.lastDebug,
                chartRejectionReason = structureResult.reason
            )
        }

        // A real device test showed the prediction jumping abruptly between two frames
        // 15 seconds apart, with the chart's visible time window having shifted ~16
        // minutes — almost certainly a manual scroll/pan of the chart, not natural candle
        // progression. That's not actually a bug in the analysis itself (this pipeline
        // only ever reads whatever is currently on screen, by design — it has no
        // persistent memory of "true" chart history beyond that), but two real problems
        // sit underneath the confusing symptom: (1) nothing disclosed that a shift had
        // happened, so a legitimate re-analysis of genuinely different data looked like
        // arbitrary instability, and (2) the region/OCR caches (good for 20-30 frames on
        // a stable chart) could keep serving stale, now-mismatched crops for several
        // frames after a shift before naturally refreshing. This detects a large,
        // sudden change in the visible candles' vertical pixel extent — a heuristic, not
        // a perfect signal (it can't fully replace real per-candle timestamps, which
        // this pipeline doesn't have), but it catches the common case and forces an
        // immediate, honest re-verification instead of silently trusting stale state.
        val viewChanged = viewShiftDetector.update(candles, region.top)
        if (viewChanged) {
            candleCloseTracker.reset()
            framesSinceRediscovery = rediscoverEveryNFrames
            framesSinceOcr = ocrEveryNFrames
        }

        val patterns = patternDetector.detect(candles)
        val closeEvent = candleCloseTracker.update(candles)

        runOcrIfDue(bitmap, region, candles)

        val priceMapping = cachedPriceScaleMapping
        // Only convert to real prices and run technical analysis when the mapping is
        // trustworthy enough to be worth it. A weak mapping (e.g. fitted from only 2 poor
        // labels, capped at 50% confidence by design) can still produce a mathematically
        // valid-looking line — feeding it through would produce specific, precise-looking
        // indicator values (an exact RSI, exact EMA numbers) built on essentially
        // guesswork, which is exactly the kind of falsely-confident output the "never
        // fabricate" rules exist to prevent. This gate was added after a real device test
        // showed EMA values in the thousands on a chart where the real price was ~0.69 —
        // mathematically consistent with the (bad) mapping, but obviously wrong, and nothing
        // upstream was stopping it from being computed and displayed as if it meant something.
        val priceCandles = if (priceMapping != null && priceMapping.confidence >= minPriceMappingConfidenceForAnalysis) {
            candles.filterNot { it.isForming }.map { it.toPriceCandle(priceMapping) }
        } else {
            emptyList()
        }

        // priceCandles (above) stays exactly what it always was — the current frame's
        // own on-screen candles — since JournalCoordinator/AiRequestMapper/lastCandleContext
        // below all match against it by this-frame index and would silently break if its
        // meaning changed. The recorded session history (when available) only enriches
        // what TechnicalAnalysisEngine itself sees, via a separate variable — the fix for
        // indicators being "forgotten" once a candle scrolls off screen, without touching
        // any of the index-matching logic that already works correctly.
        val analysisInputCandles = if (sessionHistoryProvider != null) {
            val recordedHistory = try {
                sessionHistoryProvider.invoke()
            } catch (t: Throwable) {
                Log.w(TAG, "Failed to load recorded session history, using on-screen candles only", t)
                emptyList()
            }
            if (recordedHistory.isNotEmpty()) {
                CandleHistoryMerger.merge(recordedHistory, priceCandles)
            } else {
                priceCandles
            }
        } else {
            priceCandles
        }
        val technicalAnalysis = if (analysisInputCandles.isNotEmpty()) {
            technicalAnalysisEngine.analyze(analysisInputCandles)
        } else {
            null
        }

        val quality = DataQualityCalculator.calculate(region.confidence, candles, priceMapping?.confidence)

        val closedPixelCandles = candles.filterNot { it.isForming }
        val lastClosedCandle = closedPixelCandles.maxByOrNull { it.index }
        val lastClosedPriceCandle = priceCandles.maxByOrNull { it.index }
        val lastCandleContext = if (lastClosedCandle != null && lastClosedPriceCandle != null) {
            LastCandleContext(
                closePrice = lastClosedPriceCandle.close,
                direction = lastClosedCandle.direction,
                upperWickPx = lastClosedCandle.upperWickPx,
                lowerWickPx = lastClosedCandle.lowerWickPx,
                patterns = patterns.find { it.candleIndex == lastClosedCandle.index }?.patterns ?: emptySet()
            )
        } else {
            null
        }
        val prediction = predictionEngine.predict(
            technicalAnalysis = technicalAnalysis,
            // Must match analysisInputCandles, not closedPixelCandles — a real device test
            // showed a frame with rich, sensible technical analysis (RSI 50.6, real EMAs,
            // a coherent trend) computed from the accumulated session history, immediately
            // followed by "not enough closed candles yet" — because this gate was still
            // using the narrow, this-frame-only on-screen count instead of the same merged
            // series technicalAnalysis was actually computed from. Introduced by the
            // CandleHistoryMerger fix (which correctly widened the analysis input) without
            // widening this gate to match — a real inconsistency, not a design choice.
            closedCandleCount = analysisInputCandles.size,
            lastCandle = lastCandleContext,
            timeframe = cachedTimeframeResult?.timeframe
        )

        structuralRejectionDebouncer.onFrameResult(isValidChart = true)

        val result = AnalysisFrame(
            timestampMillis = timestampMillis,
            chartRegion = region,
            candles = candles,
            patternMatches = patterns,
            dataQuality = quality,
            priceScaleMapping = priceMapping,
            timeframeResult = cachedTimeframeResult,
            priceCandles = priceCandles,
            technicalAnalysis = technicalAnalysis,
            candleCloseEvent = closeEvent,
            ocrDebug = cachedOcrDebug,
            prediction = prediction,
            lastCandleContext = lastCandleContext,
            viewChanged = viewChanged,
            candleDetectionDebug = candleDetector.lastDebug
        )
        lastGoodFrame = result
        return result
    }

    /** Call when the user changes/clears the manual selection, or on a new capture session. */
    fun invalidateCache() {
        cachedAutoRegion = null
        framesSinceRediscovery = 0
        cachedPriceScaleMapping = null
        cachedTimeframeResult = null
        cachedOcrDebug = null
        framesSinceOcr = Int.MAX_VALUE
        lastCandleCount = Int.MAX_VALUE
        viewShiftDetector.reset()
        candleCloseTracker.reset()
        structuralRejectionDebouncer.reset()
        lastGoodFrame = null
    }

    fun close() {
        ocrEngine.close()
    }

    /**
     * Resolves the chart region, re-detecting on the normal interval — but ALSO
     * immediately when the currently-cached region has stopped producing a
     * sensible number of candles.
     *
     * The second condition is the fix for a real, long-running device bug that took
     * several wrong guesses to pin down: candle counts would get stuck at 0/1 or 4/5
     * for a whole session with region confidence still reading 98-99%, never
     * recovering on their own even after a minute idle, but sometimes jumping to a
     * correct 37/38 after the user zoomed around (which triggers ViewShiftDetector,
     * forcing an invalidation), and resetting to broken again on a chart change.
     *
     * The cause is that a stale or subtly-wrong cached region can still score high
     * confidence — ChartDetector scores density *within whatever region it found*,
     * so a region that has drifted onto a narrow or unrepresentative slice genuinely
     * does contain candle-colored pixels and scores well, while containing almost no
     * complete, detectable candles. Nothing ever re-evaluated whether the cached
     * region was actually WORKING, so a bad one persisted for the whole session.
     *
     * [lastCandleCount] lets this check the previous frame's real outcome: a region
     * that yielded almost nothing last frame is re-detected now rather than trusted
     * for another 20 frames. Deliberately conservative — only triggers below
     * [minCandlesBeforeForcedRediscovery], which is far below any plausible real
     * chart, so a genuinely sparse-but-correct region isn't thrashed unnecessarily.
     */
    private fun resolveAutoRegion(fullBuffer: PixelBuffer, lastCandleCount: Int): ChartRegion? {
        val shouldRediscover = regionRediscoveryPolicy.shouldRediscover(
            hasCachedRegion = cachedAutoRegion != null,
            framesSinceRediscovery = framesSinceRediscovery,
            lastCandleCount = lastCandleCount
        )

        return if (shouldRediscover) {
            framesSinceRediscovery = 0
            chartDetector.detect(fullBuffer).also { cachedAutoRegion = it }
        } else {
            framesSinceRediscovery++
            cachedAutoRegion
        }
    }

    private suspend fun runOcrIfDue(bitmap: Bitmap, region: ChartRegion, candles: List<Candle>) {
        if (framesSinceOcr < ocrEveryNFrames) {
            framesSinceOcr++
            return
        }
        framesSinceOcr = 0

        val priceAxisBitmap = cropPriceAxisStrip(bitmap, region)
        val timeAxisBitmap = cropTimeAxisStrip(bitmap, region)

        var priceAxisError: String? = null
        var timeAxisError: String? = null

        val priceAxisLabels = try {
            if (priceAxisBitmap == null) {
                priceAxisError = "crop returned null (degenerate region)"
                emptyList()
            } else {
                ocrEngine.recognize(priceAxisBitmap)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Price-axis OCR failed", t)
            priceAxisError = "${t::class.simpleName}: ${t.message}"
            emptyList()
        }

        val timeAxisLabels = try {
            if (timeAxisBitmap == null) {
                timeAxisError = "crop returned null (degenerate region)"
                emptyList()
            } else {
                ocrEngine.recognize(timeAxisBitmap)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Time-axis OCR failed", t)
            timeAxisError = "${t::class.simpleName}: ${t.message}"
            emptyList()
        }

        cachedOcrDebug = OcrDebugInfo(
            priceAxisRawTexts = priceAxisLabels.map { it.text }.take(12),
            timeAxisRawTexts = timeAxisLabels.map { it.text }.take(12),
            priceAxisCropSize = priceAxisBitmap?.let { "${it.width}x${it.height}" },
            timeAxisCropSize = timeAxisBitmap?.let { "${it.width}x${it.height}" },
            priceAxisError = priceAxisError,
            timeAxisError = timeAxisError
        )

        priceScaleMapper.fit(priceAxisLabels)?.let { cachedPriceScaleMapping = it }
        // If fit() returns null (not enough usable labels this pass), keep the previous
        // mapping rather than blank it out — a single bad OCR pass on an otherwise
        // stable price axis shouldn't throw away a good mapping from moments ago.

        val timeframe = timeframeDetector.detect(timeAxisLabels, candles)
        if (timeframe.timeframe != null || cachedTimeframeResult == null) {
            // Same "don't blank out a good cached result on one bad pass" policy as
            // price mapping above — but only once we have any cached result at all;
            // the very first attempt should always be recorded, even if inconclusive,
            // so the UI shows "estimated but unmatched" rather than nothing at all.
            cachedTimeframeResult = timeframe
        }
    }

    private fun cropPriceAxisStrip(bitmap: Bitmap, region: ChartRegion): Bitmap? {
        // Spans the ENTIRE remaining width to the right of the candles, not a fixed
        // guessed width — a fixed width has now proven wrong in both directions on two
        // different real layouts: too narrow on a portrait layout with blank chart space
        // reserved after the last candle, and (anchoring to the screen edge instead)
        // wrong on a wide/landscape layout with a persistent sidebar occupying the actual
        // screen edge, which pulled in sidebar text ("Withdrawal", trade amounts) instead
        // of the chart's own price axis. Rather than keep guessing a pixel width that's
        // fundamentally layout-dependent, this crops generously and relies on
        // PriceScaleMapper's X-position clustering to find the real axis among whatever
        // else gets swept in — that logic is much better positioned to tell "a vertically
        // stacked column of prices" apart from scattered sidebar noise than a fixed guess
        // made without seeing the layout ever is.
        //
        // minWidthPx is a hard floor, not a preference: a real device test found
        // region.right landing just 22px from the bitmap's right edge on one chart
        // (the last candle happened to be detected very close to the screen edge),
        // producing a crop narrower than ML Kit's own minimum input size (32x32) and
        // throwing MlKitException on every single OCR attempt — a silent, total
        // failure that "0 labels found" alone didn't distinguish from a legitimate
        // empty read. left now expands into the chart region itself when necessary to
        // guarantee at least minWidthPx, rather than trusting region.right blindly.
        //
        // 200px, not just-above-32px: an earlier version of this fix used 60px —
        // enough to stop the crash, but a second device test showed it wasn't enough
        // to capture full label text ("92.700" truncated down to just "700", losing
        // the "92." prefix entirely). The truncated fragments were still evenly
        // spaced relative to each other, so PriceScaleMapper fit a clean, confident
        // line through completely wrong values — a confidently-wrong mapping is worse
        // than an obviously-failed one. 200px comfortably fits full multi-digit
        // labels at the font sizes observed so far.
        val minWidthPx = 200
        val idealLeft = region.right.coerceIn(0, bitmap.width)
        val left = minOf(idealLeft, bitmap.width - minWidthPx).coerceAtLeast(0)
        val right = bitmap.width
        val top = region.top.coerceIn(0, bitmap.height)
        val bottom = region.bottom.coerceIn(0, bitmap.height)
        if (right <= left || bottom <= top) return null
        return safeCrop(bitmap, left, top, right - left, bottom - top)
    }

    private fun cropTimeAxisStrip(bitmap: Bitmap, region: ChartRegion): Bitmap? {
        // Spans the ENTIRE remaining height below the chart, not a fixed guessed
        // height — mirrors the exact fix that resolved the price-axis crop's width
        // problem days ago, applied here after the same symptom (near-zero useful
        // text found) persisted on the time axis for many rounds without the same
        // scrutiny. A fixed 150px height assumed the time-axis label row sits close
        // below the last candle wick; if there's more vertical gap than that on a
        // given chart (plausible — the price-axis crop had exactly this problem
        // horizontally), the crop would end before ever reaching real label text.
        // TimeTextParser's strict HH:mm-only regex is what makes cropping this
        // generously safe — trading-panel UI text below the chart (Timer,
        // Investment, Payout, Up/Down) simply won't match and gets filtered out,
        // same reasoning as the price-axis fix relying on PriceScaleMapper's
        // clustering to filter its own wider net.
        val minHeightPx = 60
        val idealTop = region.bottom.coerceIn(0, bitmap.height)
        val top = minOf(idealTop, (bitmap.height - minHeightPx).coerceAtLeast(0))
        val bottom = bitmap.height
        val left = 0
        val right = bitmap.width
        if (right <= left || bottom <= top) return null
        return safeCrop(bitmap, left, top, right - left, bottom - top)
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, width: Int, height: Int): Bitmap? {
        return try {
            Bitmap.createBitmap(bitmap, x, y, width, height)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to crop OCR strip at ($x,$y,$width,$height)", t)
            null
        }
    }

    private fun Candle.toPriceCandle(mapping: PriceScaleMapping): PriceCandle = PriceCandle(
        index = index,
        timestampMillis = null, // real timestamps need timeframe + a reference clock — not derived here
        open = mapping.priceAt(openY.toDouble()),
        high = mapping.priceAt(highY.toDouble()),
        low = mapping.priceAt(lowY.toDouble()),
        close = mapping.priceAt(closeY.toDouble())
    )

    private fun Bitmap.toPixelBuffer(): PixelBuffer {
        val pixels = IntArray(width * height)
        getPixels(pixels, 0, width, 0, 0, width, height)
        return PixelBuffer(width, height, pixels)
    }

    private companion object {
        const val TAG = "FrameAnalyzer"
    }
}
