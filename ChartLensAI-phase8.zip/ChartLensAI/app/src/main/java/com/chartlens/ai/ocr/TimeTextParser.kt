package com.chartlens.ai.ocr

/**
 * Parses a time-axis label like "21:36" into minutes since midnight. Returns
 * null for anything that doesn't look like a valid 24-hour time — never
 * guesses at a partially-garbled reading.
 *
 * Rejects the whole string outright if it matches an H:MM:SS pattern
 * (e.g. "00:01:00") before attempting any extraction — added after a real
 * device test showed a countdown-timer display ("00:01:00", the 1-minute
 * trade timer, not a chart time-axis label) being picked up by the same
 * OCR pass as real time labels. A naive HH:mm regex still finds "00:01"
 * within "00:01:00" and happily parses it as 12:01am, a wildly wrong value
 * mixed in among genuine ~600-minute readings with no safeguard to catch it
 * downstream — the same failure shape as an earlier `PriceTextParser` bug
 * where a naive decimal regex found a valid-looking sub-match inside a
 * comma-grouped monetary figure. The fix is the same: reject the whole
 * string if the wrong overall shape is present, rather than trying to
 * extract a plausible-but-wrong value from part of it.
 *
 * Known limitation: does not handle a chart spanning midnight (e.g. labels
 * "23:52" then "00:08") — [com.chartlens.ai.analysis.TimeframeDetector] fits a
 * simple linear regression over these values, which would see the wraparound
 * as a large negative jump rather than a small forward step. Documented rather
 * than silently handled; worth fixing if real testing shows charts commonly
 * cross midnight.
 */
object TimeTextParser {

    private val countdownSignature = Regex("""\d{1,2}:\d{2}:\d{2}""")
    private val timePattern = Regex("""(\d{1,2}):(\d{2})""")

    fun parseMinutesSinceMidnight(rawText: String): Int? {
        val cleaned = rawText.trim()
        if (countdownSignature.containsMatchIn(cleaned)) return null

        val match = timePattern.find(cleaned) ?: return null
        val hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        return hour * 60 + minute
    }
}
