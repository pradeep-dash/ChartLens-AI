package com.chartlens.ai.prediction

/**
 * The result of checking a past prediction against what actually happened.
 * [UNRESOLVED] is the initial state for every journaled prediction — set only
 * by [OutcomeEvaluator] once the prediction's horizon has actually been
 * reached, never guessed early. [INVALID_DATA] covers the case where the
 * outcome genuinely can't be determined (e.g. the target candle scrolled out
 * of the visible/cropped region before evaluation could happen) — a real,
 * honest outcome in its own right, not an error to hide.
 */
enum class PredictionOutcome { WIN, LOSS, NEUTRAL, UNRESOLVED, INVALID_DATA }
