package com.chartlens.ai.prediction

/**
 * UP/DOWN/NO_TRADE only — never a forced direction. See [PredictionEngine] for
 * the conditions that force NO_TRADE regardless of what the evidence leans
 * toward.
 */
enum class PredictionDirection { UP, DOWN, NO_TRADE }

/**
 * Every reason a prediction can be forced to NO_TRADE. Multiple reasons can
 * apply to a single NO_TRADE result — this project treats "why did it decline
 * to predict" as important, structured information, not an afterthought.
 */
enum class NoTradeReason {
    INSUFFICIENT_DATA,
    INSUFFICIENT_CANDLES,
    CONFLICTING_EVIDENCE,
    LOW_DIRECTIONAL_CONFIDENCE,
    UNKNOWN_TIMEFRAME,
    PRICE_NEAR_KEY_LEVEL,
    ABNORMAL_VOLATILITY,
    DOJI_CHOP
}

/** Shared by the Dashboard and the overlay — a single human-readable source of truth
 * for these reasons, rather than duplicating the wording in two places. */
fun NoTradeReason.readableLabel(): String = when (this) {
    NoTradeReason.INSUFFICIENT_DATA -> "not enough data yet"
    NoTradeReason.INSUFFICIENT_CANDLES -> "not enough closed candles yet"
    NoTradeReason.CONFLICTING_EVIDENCE -> "evidence conflicts"
    NoTradeReason.LOW_DIRECTIONAL_CONFIDENCE -> "no clear directional lean"
    NoTradeReason.UNKNOWN_TIMEFRAME -> "timeframe not confirmed"
    NoTradeReason.PRICE_NEAR_KEY_LEVEL -> "price sitting at a key level"
    NoTradeReason.ABNORMAL_VOLATILITY -> "volatility is elevated"
    NoTradeReason.DOJI_CHOP -> "last candle shows indecision"
}

/**
 * One piece of evidence's contribution to the overall score.
 *
 * [score] is this evidence source's own directional lean, from -1.0 (strongly
 * bearish) to +1.0 (strongly bullish), independent of how much [weight] it's
 * given in the final combination. [applicable] is false when this evidence
 * source didn't have enough data to say anything at all (e.g. RSI is null) —
 * an inapplicable signal contributes nothing to the final score rather than
 * being silently treated as neutral, which would be a different (fabricated)
 * claim than "we don't know."
 */
data class EvidenceSignal(
    val name: String,
    val score: Double,
    val applicable: Boolean,
    val weight: Double
)

/**
 * [modelConfidence] is explicitly a raw heuristic score (0-100), NOT a
 * calibrated probability — per the spec's requirement, this must never be
 * presented as "72% chance." It becomes a real probability only after
 * historical calibration against actual outcomes, which needs Phase 7's
 * prediction journal and doesn't exist yet. Always 0 when [direction] is
 * NO_TRADE, since there is no direction to be confident about.
 */
data class PredictionResult(
    val direction: PredictionDirection,
    val modelConfidence: Int,
    val evidence: List<EvidenceSignal>,
    val noTradeReasons: List<NoTradeReason>,
    val setup: String?,
    /**
     * Informational only — NEVER a trade signal, never journaled, never counted toward
     * accuracy stats. Populated only when a gate blocked what the raw evidence would
     * otherwise have called (e.g. price sitting right at a key level, or the timeframe
     * being momentarily unknown) — added because a hard NO_TRADE gate correctly protects
     * against fabricated confidence, but throwing away the direction the evidence was
     * actually leaning is more silence than the situation calls for. Null whenever the
     * raw evidence itself was too weak or too mixed to have a real lean in the first
     * place (LOW_DIRECTIONAL_CONFIDENCE on genuinely unclear evidence, not a gate
     * blocking an otherwise-clear one) — there's nothing honest to show in that case.
     */
    val directionalLean: DirectionalLean? = null
)

data class DirectionalLean(val direction: PredictionDirection, val rawScore: Int)
