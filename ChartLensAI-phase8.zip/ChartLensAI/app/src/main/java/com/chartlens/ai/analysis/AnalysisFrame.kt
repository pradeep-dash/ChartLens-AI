package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDetectionDebug
import com.chartlens.ai.candle.CandlePatternMatch
import com.chartlens.ai.cv.ChartRegion
import com.chartlens.ai.ocr.OcrDebugInfo
import com.chartlens.ai.prediction.LastCandleContext
import com.chartlens.ai.prediction.PredictionResult

/**
 * Everything the pipeline knows about a single analyzed frame.
 *
 * [priceScaleMapping]/[timeframeResult]/[priceCandles]/[technicalAnalysis] are
 * all null/empty until Phase 3's OCR successfully reads the price and time
 * axes — there is no fallback that fabricates them. [priceCandles] only ever
 * contains CLOSED candles (see [Candle.isForming]), consistent with never
 * treating an unfinished candle as confirmed data.
 *
 * [prediction] is Phase 5's contribution — a weighted directional read (or a
 * NO_TRADE with reasons) built from everything above. Its confidence is
 * explicitly a raw heuristic score, never a calibrated probability — see
 * [com.chartlens.ai.prediction.PredictionResult]'s doc comment. Null until
 * [technicalAnalysis] itself is non-null; there is nothing to predict from
 * without it.
 */
data class AnalysisFrame(
    val timestampMillis: Long,
    val chartRegion: ChartRegion?,
    val candles: List<Candle>,
    val patternMatches: List<CandlePatternMatch>,
    val dataQuality: DataQuality,
    val priceScaleMapping: PriceScaleMapping? = null,
    val timeframeResult: TimeframeResult? = null,
    val priceCandles: List<PriceCandle> = emptyList(),
    val technicalAnalysis: TechnicalAnalysisResult? = null,
    val candleCloseEvent: CandleCloseEvent? = null,
    val ocrDebug: OcrDebugInfo? = null,
    val prediction: PredictionResult? = null,
    val lastCandleContext: LastCandleContext? = null,
    val viewChanged: Boolean = false,
    val candleDetectionDebug: CandleDetectionDebug? = null,
    /** Non-null when structural validation rejected this frame — see ChartStructureValidator. */
    val chartRejectionReason: String? = null
) {
    val closedCandleCount: Int get() = candles.count { !it.isForming }
}

