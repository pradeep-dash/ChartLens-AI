package com.chartlens.ai.ai

import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.prediction.PredictionDirection

/**
 * Decides whether THIS frame is worth spending an AI call on. Per the spec's
 * "prefer deterministic local analysis over unnecessary AI calls" and "do not
 * send every captured frame to an LLM" — an AI call only fires when a candle
 * has just closed AND the local PredictionEngine found an actual directional
 * signal worth having explained. A NO_TRADE result has nothing for the AI to
 * usefully add — it would just be restating "no clear setup" at real cost
 * (network, backend rate limit, LLM tokens) for no benefit.
 *
 * Pure Kotlin — takes the caller's own record of which candle it last
 * triggered on, rather than holding that state itself, so this stays fully
 * unit-testable without any service/coroutine machinery.
 */
object AiTriggerPolicy {

    fun shouldTrigger(frame: AnalysisFrame, lastTriggeredCandleIndex: Int?): Boolean {
        val closeEvent = frame.candleCloseEvent ?: return false
        val prediction = frame.prediction ?: return false
        if (prediction.direction == PredictionDirection.NO_TRADE) return false
        if (frame.technicalAnalysis == null) return false
        return closeEvent.closedCandle.index != lastTriggeredCandleIndex
    }
}
