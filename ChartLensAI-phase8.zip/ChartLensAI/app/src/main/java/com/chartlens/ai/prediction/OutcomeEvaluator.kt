package com.chartlens.ai.prediction

import kotlin.math.abs

/**
 * Decides a prediction's real outcome by comparing the price at the moment
 * it was made against the price once its horizon was actually reached — the
 * only honest way to score a prediction. Never called before the horizon is
 * reached; the caller (see `JournalCoordinator`) is responsible for that
 * timing, this class only does the comparison itself.
 */
object OutcomeEvaluator {

    /** Price moves smaller than this fraction are treated as noise, not a real win/loss —
     * without this, a prediction could "win" or "lose" on a move too small to mean anything. */
    private const val NEUTRAL_THRESHOLD_FRACTION = 0.0002

    fun evaluate(direction: PredictionDirection, entryPrice: Double, evaluationPrice: Double): PredictionOutcome {
        if (direction == PredictionDirection.NO_TRADE) return PredictionOutcome.INVALID_DATA
        if (entryPrice <= 0.0) return PredictionOutcome.INVALID_DATA

        val changeFraction = (evaluationPrice - entryPrice) / entryPrice
        if (abs(changeFraction) < NEUTRAL_THRESHOLD_FRACTION) return PredictionOutcome.NEUTRAL

        return when (direction) {
            PredictionDirection.UP -> if (changeFraction > 0) PredictionOutcome.WIN else PredictionOutcome.LOSS
            PredictionDirection.DOWN -> if (changeFraction < 0) PredictionOutcome.WIN else PredictionOutcome.LOSS
            PredictionDirection.NO_TRADE -> PredictionOutcome.INVALID_DATA
        }
    }
}
