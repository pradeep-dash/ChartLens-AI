package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.ocr.OcrTextBlock
import com.chartlens.ai.ocr.TimeTextParser
import kotlin.math.abs

enum class Timeframe(val minutes: Int) {
    M1(1), M5(5), M15(15), M30(30), H1(60);

    companion object {
        /** Snaps to the nearest common interval only if within [toleranceFraction] — otherwise null. */
        fun nearestOrNull(estimatedMinutes: Double, toleranceFraction: Double = 0.25): Timeframe? {
            if (estimatedMinutes <= 0) return null
            val best = entries.minByOrNull { abs(it.minutes - estimatedMinutes) } ?: return null
            val relativeError = abs(best.minutes - estimatedMinutes) / best.minutes
            return if (relativeError <= toleranceFraction) best else null
        }
    }
}

/**
 * [timeframe] is null when detection isn't confident enough to snap to a
 * known interval — the spec's "Timeframe: Unknown rather than guessing"
 * requirement (§8). [estimatedMinutesPerCandle] is still surfaced even when
 * [timeframe] is null, so a caller/debug view can see *why* it didn't match
 * (e.g. "estimated 3.2 min/candle" makes clear it's between two known
 * intervals rather than the detector having failed outright).
 */
data class TimeframeResult(
    val timeframe: Timeframe?,
    val estimatedMinutesPerCandle: Double?,
    val confidence: Float
)

/**
 * Infers the candle interval by combining two independently-measured
 * quantities: minutes-per-pixel (from time-axis OCR labels) and pixels-per-
 * candle (from Phase 2's detected candle spacing) — never inferred from screen
 * dimensions alone, per the "do not assume the interval from screen
 * dimensions" requirement.
 *
 * Two robustness passes were added after a real device test showed a 15m
 * result on a chart that was actually 1m — a 15x error that a single bad
 * input could plausibly cause, and this class originally had zero tolerance
 * for one:
 *  1. **Iterative outlier removal on the time-label regression**, mirroring
 *     [PriceScaleMapper]'s approach exactly (median-based residual detection,
 *     same reasoning: a mean-based baseline is skewed by the very outlier
 *     it's supposed to detect). Unlike price labels, time labels don't get
 *     an X-position clustering pass — spreading across X is expected and
 *     correct for a time axis, not a sign of illegitimacy the way it is for
 *     a price axis's vertically-stacked labels.
 *  2. **Median, not mean, for candle spacing.** A single momentarily-missed
 *     candle creates one double-width gap in the spacing sequence; a mean
 *     lets that one gap drag the whole estimate up, a median doesn't.
 */
class TimeframeDetector(
    private val outlierResidualMultiplier: Double = 3.0,
    private val maxOutliersToDrop: Int = 2
) {

    fun detect(timeLabels: List<OcrTextBlock>, candles: List<Candle>): TimeframeResult {
        val points = timeLabels.mapNotNull { block ->
            TimeTextParser.parseMinutesSinceMidnight(block.text)?.let { minutes ->
                Point(block.centerX.toDouble(), minutes.toDouble())
            }
        }
        if (points.size < 2) return TimeframeResult(null, null, 0f)
        if (points.map { it.x }.distinct().size < 2) return TimeframeResult(null, null, 0f)

        val fit = fitWithOutlierRemoval(points) ?: return TimeframeResult(null, null, 0f)

        val closedCandles = candles.filterNot { it.isForming }
        if (closedCandles.size < 2) return TimeframeResult(null, null, 0f)

        val spacings = closedCandles.zipWithNext { a, b -> (b.xStart - a.xStart).toDouble() }.filter { it > 0 }
        if (spacings.isEmpty()) return TimeframeResult(null, null, 0f)
        val medianSpacingPx = median(spacings)

        val estimatedMinutes = abs(fit.slope) * medianSpacingPx
        val matched = Timeframe.nearestOrNull(estimatedMinutes)
        val confidence = if (matched != null) 0.8f else 0.3f

        return TimeframeResult(matched, estimatedMinutes, confidence)
    }

    private data class Point(val x: Double, val y: Double)
    private data class LineFit(val slope: Double, val intercept: Double, val rSquared: Double)

    private fun fitWithOutlierRemoval(initial: List<Point>): LineFit? {
        var working = initial
        var current = leastSquares(working) ?: return null

        var dropped = 0
        while (dropped < maxOutliersToDrop && working.size > 2) {
            val residuals = working.map { abs(it.y - (current.slope * it.x + current.intercept)) }
            val medianResidual = median(residuals)
            if (medianResidual < NEGLIGIBLE_RESIDUAL) break

            val worstIndex = residuals.indices.maxByOrNull { residuals[it] } ?: break
            if (residuals[worstIndex] <= outlierResidualMultiplier * medianResidual) break

            val reduced = working.toMutableList().also { it.removeAt(worstIndex) }
            val reducedFit = leastSquares(reduced) ?: break
            if (reducedFit.rSquared <= current.rSquared + 0.02) break

            working = reduced
            current = reducedFit
            dropped++
        }

        return current
    }

    private fun leastSquares(points: List<Point>): LineFit? {
        if (points.size < 2) return null
        val distinctX = points.map { it.x }.distinct().size
        if (distinctX < 2) return null

        val n = points.size
        val meanX = points.sumOf { it.x } / n
        val meanY = points.sumOf { it.y } / n
        val ssXX = points.sumOf { (it.x - meanX) * (it.x - meanX) }
        val ssXY = points.sumOf { (it.x - meanX) * (it.y - meanY) }
        if (ssXX == 0.0) return null

        val slope = ssXY / ssXX
        val intercept = meanY - slope * meanX

        val ssTot = points.sumOf { (it.y - meanY) * (it.y - meanY) }
        val ssRes = points.sumOf { p ->
            val predicted = slope * p.x + intercept
            (p.y - predicted) * (p.y - predicted)
        }
        val rSquared = if (ssTot == 0.0) 1.0 else 1.0 - (ssRes / ssTot)

        return LineFit(slope, intercept, rSquared)
    }

    private fun median(values: List<Double>): Double {
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
    }

    private companion object {
        const val NEGLIGIBLE_RESIDUAL = 1e-6
    }
}
