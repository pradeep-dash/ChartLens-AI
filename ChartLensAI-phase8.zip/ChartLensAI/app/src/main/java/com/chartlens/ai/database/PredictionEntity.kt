package com.chartlens.ai.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.chartlens.ai.prediction.PredictionOutcome

/**
 * One journaled prediction. Per the spec's "do not modify historical
 * predictions after evaluation except to record their actual outcome" —
 * every field here except [outcome]/[evaluationTimestampMillis]/
 * [evaluationPrice] is set once at insert time and never touched again;
 * [PredictionDao.recordOutcome] only ever updates those three columns.
 *
 * [candleIndexAtPrediction] and [horizonCandles] together define exactly
 * which future candle this prediction should be evaluated against — index-
 * based, not wall-clock based, since real candle timestamps don't reliably
 * exist yet (see [com.chartlens.ai.analysis.PriceCandle.timestampMillis]).
 */
@Entity(tableName = "predictions")
data class PredictionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val instrument: String,
    val timeframe: String,
    val direction: String, // PredictionDirection.name — only UP/DOWN are ever journaled
    val modelConfidence: Int,
    val setup: String?,
    val entryPrice: Double,
    val candleIndexAtPrediction: Int,
    val horizonCandles: Int,
    /** JSON snapshot of the structured market state at prediction time, per spec §16. */
    val marketStateJson: String,
    val outcome: String = PredictionOutcome.UNRESOLVED.name,
    val evaluationTimestampMillis: Long? = null,
    val evaluationPrice: Double? = null
)
