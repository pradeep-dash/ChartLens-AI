package com.chartlens.ai.settings

import android.content.Context
import androidx.core.content.edit
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Stores the user-configured AI backend URL and auth token — never an LLM
 * provider API key, which lives only on the backend server (see /backend),
 * per the spec's "never put AI API keys directly in the Android application"
 * requirement. There is no default backend baked into this app; the user
 * must deploy their own and enter its URL here.
 *
 * The auth token is a shared secret between this app and the user's own
 * deployed backend — used so the backend can reject requests that aren't
 * from the user's own app instance. A real, simple safeguard appropriate for
 * a personal/single-user deployment, not a substitute for a production auth
 * system if this were ever opened up to multiple users.
 */
@Singleton
class AiBackendSettingsStore @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveBaseUrl(url: String) {
        prefs.edit { putString(KEY_BASE_URL, url) }
    }

    fun loadBaseUrl(): String? = prefs.getString(KEY_BASE_URL, null)

    fun saveAuthToken(token: String) {
        prefs.edit { putString(KEY_AUTH_TOKEN, token) }
    }

    fun loadAuthToken(): String? = prefs.getString(KEY_AUTH_TOKEN, null)

    private companion object {
        const val PREFS_NAME = "chartlens_ai_backend"
        const val KEY_BASE_URL = "base_url"
        const val KEY_AUTH_TOKEN = "auth_token"
    }
}
