package com.chartlens.ai.ocr

/**
 * Extracts a price value from raw OCR text like "61.400", "0.19773", or noisy
 * variants OCR sometimes produces. Returns null rather than guessing when the
 * text doesn't contain a recognizable number — per the "if OCR confidence is
 * poor, explicitly mark price values as approximate rather than inventing
 * them" requirement, a failed parse must never become a fabricated 0.0 or
 * similar placeholder.
 *
 * Only accepts a plain `digits.digits` pattern (period as decimal separator,
 * no comma/thousands-grouping support at all) — and rejects the whole string
 * outright if it contains a thousands-grouping signature ANYWHERE, rather
 * than just declining to match on the grouped portion. This matters: a naive
 * `digits.digits` regex still finds "500.00" as a valid sub-match inside
 * "974,500.00", since the comma simply isn't part of that match — extracting
 * it would silently turn an account balance into a plausible-looking but
 * completely wrong "price."
 *
 * This is a deliberate simplification made after real device testing, not an
 * oversight: across every real price label seen in testing so far (61.400,
 * 0.19773, 92.700, 194.200, 1.65300, ...), every single one used a plain
 * period with no thousands grouping — and every comma-containing candidate
 * encountered was a false positive (an account balance like "₹974,500.00", a
 * payout amount like "19,500"). An earlier version tried to support
 * comma-thousands prices as a hypothetical, with a decimal-required carve-out
 * that only applied to plain-period text — that gap let "19,500" (comma-
 * grouped, no decimal) through as a "valid" price on a real device test,
 * producing a badly wrong mapping (EMA values over 2000 on a chart where the
 * real price was ~1.65). Rather than keep patching exemptions, comma support
 * was removed outright: the empirical evidence across every real screenshot
 * so far says a comma next to digits on these platforms means "UI monetary
 * figure," never "price." Worth revisiting if a future platform genuinely
 * needs comma-grouped prices, but not something to keep speculative
 * complexity around when it's caused two real bugs.
 */
object PriceTextParser {

    private val thousandsGroupingSignature = Regex("""\d{1,3}(,\d{3})+""")
    private val pricePattern = Regex("""-?\d+\.\d+""")

    fun parse(rawText: String): Double? {
        val cleaned = rawText.trim()
        if (thousandsGroupingSignature.containsMatchIn(cleaned)) return null
        val match = pricePattern.find(cleaned) ?: return null
        return match.value.toDoubleOrNull()
    }
}
