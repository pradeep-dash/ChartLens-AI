package com.chartlens.ai.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PredictionDao {

    @Insert
    suspend fun insert(prediction: PredictionEntity): Long

    /** Deliberately updates ONLY the three outcome-related columns — see [PredictionEntity]'s
     * doc comment. There is no update method that touches any other field. */
    @Query(
        "UPDATE predictions SET outcome = :outcome, " +
            "evaluationTimestampMillis = :evaluationTimestampMillis, " +
            "evaluationPrice = :evaluationPrice WHERE id = :id"
    )
    suspend fun recordOutcome(
        id: Long,
        outcome: String,
        evaluationTimestampMillis: Long,
        evaluationPrice: Double?
    )

    @Query("SELECT * FROM predictions WHERE outcome = :outcome")
    suspend fun getByOutcome(outcome: String): List<PredictionEntity>

    @Query("SELECT * FROM predictions ORDER BY timestampMillis DESC")
    fun observeAll(): Flow<List<PredictionEntity>>

    @Query("SELECT * FROM predictions ORDER BY timestampMillis DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<PredictionEntity>

    @Query("SELECT * FROM predictions")
    suspend fun getAll(): List<PredictionEntity>
}
