package com.chartlens.ai.ai

import kotlinx.serialization.Serializable

/**
 * The AI backend's structured response. Raw/untrusted until it passes
 * [AiResponseValidator] — the network layer never hands this directly to the
 * UI. Every field mirrors the spec's example response schema.
 */
@Serializable
data class AiAnalysisResponse(
    val bias: String,
    val confidence: Int,
    val setup: String? = null,
    val keyLevel: Double? = null,
    val invalidationLevel: Double? = null,
    val reasoning: List<String> = emptyList(),
    val dataQuality: String
)
