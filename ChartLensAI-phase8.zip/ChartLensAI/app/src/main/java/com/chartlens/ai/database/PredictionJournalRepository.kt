package com.chartlens.ai.database

import com.chartlens.ai.prediction.PredictionOutcome
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PredictionJournalRepository @Inject constructor(
    private val dao: PredictionDao
) {
    suspend fun record(entity: PredictionEntity): Long = dao.insert(entity)

    suspend fun getUnresolved(): List<PredictionEntity> = dao.getByOutcome(PredictionOutcome.UNRESOLVED.name)

    suspend fun recordOutcome(id: Long, outcome: PredictionOutcome, evaluationTimestampMillis: Long, evaluationPrice: Double?) {
        dao.recordOutcome(id, outcome.name, evaluationTimestampMillis, evaluationPrice)
    }

    fun observeAll(): Flow<List<PredictionEntity>> = dao.observeAll()

    suspend fun getRecent(limit: Int): List<PredictionEntity> = dao.getRecent(limit)

    suspend fun getAll(): List<PredictionEntity> = dao.getAll()
}
