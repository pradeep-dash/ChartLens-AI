package com.chartlens.ai.candle

import com.chartlens.ai.common.PixelBuffer
import com.chartlens.ai.cv.CandleColorProfile
import com.chartlens.ai.cv.PixelClassification
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Detects individual candles within a [PixelBuffer] that has already been cropped
 * to the chart region (see [com.chartlens.ai.cv.ChartDetector]).
 *
 * Algorithm, in two passes:
 *  1. Cluster columns into "bars" — contiguous runs of same-colored columns. A
 *     color change always starts a new bar immediately, even when candles are
 *     touching with no gap (common on real charts); only *background* gaps get
 *     tolerance (see [maxColumnGapPx]) since background gaps and color changes
 *     are different signals — a run of background columns might just be
 *     anti-aliasing/grid-line noise between two columns of the *same* candle.
 *  2. Within each bar, separate body rows from wick rows using row coverage: a
 *     wick is a thin (typically 1-3px) vertical line, so most rows it touches have
 *     candle color in only a few of the bar's columns. A body is wide, so its rows
 *     have candle color across most of the bar's width. The row-coverage-fraction
 *     threshold ([bodyRowCoverageFraction]) is what separates the two — this is
 *     real geometric reasoning, not a name/shape lookup, so it works regardless of
 *     candle width, color, or exact rendering style.
 *
 * Never uses information from columns to the right of a candle to decide that
 * candle's own geometry — each bar's body/wick split only looks at pixels within
 * its own column range, so nothing here depends on "future" candles.
 */
class CandleDetector(
    private val colorProfile: CandleColorProfile = CandleColorProfile(),
    private val maxColumnGapPx: Int = 2,
    private val minBarWidthPx: Int = 2,
    private val bodyRowCoverageFraction: Float = 0.55f
) {

    fun detect(chartRegion: PixelBuffer): List<Candle> {
        if (chartRegion.width < minBarWidthPx || chartRegion.height < 2) return emptyList()

        val columnClass = Array(chartRegion.width) { x -> classifyColumn(chartRegion, x) }
        val rawBars = clusterIntoBars(columnClass)
            .filter { (start, end, _) -> end - start + 1 >= minBarWidthPx }
        val bars = splitMergedRuns(rawBars)

        // bars.lastIndex is taken AFTER filtering/splitting, so "isForming" correctly
        // marks the last surviving bar rather than the last bar before short ones were
        // dropped or a merged run was split apart.
        return bars.mapIndexedNotNull { index, (start, end, direction) ->
            buildCandle(chartRegion, index, start, end, direction, isLast = index == bars.lastIndex)
        }
    }

    /** @return the dominant candle-color class for a column, or null if the column has none. */
    private fun classifyColumn(buffer: PixelBuffer, x: Int): PixelClassification? {
        var bullish = 0
        var bearish = 0
        for (y in 0 until buffer.height) {
            when (colorProfile.classify(buffer.get(x, y))) {
                PixelClassification.BULLISH -> bullish++
                PixelClassification.BEARISH -> bearish++
                PixelClassification.OTHER -> Unit
            }
        }
        return when {
            bullish == 0 && bearish == 0 -> null
            bullish >= bearish -> PixelClassification.BULLISH
            else -> PixelClassification.BEARISH
        }
    }

    private data class BarSpan(val start: Int, val end: Int, val direction: PixelClassification)

    private fun clusterIntoBars(columnClass: Array<PixelClassification?>): List<BarSpan> {
        val bars = mutableListOf<BarSpan>()
        var barStart = -1
        var barDirection: PixelClassification? = null
        var lastColoredColumn = -1

        fun closeBar(endColumn: Int) {
            if (barStart != -1 && barDirection != null) {
                bars += BarSpan(barStart, endColumn, barDirection!!)
            }
            barStart = -1
            barDirection = null
        }

        for (x in columnClass.indices) {
            val cls = columnClass[x]
            if (cls == null) {
                if (barStart != -1 && x - lastColoredColumn > maxColumnGapPx) {
                    closeBar(lastColoredColumn)
                }
                continue
            }

            if (barStart == -1) {
                barStart = x
                barDirection = cls
            } else if (cls != barDirection) {
                // A color change always starts a new candle, regardless of how close it
                // is to the previous one. Real charts routinely render adjacent candles
                // touching or nearly touching with no background gap between them — gap
                // distance alone cannot be used to decide "this is still the same candle."
                // (A single stray anti-aliased column of the "wrong" color self-corrects:
                // it either matches whichever neighboring color has more pixels in that
                // column via classifyColumn's majority vote, or forms its own sub-minimum-
                // width bar that gets filtered out by minBarWidthPx.)
                closeBar(lastColoredColumn)
                barStart = x
                barDirection = cls
            }
            lastColoredColumn = x
        }
        closeBar(lastColoredColumn)

        return bars
    }

    /**
     * Splits a bar that's a confident whole-number multiple of the typical single-candle
     * width into that many equal sub-bars, all keeping the same detected color.
     *
     * The fix for a real device bug: [clusterIntoBars] only starts a new bar on a color
     * CHANGE or a background gap — it has no way to split a run of several consecutive
     * SAME-colored candles with little/no gap between them, which is routine during any
     * sustained directional move (a real device test showed roughly 4x undercounting on
     * a chart with an extended same-direction decline, consistent with runs of ~4
     * same-colored candles merging into one detected bar each).
     *
     * The "typical width" is the MEDIAN width across all bars — genuinely single candles
     * (correctly split by color changes) are the majority on most charts with reasonably
     * frequent color alternation, so the median stays a robust estimate even with some
     * merged-run outliers pulling individual bars wider. A bar only splits when it's
     * confidently a clean multiple of that width (checked with tolerance, not exact-
     * integer division, since real rendered candle width varies by a pixel or two) —
     * a genuinely wide bar with no clean multiple relationship is left alone rather than
     * guessed at, since a real single wide candle (or an unusual chart style) is possible
     * and splitting it would fabricate candles that were never actually there.
     */
    private fun splitMergedRuns(bars: List<BarSpan>): List<BarSpan> {
        if (bars.size < 3) return bars // not enough bars to estimate a reliable typical width

        val widths = bars.map { it.end - it.start + 1 }.sorted()
        val medianWidth = widths[widths.size / 2]
        if (medianWidth < 1) return bars

        return bars.flatMap { bar ->
            val width = bar.end - bar.start + 1
            val candidateCount = (width.toDouble() / medianWidth).roundToInt()
            val isCleanMultiple = candidateCount >= 2 &&
                abs(width - candidateCount * medianWidth) <= (medianWidth * 0.35).coerceAtLeast(1.0)

            if (!isCleanMultiple) {
                listOf(bar)
            } else {
                val subWidth = width / candidateCount
                (0 until candidateCount).map { i ->
                    val subStart = bar.start + i * subWidth
                    // The last sub-bar absorbs any remainder from integer division, rather
                    // than leaving a gap or dropping trailing pixels.
                    val subEnd = if (i == candidateCount - 1) bar.end else subStart + subWidth - 1
                    BarSpan(subStart, subEnd, bar.direction)
                }
            }
        }
    }

    private fun buildCandle(
        buffer: PixelBuffer,
        index: Int,
        xStart: Int,
        xEndInclusive: Int,
        direction: PixelClassification,
        isLast: Boolean
    ): Candle? {
        val xEnd = xEndInclusive + 1
        val barWidth = xEnd - xStart

        var wickTop = Int.MAX_VALUE
        var wickBottom = Int.MIN_VALUE
        val rowCoverage = IntArray(buffer.height)

        for (x in xStart until xEnd) {
            for (y in 0 until buffer.height) {
                val matches = colorProfile.classify(buffer.get(x, y)) == direction
                if (matches) {
                    rowCoverage[y]++
                    wickTop = min(wickTop, y)
                    wickBottom = max(wickBottom, y)
                }
            }
        }
        if (wickBottom < wickTop) return null // no matching pixels at all — defensive, shouldn't happen

        val coverageThreshold = barWidth * bodyRowCoverageFraction
        var bodyTop = -1
        var bodyBottom = -1
        for (y in wickTop..wickBottom) {
            if (rowCoverage[y] >= coverageThreshold) {
                if (bodyTop == -1) bodyTop = y
                bodyBottom = y
            }
        }
        // No row met the body-coverage threshold (e.g. an all-wick sliver, or a doji
        // rendered as a near-flat line) — treat the whole span as a minimal body at
        // its midpoint rather than fabricating a body that isn't visually there.
        if (bodyTop == -1) {
            val mid = (wickTop + wickBottom) / 2
            bodyTop = mid
            bodyBottom = mid
        }

        val totalPixelsInBar = barWidth * (wickBottom - wickTop + 1)
        val coloredPixels = rowCoverage.sliceArray(wickTop..wickBottom).sum()
        val purity = if (totalPixelsInBar > 0) coloredPixels.toFloat() / totalPixelsInBar else 0f
        val widthConfidence = (barWidth.toFloat() / MIN_CONFIDENT_WIDTH_PX).coerceAtMost(1f)
        val confidence = (0.7f * purity + 0.3f * widthConfidence).coerceIn(0f, 1f)

        return Candle(
            index = index,
            xStart = xStart,
            xEnd = xEnd,
            bodyTopY = bodyTop,
            bodyBottomY = bodyBottom,
            wickTopY = wickTop,
            wickBottomY = wickBottom,
            direction = if (direction == PixelClassification.BULLISH) CandleDirection.BULLISH else CandleDirection.BEARISH,
            isForming = isLast,
            confidence = confidence
        )
    }

    private companion object {
        const val MIN_CONFIDENT_WIDTH_PX = 6f
    }
}
