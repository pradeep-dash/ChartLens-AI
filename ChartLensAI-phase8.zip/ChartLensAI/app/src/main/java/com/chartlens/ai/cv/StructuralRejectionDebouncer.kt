package com.chartlens.ai.cv

/**
 * Decides whether a structural-validation rejection should actually be
 * surfaced to the user, or coasted through silently.
 *
 * Built after a real device report: `ChartStructureValidator` rejecting a
 * single transient bad frame (a capture mid-zoom-transition, a momentary
 * render glitch) immediately flipped the whole UI to "no chart detected,"
 * with zero tolerance and no memory of the previous good state — described
 * as happening "frequently" and behaving "abruptly" whenever the user
 * zoomed. That instability had nothing to do with `CandleDetector`'s
 * segmentation algorithm; it was that one bad frame was being treated with
 * the same alarm as a genuinely sustained "you're not looking at a chart
 * anymore" situation. Requiring several consecutive rejections before
 * surfacing anything absorbs the transient case while still catching a real,
 * sustained one within a few frames.
 */
class StructuralRejectionDebouncer(
    private val consecutiveRejectionsBeforeSurfacing: Int = 3
) {
    private var consecutiveRejections = 0

    /**
     * Call once per analyzed frame with whether structural validation passed.
     * @return true if the rejection should be surfaced now (a sustained failure);
     *   false if it should be coasted through on the last known-good result instead.
     */
    fun onFrameResult(isValidChart: Boolean): Boolean {
        if (isValidChart) {
            consecutiveRejections = 0
            return false
        }
        consecutiveRejections++
        return consecutiveRejections >= consecutiveRejectionsBeforeSurfacing
    }

    fun reset() {
        consecutiveRejections = 0
    }
}
