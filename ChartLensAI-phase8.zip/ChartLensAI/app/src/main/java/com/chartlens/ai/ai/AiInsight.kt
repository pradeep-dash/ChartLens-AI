package com.chartlens.ai.ai

/**
 * What the UI shows for the AI reasoning layer. Deliberately distinct states
 * rather than a nullable response — [Error] carries a real, specific reason
 * (no backend configured, network failure, invalid response rejected by
 * [AiResponseValidator]) rather than looking identical to [Idle].
 */
sealed interface AiInsight {
    data object Idle : AiInsight
    data object Loading : AiInsight
    data class Success(val response: AiAnalysisResponse, val receivedAtMillis: Long) : AiInsight
    data class Error(val message: String) : AiInsight
}
