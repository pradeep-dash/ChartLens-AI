package com.chartlens.ai.common

/**
 * Represents the real, observable state of the screen-capture pipeline.
 *
 * IMPORTANT: This intentionally does NOT include chart/candle/prediction fields.
 * Those belong to later phases (CV, analysis, prediction) and must not be
 * fabricated here. A [CaptureState.Capturing] value means "frames are being
 * read from the screen" — nothing more. Do not infer analysis readiness from it.
 */
sealed interface CaptureState {

    /** No capture session exists. Initial state and state after a clean stop. */
    data object Idle : CaptureState

    /** Waiting on the user to grant notification / overlay / MediaProjection permissions. */
    data object AwaitingPermission : CaptureState

    /** MediaProjection is active and frames are being read from the screen. */
    data class Capturing(
        val frameWidth: Int,
        val frameHeight: Int,
        val capturedFrameCount: Long,
        val analyzedFrameCount: Long,
        val lastFrameAtMillis: Long,
        val startedAtMillis: Long
    ) : CaptureState

    /** The user or the system stopped capture entirely (e.g. "Stop casting" from system
     * UI, or an explicit full stop) — MediaProjection has been released; starting again
     * requires fresh consent. */
    data object Stopped : CaptureState

    /**
     * Analysis is paused but the underlying MediaProjection session is deliberately kept
     * alive — no new consent dialog is needed to resume. Exists specifically so the
     * overlay's Start button can resume instantly rather than re-triggering Android's
     * screen-capture permission flow every time. The tradeoff, and it's a real one: the
     * system's screen-recording indicator/notification stays visible the whole time a
     * session is Paused, even though nothing is actually being captured or analyzed —
     * Android requires this for any technically-live MediaProjection grant, and there is
     * no way to suppress it. A true full stop (releasing the grant, clearing the
     * indicator) requires the overlay's explicit Dismiss action or the Dashboard's Stop.
     */
    data class Paused(val pausedAtMillis: Long) : CaptureState

    /** Something in the capture pipeline failed. [recoverable] hints whether retrying start() is reasonable. */
    data class Error(val message: String, val recoverable: Boolean) : CaptureState
}
