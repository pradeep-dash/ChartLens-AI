package com.chartlens.ai.analysis

import kotlin.math.abs

/**
 * Finds which of the currently-visible closed candles haven't been recorded
 * yet, given only the last recorded candle's closing price. Built for a real
 * workflow gap: when a chart doesn't auto-follow live price and has to be
 * manually scrolled to catch up, several real candles can close entirely
 * off-screen in between — a single frame-to-frame close-event comparison
 * (the original design) would only ever catch the single most recent one
 * once the view catches up, silently losing the rest. This compares the
 * whole currently-visible window against what's already recorded and
 * returns everything genuinely new, so [com.chartlens.ai.replay.CandleHistoryRecorder]
 * can backfill all of them at once instead of just the latest.
 *
 * Same disclosed limitation as [CandleHistoryMerger]: matches by closing
 * price, not a stable identity, since neither the recorded history's nor
 * the current frame's candle index is a reliable cross-frame identifier —
 * both are positional, assigned fresh from whatever's currently visible.
 * If the last recorded candle's price genuinely doesn't appear anywhere in
 * the current view (it scrolled off entirely, or price mapping shifted),
 * this falls back to treating the whole visible window as new — an
 * accepted risk of occasionally re-recording an already-seen candle,
 * preferred over silently recording nothing at all for that frame.
 */
object NewCandleFinder {

    private const val PRICE_EPSILON = 1e-6

    fun findNewSuffix(lastRecordedClose: Double?, currentlyVisible: List<PriceCandle>): List<PriceCandle> {
        if (currentlyVisible.isEmpty()) return emptyList()
        if (lastRecordedClose == null) return currentlyVisible

        val matchIndex = currentlyVisible.indexOfLast { abs(it.close - lastRecordedClose) < PRICE_EPSILON }
        val startIndex = if (matchIndex >= 0) matchIndex + 1 else 0
        return if (startIndex >= currentlyVisible.size) {
            emptyList()
        } else {
            currentlyVisible.subList(startIndex, currentlyVisible.size)
        }
    }
}
