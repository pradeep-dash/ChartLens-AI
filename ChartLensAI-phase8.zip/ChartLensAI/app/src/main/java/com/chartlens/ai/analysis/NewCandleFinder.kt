package com.chartlens.ai.analysis

import kotlin.math.abs

/**
 * Finds which of the currently-visible closed candles haven't been recorded
 * yet, given only the last recorded candle's closing price. Built for a real
 * workflow gap: when a chart doesn't auto-follow live price and has to be
 * manually scrolled to catch up, several real candles can close entirely
 * off-screen in between — a single frame-to-frame close-event comparison
 * (the original design) would only ever catch the single most recent one
 * once the view catches up, silently losing the rest. This compares the
 * whole currently-visible window against what's already recorded and
 * returns everything genuinely new, so [com.chartlens.ai.replay.CandleHistoryRecorder]
 * can backfill all of them at once instead of just the latest.
 *
 * Same disclosed limitation as [CandleHistoryMerger]: matches by closing
 * price, not a stable identity, since neither the recorded history's nor
 * the current frame's candle index is a reliable cross-frame identifier —
 * both are positional, assigned fresh from whatever's currently visible.
 * If the last recorded candle's price genuinely doesn't appear anywhere in
 * the current view (it scrolled off entirely, or price mapping shifted),
 * this falls back to treating the (capped — see [maxResults]) visible
 * window as new — an accepted risk of occasionally re-recording an
 * already-seen candle, preferred over silently recording nothing at all
 * for that frame.
 *
 * **[maxResults] exists because that fallback caused a real, serious bug**: a
 * real device session recorded 5478 rows for roughly 20-25 minutes of real
 * candles (which should be on the order of 20-25 rows). The cause was
 * candle-detection jitter (a separate, still-open investigation) making a
 * real candle's computed closing price shift by enough, frame to frame, to
 * keep missing the match — triggering the "whole window is new" fallback on
 * a large fraction of frames, each one re-recording dozens of already-seen
 * candles as if they were new. A genuine scroll-catch-up gap is a handful of
 * candles; capping the fallback to [maxResults] keeps that legitimate case
 * working while making it structurally impossible for one bad match to
 * flood storage with duplicates the way it did here. When the cap trims the
 * result, the MOST RECENT candles are kept (the tail of the window) rather
 * than the oldest, since those are the ones most likely to be genuinely
 * current if the chart really did just catch up from a scroll.
 */
object NewCandleFinder {

    private const val PRICE_EPSILON = 1e-6

    /** See the class doc comment's account of the 5478-row corruption this bounds. */
    const val DEFAULT_MAX_BACKFILL = 15

    fun findNewSuffix(
        lastRecordedClose: Double?,
        currentlyVisible: List<PriceCandle>,
        maxResults: Int = DEFAULT_MAX_BACKFILL
    ): List<PriceCandle> {
        if (currentlyVisible.isEmpty()) return emptyList()
        if (lastRecordedClose == null) return currentlyVisible.takeLastCapped(maxResults)

        val matchIndex = currentlyVisible.indexOfLast { abs(it.close - lastRecordedClose) < PRICE_EPSILON }
        val startIndex = if (matchIndex >= 0) matchIndex + 1 else 0
        val result = if (startIndex >= currentlyVisible.size) {
            emptyList()
        } else {
            currentlyVisible.subList(startIndex, currentlyVisible.size)
        }
        return result.takeLastCapped(maxResults)
    }

    private fun List<PriceCandle>.takeLastCapped(maxResults: Int): List<PriceCandle> =
        if (size > maxResults) takeLast(maxResults) else this
}
