package com.chartlens.ai.database

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): ChartLensDatabase =
        Room.databaseBuilder(context, ChartLensDatabase::class.java, "chartlens.db")
            // No migration path from v1 (Phase 7) to v2 (Phase 8's candle_history table) —
            // this project has no released users yet, so destructive fallback is an
            // accepted, disclosed tradeoff, not an oversight. Upgrading from a Phase 7
            // build will silently wipe the existing prediction journal; see README.
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    @Singleton
    fun providePredictionDao(database: ChartLensDatabase): PredictionDao = database.predictionDao()

    @Provides
    @Singleton
    fun provideCandleHistoryDao(database: ChartLensDatabase): CandleHistoryDao = database.candleHistoryDao()
}
