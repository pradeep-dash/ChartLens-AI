package com.chartlens.ai.ai

import kotlin.math.abs

/**
 * Validates an AI backend response before it's ever shown to the user — the
 * network layer never hands a raw response straight to the UI. Rejects
 * (returns null for) anything that doesn't fit the expected shape, is out of
 * range, or invents a price level nowhere close to what the request actually
 * supplied. The local pipeline's own support/resistance data is the ground
 * truth here, not anything the AI claims — this is the direct enforcement of
 * the spec's "never invent price levels" rule at the client boundary, on top
 * of whatever validation the backend itself does.
 */
object AiResponseValidator {

    private val validBiases = setOf("BULLISH", "BEARISH", "NO_CLEAR_SETUP")
    private val validDataQuality = setOf("GOOD", "FAIR", "POOR", "INVALID")
    private const val MAX_REASONING_ITEMS = 6
    private const val MAX_REASONING_LENGTH = 300
    private const val LEVEL_TOLERANCE_FRACTION = 0.05

    fun validate(response: AiAnalysisResponse, request: AiAnalysisRequest): AiAnalysisResponse? {
        if (response.bias !in validBiases) return null
        if (response.confidence !in 0..100) return null
        if (response.dataQuality !in validDataQuality) return null
        if (response.reasoning.isEmpty() || response.reasoning.size > MAX_REASONING_ITEMS) return null
        if (response.reasoning.any { it.isBlank() || it.length > MAX_REASONING_LENGTH }) return null

        // A "no setup" call that also claims strong confidence is internally
        // inconsistent — confidence in nothing shouldn't be high.
        if (response.bias == "NO_CLEAR_SETUP" && response.confidence > 50) return null

        val knownLevels = request.support + request.resistance
        if (!isPlausibleLevel(response.keyLevel, knownLevels)) return null
        if (!isPlausibleLevel(response.invalidationLevel, knownLevels)) return null

        return response
    }

    /**
     * Null is always plausible (the AI simply didn't provide a level). A non-null
     * value must be within [LEVEL_TOLERANCE_FRACTION] of a level the request
     * actually supplied. This is deliberately strict — it will reject a
     * legitimate "round number" psychological level the AI reasonably
     * introduces on its own (the spec allows those as an S/R type, but this
     * project's local pipeline doesn't compute them), which is an accepted
     * trade-off: erring toward rejecting a possibly-legitimate response is
     * safer than accepting a possibly-fabricated one.
     */
    private fun isPlausibleLevel(level: Double?, knownLevels: List<Double>): Boolean {
        if (level == null) return true
        if (knownLevels.isEmpty()) return false
        val closest = knownLevels.minByOrNull { abs(it - level) } ?: return false
        if (closest == 0.0) return level == 0.0
        val relativeDeviation = abs(level - closest) / abs(closest)
        return relativeDeviation <= LEVEL_TOLERANCE_FRACTION
    }
}
