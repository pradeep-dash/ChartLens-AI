package com.chartlens.ai.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [PredictionEntity::class, CandleHistoryEntity::class],
    version = 2,
    exportSchema = false
)
abstract class ChartLensDatabase : RoomDatabase() {
    abstract fun predictionDao(): PredictionDao
    abstract fun candleHistoryDao(): CandleHistoryDao
}
