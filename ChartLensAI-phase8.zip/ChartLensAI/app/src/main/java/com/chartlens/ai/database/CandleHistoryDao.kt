package com.chartlens.ai.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CandleHistoryDao {

    @Insert
    suspend fun insert(candle: CandleHistoryEntity): Long

    @Query("SELECT DISTINCT sessionId FROM candle_history ORDER BY sessionId DESC")
    suspend fun getSessionIds(): List<Long>

    @Query("SELECT * FROM candle_history WHERE sessionId = :sessionId ORDER BY timestampMillis ASC")
    suspend fun getSession(sessionId: Long): List<CandleHistoryEntity>

    @Query("SELECT COUNT(*) FROM candle_history WHERE sessionId = :sessionId")
    suspend fun countForSession(sessionId: Long): Int
}
