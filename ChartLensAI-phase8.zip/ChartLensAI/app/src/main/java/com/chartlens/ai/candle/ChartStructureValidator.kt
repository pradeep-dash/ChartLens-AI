package com.chartlens.ai.candle

import kotlin.math.abs

/**
 * Why this exists, plainly: a real device test found the app reporting
 * "60/61 candles · region 80% · quality GOOD" while displaying a **text
 * conversation** — no chart on screen at all. [com.chartlens.ai.cv.ChartDetector]
 * scores candle-color density, and [CandleDetector] segments colored runs, but
 * NOTHING anywhere in the pipeline verified that what was found actually looks
 * like a candlestick chart. Red and green syntax-highlighted text, colored
 * icons, and UI buttons were being counted as candles, and could in principle
 * have produced a fully fabricated BULLISH/BEARISH prediction from pure noise.
 *
 * That is the most dangerous class of bug in this entire project — far worse
 * than an inaccurate count on a real chart, because the output is not merely
 * imprecise, it is meaningless while still looking confident.
 *
 * This validator checks properties that are true of real candlestick charts and
 * false of arbitrary colored pixels:
 *
 *  1. **Enough candles.** A handful of colored blobs is not a chart.
 *  2. **Consistent pitch.** Real candles sit at a regular horizontal interval.
 *     Text and icons are spaced irregularly. Measured as the fraction of
 *     gaps close to the median gap.
 *  3. **Consistent width.** Real candles are near-identical in width. Text
 *     glyphs and UI elements vary wildly.
 *  4. **Vertical overlap.** Real candles occupy a shared price band, so
 *     neighbours overlap vertically. Scattered text does not.
 *
 * Deliberately fails SAFE: when it rejects, the caller reports no chart and
 * makes no prediction. A missed opportunity costs nothing; a fabricated signal
 * from screen noise could cost real money. It also cannot introduce a false
 * signal — it can only ever remove one.
 */
class ChartStructureValidator(
    private val minCandles: Int = 8,
    private val minPitchConsistency: Float = 0.6f,
    private val minWidthConsistency: Float = 0.6f,
    private val minVerticalOverlapFraction: Float = 0.5f,
    private val pitchToleranceFraction: Double = 0.35,
    private val widthToleranceFraction: Double = 0.4
) {

    data class Result(val isValidChart: Boolean, val reason: String?) {
        companion object {
            val VALID = Result(true, null)
            fun rejected(reason: String) = Result(false, reason)
        }
    }

    fun validate(candles: List<Candle>): Result {
        if (candles.size < minCandles) {
            return Result.rejected("only ${candles.size} candle-like shapes (need $minCandles+)")
        }

        val sorted = candles.sortedBy { it.xStart }

        val gaps = sorted.zipWithNext { a, b -> (b.xStart - a.xStart).toDouble() }.filter { it > 0 }
        if (gaps.size < 2) return Result.rejected("not enough spacing data")
        val medianGap = median(gaps)
        if (medianGap <= 0) return Result.rejected("degenerate spacing")
        val pitchConsistency = gaps.count {
            abs(it - medianGap) / medianGap <= pitchToleranceFraction
        }.toFloat() / gaps.size
        if (pitchConsistency < minPitchConsistency) {
            return Result.rejected("irregular spacing (${(pitchConsistency * 100).toInt()}% consistent)")
        }

        val widths = sorted.map { (it.xEnd - it.xStart).toDouble() }.filter { it > 0 }
        if (widths.isEmpty()) return Result.rejected("degenerate widths")
        val medianWidth = median(widths)
        if (medianWidth <= 0) return Result.rejected("degenerate widths")
        val widthConsistency = widths.count {
            abs(it - medianWidth) / medianWidth <= widthToleranceFraction
        }.toFloat() / widths.size
        if (widthConsistency < minWidthConsistency) {
            return Result.rejected("inconsistent widths (${(widthConsistency * 100).toInt()}% consistent)")
        }

        // Neighbouring candles should share a vertical price band. Uses the full wick
        // extent, since that's the true vertical footprint of a candle.
        val overlapping = sorted.zipWithNext { a, b ->
            val overlap = minOf(a.wickBottomY, b.wickBottomY) - maxOf(a.wickTopY, b.wickTopY)
            overlap > 0
        }
        val overlapFraction = overlapping.count { it }.toFloat() / overlapping.size
        if (overlapFraction < minVerticalOverlapFraction) {
            return Result.rejected("scattered vertically (${(overlapFraction * 100).toInt()}% overlap)")
        }

        return Result.VALID
    }

    private fun median(values: List<Double>): Double {
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
    }
}
