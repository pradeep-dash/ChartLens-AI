package com.chartlens.ai.analytics

import com.chartlens.ai.database.PredictionEntity
import com.chartlens.ai.prediction.PredictionOutcome

/**
 * Computes [AccuracyStats] from a list of journaled predictions, in any
 * order — sorts chronologically internally before computing streaks, so
 * callers don't need to know or guarantee the DAO's own ordering convention.
 * Pure Kotlin: [PredictionEntity] is a plain data class despite its Room
 * annotations, so this is fully unit-testable without a real database.
 */
object AccuracyAnalytics {

    /** A documented judgment call, not a statistically derived minimum — see
     * [AccuracyStats.hasEnoughDataForEdgeClaim]'s doc comment. */
    const val MIN_EVALUATED_FOR_EDGE_CLAIM = 30

    private val confidenceBuckets = listOf(50..54, 55..59, 60..64, 65..69, 70..74, 75..100)

    fun compute(entries: List<PredictionEntity>): AccuracyStats {
        val chronological = entries.sortedBy { it.timestampMillis }
        val evaluated = chronological.filter { it.outcome != PredictionOutcome.UNRESOLVED.name }

        val wins = evaluated.count { it.outcome == PredictionOutcome.WIN.name }
        val losses = evaluated.count { it.outcome == PredictionOutcome.LOSS.name }
        val neutral = evaluated.count { it.outcome == PredictionOutcome.NEUTRAL.name }
        val invalid = evaluated.count { it.outcome == PredictionOutcome.INVALID_DATA.name }
        val decisive = wins + losses

        return AccuracyStats(
            totalPredictions = chronological.size,
            evaluatedPredictions = evaluated.size,
            wins = wins,
            losses = losses,
            neutral = neutral,
            invalidData = invalid,
            unresolved = chronological.size - evaluated.size,
            overallAccuracyPercent = if (decisive == 0) null else (wins.toFloat() / decisive) * 100f,
            accuracyByInstrument = bucketBy(evaluated) { it.instrument },
            accuracyByTimeframe = bucketBy(evaluated) { it.timeframe },
            accuracyByConfidenceBucket = bucketByConfidence(evaluated),
            accuracyBySetup = bucketBy(evaluated) { it.setup ?: "unknown" },
            currentStreak = computeCurrentStreak(evaluated),
            maxWinningStreak = computeMaxStreak(evaluated, PredictionOutcome.WIN.name),
            maxLosingStreak = computeMaxStreak(evaluated, PredictionOutcome.LOSS.name),
            hasEnoughDataForEdgeClaim = decisive >= MIN_EVALUATED_FOR_EDGE_CLAIM
        )
    }

    private fun bucketBy(entries: List<PredictionEntity>, keySelector: (PredictionEntity) -> String): List<AccuracyBucket> =
        entries.groupBy(keySelector).map { (key, group) ->
            AccuracyBucket(
                label = key,
                total = group.size,
                wins = group.count { it.outcome == PredictionOutcome.WIN.name },
                losses = group.count { it.outcome == PredictionOutcome.LOSS.name }
            )
        }.sortedByDescending { it.total }

    private fun bucketByConfidence(entries: List<PredictionEntity>): List<AccuracyBucket> =
        confidenceBuckets.mapNotNull { range ->
            val group = entries.filter { it.modelConfidence in range }
            if (group.isEmpty()) return@mapNotNull null
            val label = if (range.last >= 75) "75+" else "${range.first}-${range.last}"
            AccuracyBucket(
                label = label,
                total = group.size,
                wins = group.count { it.outcome == PredictionOutcome.WIN.name },
                losses = group.count { it.outcome == PredictionOutcome.LOSS.name }
            )
        }

    private fun decisiveOnly(entries: List<PredictionEntity>): List<PredictionEntity> =
        entries.filter { it.outcome == PredictionOutcome.WIN.name || it.outcome == PredictionOutcome.LOSS.name }

    private fun computeCurrentStreak(chronologicalEvaluated: List<PredictionEntity>): Int {
        val decisive = decisiveOnly(chronologicalEvaluated)
        if (decisive.isEmpty()) return 0
        val lastOutcome = decisive.last().outcome
        var streak = 0
        for (entry in decisive.asReversed()) {
            if (entry.outcome == lastOutcome) streak++ else break
        }
        return if (lastOutcome == PredictionOutcome.WIN.name) streak else -streak
    }

    private fun computeMaxStreak(chronologicalEvaluated: List<PredictionEntity>, outcomeName: String): Int {
        val decisive = decisiveOnly(chronologicalEvaluated)
        var maxStreak = 0
        var current = 0
        for (entry in decisive) {
            if (entry.outcome == outcomeName) {
                current++
                maxStreak = maxOf(maxStreak, current)
            } else {
                current = 0
            }
        }
        return maxStreak
    }
}
