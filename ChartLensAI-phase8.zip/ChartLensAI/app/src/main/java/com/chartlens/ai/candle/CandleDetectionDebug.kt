package com.chartlens.ai.candle

/**
 * Stage-by-stage counts from [CandleDetector.detect], so a wrong final candle
 * count can be traced to the exact stage that dropped or merged candles
 * instead of being guessed at from the final number alone.
 *
 * Added after four unsuccessful attempts to fix a real candle-undercount bug
 * by reasoning from theory — each attempt cost a build/test cycle and none
 * addressed the actual cause. Reading what the detector actually sees is
 * strictly faster than another plausible-sounding guess.
 */
data class CandleDetectionDebug(
    /** Columns whose dominant pixel classification was a candle color (not background). */
    val coloredColumns: Int,
    /** Contiguous same-colored runs found before any filtering. */
    val rawBars: Int,
    /** Bars remaining after dropping those narrower than minBarWidthPx. */
    val barsAfterWidthFilter: Int,
    /** Bars after pitch-based segmentation split any merged runs (see CandlePitchEstimator). */
    val barsAfterSplitting: Int,
    /** Candles actually built — buildCandle can still return null for degenerate geometry. */
    val builtCandles: Int,
    /** Measured candle pitch in px — the fixed start-to-start interval segmentation uses
     * (see [CandlePitchEstimator]). 0 means no confident pitch could be measured, in
     * which case bars were left exactly as clusterIntoBars produced them rather than
     * being split on a guess. */
    val pitchPx: Int,
    /** Median gap (background columns) between consecutive raw bars — distinguishes two
     * very different explanations for a low count that look identical from the final
     * number alone: genuinely wide, uniform spacing between real candles (in which case
     * the count may simply be correct), versus a few much-larger gaps where specific
     * candles are being missed by color classification entirely, invisible before
     * clustering ever runs. */
    val medianGapPx: Int,
    /** Largest single gap found — a big outlier here, next to a small median, points
     * straight at missed candles rather than uniformly wide real spacing. */
    val maxGapPx: Int,
    /** Where the largest gap sits, as a percentage of the region's width from the left
     * edge — the missing piece needed to tell apart two very different causes that look
     * identical in the med/max numbers alone: a gap near 0% or 100% points at the region
     * boundary clipping real candles; a gap in the middle points at something interfering
     * with detection at that specific spot instead (a UI overlay crossing the chart, a
     * price-reference line, etc.). */
    val maxGapPositionPercent: Int,
    /** Width of the cropped chart region the detector was given, for context. */
    val regionWidthPx: Int
) {
    fun summary(): String =
        "cols=$coloredColumns raw=$rawBars width-filtered=$barsAfterWidthFilter " +
            "split=$barsAfterSplitting built=$builtCandles pitch=${pitchPx}px " +
            "gap(med/max)=${medianGapPx}px/${maxGapPx}px@${maxGapPositionPercent}% regionW=${regionWidthPx}px"
}
