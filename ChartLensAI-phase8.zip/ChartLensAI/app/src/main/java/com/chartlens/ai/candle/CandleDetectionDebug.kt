package com.chartlens.ai.candle

/**
 * Stage-by-stage counts from [CandleDetector.detect], so a wrong final candle
 * count can be traced to the exact stage that dropped or merged candles
 * instead of being guessed at from the final number alone.
 *
 * Originally added after several unsuccessful attempts to fix a real
 * candle-undercount bug by reasoning from theory alone, each attempt costing
 * a build/test cycle without addressing the actual cause. Reading what the
 * detector actually sees is strictly faster than another plausible-sounding
 * guess. Later, an attempt at fixing merged-candle runs by splitting them
 * (estimating a "typical width" or "pitch" from the detected bars and
 * dividing wide bars accordingly) was reverted entirely — a deliberate
 * return to this raw baseline for a fresh look at the problem, rather than
 * another patch on top of an approach that kept producing new failure modes.
 * `barsAfterWidthFilter` and `builtCandles` are what's left instead of a
 * splitting stage: bars are used exactly as `clusterIntoBars` finds them.
 */
data class CandleDetectionDebug(
    /** Columns whose dominant pixel classification was a candle color (not background). */
    val coloredColumns: Int,
    /** Contiguous same-colored runs found before any filtering. */
    val rawBars: Int,
    /** Bars remaining after dropping those narrower than minBarWidthPx — this is also
     * the final segmentation, since no splitting stage exists at the moment. */
    val barsAfterWidthFilter: Int,
    /** Candles actually built — buildCandle can still return null for degenerate geometry,
     * so this can differ from barsAfterWidthFilter even with no splitting involved. */
    val builtCandles: Int,
    /** Median gap (background columns) between consecutive raw bars — distinguishes two
     * very different explanations for a low count that look identical from the final
     * number alone: genuinely wide, uniform spacing between real candles (in which case
     * the count may simply be correct), versus a few much-larger gaps where specific
     * candles are being missed by color classification entirely, invisible before
     * clustering ever runs. */
    val medianGapPx: Int,
    /** Largest single gap found — a big outlier here, next to a small median, points
     * straight at missed candles rather than uniformly wide real spacing. */
    val maxGapPx: Int,
    /** Where the largest gap sits, as a percentage of the region's width from the left
     * edge — the missing piece needed to tell apart two very different causes that look
     * identical in the med/max numbers alone: a gap near 0% or 100% points at the region
     * boundary clipping real candles; a gap in the middle points at something interfering
     * with detection at that specific spot instead (a UI overlay crossing the chart, a
     * price-reference line, etc.). */
    val maxGapPositionPercent: Int,
    /** Width of the cropped chart region the detector was given, for context. */
    val regionWidthPx: Int,
    /** True when this frame's raw bars matched the "likely capture glitch" signature —
     * see [CandleDetector.looksLikeCaptureGlitch]'s doc comment. Callers should treat
     * this differently from a genuine structural rejection (not count it toward a
     * rejection streak), since it points at a transient capture problem rather than a
     * sustained "not looking at a chart" situation. */
    val looksLikeCaptureGlitch: Boolean = false
) {
    fun summary(): String {
        val base = "cols=$coloredColumns raw=$rawBars width-filtered=$barsAfterWidthFilter built=$builtCandles " +
            "gap(med/max)=${medianGapPx}px/${maxGapPx}px@${maxGapPositionPercent}% regionW=${regionWidthPx}px"
        return if (looksLikeCaptureGlitch) "$base [likely capture glitch]" else base
    }
}
