package com.chartlens.ai.candle

/**
 * Stage-by-stage counts from [CandleDetector.detect], so a wrong final candle
 * count can be traced to the exact stage that dropped or merged candles
 * instead of being guessed at from the final number alone.
 *
 * Added after four unsuccessful attempts to fix a real candle-undercount bug
 * by reasoning from theory — each attempt cost a build/test cycle and none
 * addressed the actual cause. Reading what the detector actually sees is
 * strictly faster than another plausible-sounding guess.
 */
data class CandleDetectionDebug(
    /** Columns whose dominant pixel classification was a candle color (not background). */
    val coloredColumns: Int,
    /** Contiguous same-colored runs found before any filtering. */
    val rawBars: Int,
    /** Bars remaining after dropping those narrower than minBarWidthPx. */
    val barsAfterWidthFilter: Int,
    /** Bars after splitMergedRuns expanded any that were clean multiples of the median. */
    val barsAfterSplitting: Int,
    /** Candles actually built — buildCandle can still return null for degenerate geometry. */
    val builtCandles: Int,
    /** Typical single-candle bar width in px (pre-split), the basis splitMergedRuns uses —
     * the 25th percentile of bar widths, not the median (see splitMergedRuns' doc). */
    val typicalBarWidthPx: Int,
    /** Width of the cropped chart region the detector was given, for context. */
    val regionWidthPx: Int
) {
    fun summary(): String =
        "cols=$coloredColumns raw=$rawBars width-filtered=$barsAfterWidthFilter " +
            "split=$barsAfterSplitting built=$builtCandles typW=${typicalBarWidthPx}px regionW=${regionWidthPx}px"
}
