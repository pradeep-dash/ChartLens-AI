package com.chartlens.ai.replay

import com.chartlens.ai.analysis.Timeframe
import com.chartlens.ai.analysis.TechnicalAnalysisEngine
import com.chartlens.ai.analytics.AccuracyAnalytics
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.candle.CandlePattern
import com.chartlens.ai.database.CandleHistoryEntity
import com.chartlens.ai.database.PredictionEntity
import com.chartlens.ai.database.toPriceCandle
import com.chartlens.ai.prediction.LastCandleContext
import com.chartlens.ai.prediction.OutcomeEvaluator
import com.chartlens.ai.prediction.PredictionDirection
import com.chartlens.ai.prediction.PredictionEngine

/**
 * Replays a saved candle history one candle at a time, generating a real
 * prediction at each step using ONLY the candles up to and including that
 * step — never anything after it. This is the direct, structural
 * implementation of the spec's "prevent look-ahead bias" requirement, not
 * just a design intention: at step `i`, [technicalAnalysisEngine] only ever
 * receives `chronological.subList(0, i + 1)` — there is no code path in this
 * class that can hand it a later index. `ReplayEngineTest` proves this
 * empirically too: it replays two histories identical up to a point and
 * different after it, and asserts every prediction at or before that point
 * is identical between the two runs.
 *
 * Reuses [TechnicalAnalysisEngine] and [PredictionEngine] directly — the
 * exact same code a live session runs, not a separate reimplementation that
 * could silently drift from real behavior. Reuses [AccuracyAnalytics] for
 * the summary too, by building ordinary [PredictionEntity] rows in memory
 * (see [ReplayResult]'s doc comment for why these never touch the real
 * database).
 */
class ReplayEngine(
    private val technicalAnalysisEngine: TechnicalAnalysisEngine = TechnicalAnalysisEngine(),
    private val predictionEngine: PredictionEngine = PredictionEngine(),
    private val minCandlesForPrediction: Int = 20,
    private val horizonCandles: Int = 1
) {
    fun replay(sessionId: Long, history: List<CandleHistoryEntity>): ReplayResult {
        val chronological = history.sortedBy { it.timestampMillis }
        val steps = mutableListOf<ReplayStep>()
        val entities = mutableListOf<PredictionEntity>()

        for (i in chronological.indices) {
            if (i + 1 < minCandlesForPrediction) continue
            val targetIndex = i + horizonCandles
            if (targetIndex >= chronological.size) break // the future isn't known yet — stop, don't guess

            // The look-ahead-bias boundary: everything below this line sees only indices 0..i.
            val visibleSoFar = chronological.subList(0, i + 1)
            val priceCandles = visibleSoFar.map { it.toPriceCandle() }
            val technicalAnalysis = technicalAnalysisEngine.analyze(priceCandles)
            val current = chronological[i]

            val prediction = predictionEngine.predict(
                technicalAnalysis = technicalAnalysis,
                closedCandleCount = priceCandles.size,
                lastCandle = current.toLastCandleContext(),
                timeframe = current.timeframeLabel?.let { parseTimeframe(it) }
            )

            if (prediction.direction == PredictionDirection.NO_TRADE) continue

            val entryPrice = current.close
            val evaluationPrice = chronological[targetIndex].close
            val outcome = OutcomeEvaluator.evaluate(prediction.direction, entryPrice, evaluationPrice)

            steps += ReplayStep(
                candleIndex = current.candleIndex,
                timestampMillis = current.timestampMillis,
                prediction = prediction,
                outcome = outcome,
                entryPrice = entryPrice,
                evaluationPrice = evaluationPrice
            )
            entities += PredictionEntity(
                timestampMillis = current.timestampMillis,
                instrument = current.instrument,
                timeframe = current.timeframeLabel ?: "Unknown",
                direction = prediction.direction.name,
                modelConfidence = prediction.modelConfidence,
                setup = prediction.setup,
                entryPrice = entryPrice,
                candleIndexAtPrediction = current.candleIndex,
                horizonCandles = horizonCandles,
                marketStateJson = "",
                outcome = outcome.name,
                evaluationTimestampMillis = chronological[targetIndex].timestampMillis,
                evaluationPrice = evaluationPrice
            )
        }

        return ReplayResult(sessionId, chronological.size, steps, AccuracyAnalytics.compute(entities))
    }

    private fun parseTimeframe(label: String): Timeframe? =
        Timeframe.entries.firstOrNull { "${it.minutes}m" == label }

    private fun CandleHistoryEntity.toLastCandleContext(): LastCandleContext {
        val parsedPatterns = patterns.split(",")
            .filter { it.isNotBlank() }
            .mapNotNull { name -> runCatching { CandlePattern.valueOf(name) }.getOrNull() }
            .toSet()
        return LastCandleContext(
            closePrice = close,
            direction = runCatching { CandleDirection.valueOf(direction) }.getOrDefault(CandleDirection.BULLISH),
            upperWickPx = upperWickPx,
            lowerWickPx = lowerWickPx,
            patterns = parsedPatterns
        )
    }
}
