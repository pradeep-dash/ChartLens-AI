package com.chartlens.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Point
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.chartlens.ai.R
import com.chartlens.ai.ai.AiInsightCoordinator
import com.chartlens.ai.analysis.AnalysisStateRepository
import com.chartlens.ai.capture.CapturedFrame
import com.chartlens.ai.capture.ScreenCaptureController
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import com.chartlens.ai.common.LatestFrameHolder
import com.chartlens.ai.cv.ChartRegion
import com.chartlens.ai.cv.FrameAnalyzer
import com.chartlens.ai.journal.JournalCoordinator
import com.chartlens.ai.database.CandleHistoryRepository
import com.chartlens.ai.database.toPriceCandle
import com.chartlens.ai.replay.CandleHistoryRecorder
import com.chartlens.ai.settings.ManualChartRegionStore
import com.chartlens.ai.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Foreground service that owns the MediaProjection session end-to-end.
 *
 * Why LifecycleService: gives us `lifecycleScope` for coroutine collection of the
 * capture Flow, tied automatically to the service's actual lifecycle instead of a
 * manually-managed CoroutineScope.
 *
 * MediaProjection permission grants are single-use and tied to the resultCode/Intent
 * pair returned by the system permission dialog — they are NOT persisted or reused
 * across service restarts. A new grant is required every time capture starts,
 * including after process death.
 */
@AndroidEntryPoint
class ScreenCaptureService : LifecycleService() {

    @Inject lateinit var captureStateRepository: CaptureStateRepository
    @Inject lateinit var analysisStateRepository: AnalysisStateRepository
    @Inject lateinit var latestFrameHolder: LatestFrameHolder
    @Inject lateinit var manualChartRegionStore: ManualChartRegionStore
    @Inject lateinit var aiInsightCoordinator: AiInsightCoordinator
    @Inject lateinit var journalCoordinator: JournalCoordinator
    @Inject lateinit var candleHistoryRecorder: CandleHistoryRecorder
    @Inject lateinit var candleHistoryRepository: CandleHistoryRepository

    private var mediaProjection: MediaProjection? = null
    private var captureController: ScreenCaptureController? = null
    private var collectJob: Job? = null
    private var analysisJob: Job? = null
    private var frameAnalyzer: FrameAnalyzer = FrameAnalyzer()

    private var capturedFrameCount: Long = 0
    private var analyzedFrameCount: Long = 0
    private var startedAtMillis: Long = 0L
    private var previousManualRegion: ChartRegion? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> handleStop()
            ACTION_PAUSE -> handlePause()
            ACTION_RESUME -> handleResume()
            else -> {
                Log.w(TAG, "Started with unknown or null action: ${intent?.action}")
                handleStop()
            }
        }
        return START_NOT_STICKY // do not auto-restart with a stale/invalid projection grant
    }

    private fun handleStart(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultData == null) {
            captureStateRepository.update(
                CaptureState.Error("Missing screen-capture permission result", recoverable = true)
            )
            stopSelf()
            return
        }

        // Foreground promotion MUST happen before MediaProjectionManager.getMediaProjection()
        // on Android 14+ (the OS requires the FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION service
        // to already be running in foreground state before it will grant the projection).
        // The 3-arg overload (explicit foreground service type) is available since API 29,
        // which matches this module's minSdk — no version gate needed.
        startForeground(
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        startCaptureSession(resultCode, resultData)
    }

    private fun startCaptureSession(resultCode: Int, resultData: Intent) {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val projection = try {
            projectionManager.getMediaProjection(resultCode, resultData)
        } catch (t: Throwable) {
            Log.e(TAG, "getMediaProjection failed", t)
            captureStateRepository.update(
                CaptureState.Error("Could not start screen capture: ${t.message}", recoverable = true)
            )
            stopSelf()
            return
        }

        if (projection == null) {
            captureStateRepository.update(
                CaptureState.Error("System denied the capture session", recoverable = true)
            )
            stopSelf()
            return
        }

        beginCaptureLoop(projection)
    }

    /**
     * The actual "start analyzing" logic, shared by two real entry points: a genuinely
     * fresh [MediaProjection] grant ([startCaptureSession]) and reusing an existing,
     * still-valid one after a pause ([handleResume]) — the two differ only in where the
     * [MediaProjection] instance comes from, everything after that is identical. Always
     * begins a fresh logical session (new `startedAtMillis`, cleared caches, a new
     * candle-history/journal session grouping) even on resume — the underlying OS grant
     * carries over, but there's a genuine time gap with nothing recorded during it, and
     * treating it as a continuation would misrepresent that gap as continuous data.
     */
    private fun beginCaptureLoop(projection: MediaProjection) {
        mediaProjection = projection
        startedAtMillis = System.currentTimeMillis()
        capturedFrameCount = 0
        analyzedFrameCount = 0
        frameAnalyzer.close() // release the previous session's ML Kit recognizer before replacing it
        frameAnalyzer = FrameAnalyzer(
            // Feeds the live pipeline the same accumulated, real recorded history Replay
            // already uses — otherwise technical analysis is silently bounded by however
            // many candles fit on screen at once. Queried fresh each frame rather than
            // cached, since the repository itself is the source of truth and Room reads
            // are cheap relative to everything else this pipeline already does per frame.
            sessionHistoryProvider = {
                candleHistoryRepository.getSession(startedAtMillis).map { it.toPriceCandle() }
            }
        ) // fresh chart-region/OCR cache for this session
        aiInsightCoordinator.reset()
        journalCoordinator.reset()
        candleHistoryRecorder.startSession(startedAtMillis)
        previousManualRegion = null

        val metrics = currentScreenMetrics()
        val controller = ScreenCaptureController()
        captureController = controller

        collectJob?.cancel()
        collectJob = controller.start(
            mediaProjection = projection,
            targetWidthPx = metrics.widthPx,
            targetHeightPx = metrics.heightPx,
            screenDensityDpi = metrics.densityDpi,
            onProjectionStopped = { onProjectionLost() }
        ).onEach { frame -> onFrame(frame) }
            .launchIn(lifecycleScope)
    }

    private fun onFrame(frame: CapturedFrame) {
        capturedFrameCount++
        if (frame.hasMaterialChange) {
            analyzedFrameCount++
            runAnalysisIfIdle(frame)
        }

        captureStateRepository.update(
            CaptureState.Capturing(
                frameWidth = frame.width,
                frameHeight = frame.height,
                capturedFrameCount = capturedFrameCount,
                analyzedFrameCount = analyzedFrameCount,
                lastFrameAtMillis = frame.timestampMillis,
                startedAtMillis = startedAtMillis
            )
        )
    }

    /**
     * Runs the CV pipeline (ChartDetector -> CandleDetector -> CandlePatternDetector)
     * off the main thread. Skips launching a new analysis pass if the previous one
     * is still running, rather than piling up overlapping heavy pixel work — this
     * is the throttle that keeps CV cost bounded even if a device is slow to
     * process a single frame.
     */
    private fun runAnalysisIfIdle(frame: CapturedFrame) {
        if (analysisJob?.isActive == true) return

        val manualRegion = manualChartRegionStore.load()?.toChartRegion(frame.width, frame.height)
        if (manualRegion != previousManualRegion) {
            // The user just saved or cleared a manual selection — a cached price/timeframe
            // mapping fitted from the OLD region's price-axis crop would otherwise linger
            // (stale) until the next scheduled OCR pass, up to ocrEveryNFrames frames later.
            frameAnalyzer.invalidateCache()
            previousManualRegion = manualRegion
        }

        analysisJob = lifecycleScope.launch(Dispatchers.Default) {
            val result = frameAnalyzer.analyze(frame.bitmap, manualRegion, frame.timestampMillis)
            analysisStateRepository.update(result)
            latestFrameHolder.update(frame.bitmap)
            // Launched into lifecycleScope (not this analysisJob) deliberately — an AI call
            // is a slow network round-trip and must never hold up the next frame's local,
            // fast analysis. AiTriggerPolicy inside the coordinator decides whether this
            // frame is even worth a call at all before anything network-related happens.
            aiInsightCoordinator.onNewFrame(result, lifecycleScope)
            // Journaling runs inline (not a separate launch) — it's local Room I/O, not a
            // network call, and stays fast enough not to delay the next frame meaningfully.
            journalCoordinator.onNewFrame(result)
            candleHistoryRecorder.onNewFrame(result)
        }
    }

    private fun onProjectionLost() {
        Log.i(TAG, "Projection lost (system/user stopped screen sharing)")
        captureStateRepository.update(CaptureState.Stopped)
        handleStop()
    }

    private fun handleStop() {
        collectJob?.cancel()
        collectJob = null

        analysisJob?.cancel()
        analysisJob = null

        frameAnalyzer.close()

        captureController?.release()
        captureController = null

        try {
            mediaProjection?.stop()
        } catch (t: Throwable) {
            Log.w(TAG, "Error stopping MediaProjection", t)
        }
        mediaProjection = null

        if (captureStateRepository.current() !is CaptureState.Error) {
            captureStateRepository.update(CaptureState.Stopped)
        }

        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /**
     * Stops analyzing but deliberately keeps [mediaProjection] alive, unlike [handleStop] —
     * see [CaptureState.Paused]'s doc comment for why, and the real tradeoff this accepts
     * (the system's screen-recording indicator stays visible while paused). The Service
     * itself also stays in the foreground state; only the capture/analysis pipeline
     * actually stops doing work.
     */
    private fun handlePause() {
        // Defensive guard: with nothing actually running (no retained MediaProjection),
        // there is nothing to pause — falling through would incorrectly transition to
        // Paused and leave the UI offering a Resume button whose tap would be a genuine
        // dead-end (handleResume() safely no-ops with no projection to reuse). The
        // overlay/Dashboard only ever call pause() while genuinely capturing in normal
        // use, but this keeps the state machine honest regardless.
        if (mediaProjection == null) {
            Log.w(TAG, "handlePause() called with nothing running — ignoring")
            return
        }

        collectJob?.cancel()
        collectJob = null

        analysisJob?.cancel()
        analysisJob = null

        // Cheap to recreate on resume (this is exactly what onConfigurationChanged already
        // does for a rotation, reusing the same MediaProjection) — no reason to keep the
        // VirtualDisplay/ImageReader/HandlerThread alive while genuinely paused.
        captureController?.release()
        captureController = null

        frameAnalyzer.close()

        val pausedAt = System.currentTimeMillis()
        if (captureStateRepository.current() !is CaptureState.Error) {
            captureStateRepository.update(CaptureState.Paused(pausedAtMillis = pausedAt))
        }

        // Refresh the notification to reflect the paused state and offer Resume instead
        // of Stop — startForeground() again is safe/idempotent; the Service was already
        // in the foreground state and never left it.
        startForeground(NOTIFICATION_ID, buildNotification(paused = true), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    /**
     * Resumes a paused session with no new consent dialog — only meaningful while
     * genuinely paused (mediaProjection still held). If called with nothing to resume
     * (a real inconsistency, not an expected path — the overlay only offers Resume when
     * state is genuinely Paused), logs and does nothing rather than crashing.
     */
    private fun handleResume() {
        val projection = mediaProjection
        if (projection == null) {
            Log.w(TAG, "handleResume() called with no retained MediaProjection — ignoring")
            return
        }
        Log.i(TAG, "Resuming a paused session — reusing the existing MediaProjection grant")
        startForeground(NOTIFICATION_ID, buildNotification(paused = false), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        beginCaptureLoop(projection)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotation / density change invalidates the VirtualDisplay's fixed-size surface.
        // Tear down and recreate against the new metrics if a session is active.
        val projection = mediaProjection ?: return
        Log.i(TAG, "Configuration changed — restarting capture at new dimensions")
        collectJob?.cancel()
        captureController?.release()

        val metrics = currentScreenMetrics()
        val controller = ScreenCaptureController()
        captureController = controller
        collectJob = controller.start(
            mediaProjection = projection,
            targetWidthPx = metrics.widthPx,
            targetHeightPx = metrics.heightPx,
            screenDensityDpi = metrics.densityDpi,
            onProjectionStopped = { onProjectionLost() }
        ).onEach { frame -> onFrame(frame) }
            .launchIn(lifecycleScope)
    }

    override fun onDestroy() {
        handleStop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): android.os.IBinder? {
        super.onBind(intent)
        return null // not a bound service
    }

    private data class ScreenMetrics(val widthPx: Int, val heightPx: Int, val densityDpi: Int)

    private fun currentScreenMetrics(): ScreenMetrics {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            ScreenMetrics(bounds.width(), bounds.height(), resources.displayMetrics.densityDpi)
        } else {
            @Suppress("DEPRECATION")
            val display = windowManager.defaultDisplay
            val size = Point()
            @Suppress("DEPRECATION")
            display.getRealSize(size)
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            display.getRealMetrics(dm)
            ScreenMetrics(size.x, size.y, dm.densityDpi)
        }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_capture),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_capture_desc)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(paused: Boolean = false): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        // While paused, the notification's action button offers Resume (reuses the
        // still-live MediaProjection, no new consent) rather than Stop — Stop already
        // happened; this notification's whole purpose while paused is to make the
        // still-active screen-access grant visible and give a way to end it for real.
        val actionIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, ScreenCaptureService::class.java).apply {
                action = if (paused) ACTION_RESUME else ACTION_STOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val actionLabel = if (paused) getString(R.string.action_resume_analysis) else getString(R.string.action_stop_analysis)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.capture_notification_title))
            .setContentText(
                getString(if (paused) R.string.capture_notification_text_paused else R.string.capture_notification_text)
            )
            .setSmallIcon(R.drawable.ic_notification_capture)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .addAction(0, actionLabel, actionIntent)
            .build()
    }

    companion object {
        private const val TAG = "ScreenCaptureService"
        private const val CHANNEL_ID = "chartlens_capture_channel"
        private const val NOTIFICATION_ID = 42

        const val ACTION_START = "com.chartlens.ai.action.START_CAPTURE"
        const val ACTION_STOP = "com.chartlens.ai.action.STOP_CAPTURE"
        const val ACTION_PAUSE = "com.chartlens.ai.action.PAUSE_CAPTURE"
        const val ACTION_RESUME = "com.chartlens.ai.action.RESUME_CAPTURE"
        private const val EXTRA_RESULT_CODE = "extra_result_code"
        private const val EXTRA_RESULT_DATA = "extra_result_data"

        /** Starts the foreground capture service using a granted MediaProjection result. */
        fun start(context: Context, resultCode: Int, resultData: Intent) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, resultData)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        /** Full stop — releases MediaProjection entirely. Starting again needs fresh consent. */
        fun stop(context: Context) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        /** Pauses analysis but deliberately keeps MediaProjection alive — see
         * [com.chartlens.ai.common.CaptureState.Paused]'s doc comment for the tradeoff
         * this accepts (the system capture indicator stays visible while paused). */
        fun pause(context: Context) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_PAUSE
            }
            context.startService(intent)
        }

        /** Resumes a paused session with NO new consent dialog — only valid to call while
         * genuinely Paused; a no-op otherwise (see [handleResume]'s guard). */
        fun resume(context: Context) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_RESUME
            }
            context.startService(intent)
        }
    }
}
