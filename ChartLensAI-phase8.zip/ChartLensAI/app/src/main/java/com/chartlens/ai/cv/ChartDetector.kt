package com.chartlens.ai.cv

import com.chartlens.ai.common.PixelBuffer

/**
 * Locates the most probable candlestick-chart region in a full-frame [PixelBuffer]
 * using candle-color density and bar-spacing regularity — never fixed coordinates,
 * per the "do not hardcode chart location" requirement. Works across different
 * trading apps/layouts because it only looks for the visual signature of a
 * candlestick chart (clustered, evenly-spaced, alternating bullish/bearish
 * vertical bars), not any particular app's UI structure.
 *
 * This is intentionally a coarse, cheap heuristic — good enough to find "roughly
 * where the candles are" so [com.chartlens.ai.candle.CandleDetector] can work on a
 * cropped region instead of the whole screen. It is not pixel-perfect and will
 * sometimes return null (below-confidence) on unusual layouts; the manual crop
 * fallback ([ManualChartRegionStore]) exists specifically for that case.
 */
class ChartDetector(
    private val colorProfile: CandleColorProfile = CandleColorProfile(),
    private val minColumnDensityFraction: Float = 0.04f, // fraction of column height that must be candle-colored
    private val maxColumnGapPx: Int = 24, // gap tolerance when clustering candle columns horizontally
    private val minCandleColumns: Int = 30,
    private val minColorTransitions: Int = 3, // guards against a single colored icon/button
    private val minRowDensityFraction: Float = 0.06f, // fraction of cluster width that must be candle-colored, per row
    private val maxRowGapPx: Int = 20, // gap tolerance when clustering candle rows vertically
    private val verticalPaddingPx: Int = 6
) {

    fun detect(frame: PixelBuffer): ChartRegion? {
        if (frame.width < minCandleColumns || frame.height < 20) return null

        val columnHasCandleColor = BooleanArray(frame.width)
        val columnDominantClass = arrayOfNulls<PixelClassification>(frame.width)

        for (x in 0 until frame.width) {
            var bullishCount = 0
            var bearishCount = 0
            for (y in 0 until frame.height) {
                when (colorProfile.classify(frame.get(x, y))) {
                    PixelClassification.BULLISH -> bullishCount++
                    PixelClassification.BEARISH -> bearishCount++
                    PixelClassification.OTHER -> Unit
                }
            }
            val total = bullishCount + bearishCount
            val density = total.toFloat() / frame.height
            columnHasCandleColor[x] = density >= minColumnDensityFraction
            if (columnHasCandleColor[x]) {
                columnDominantClass[x] =
                    if (bullishCount >= bearishCount) PixelClassification.BULLISH else PixelClassification.BEARISH
            }
        }

        val bestCluster = findBestColumnCluster(columnHasCandleColor) ?: return null
        val (clusterStart, clusterEnd) = bestCluster

        val candleColumnCount = (clusterStart..clusterEnd).count { columnHasCandleColor[it] }
        if (candleColumnCount < minCandleColumns) return null

        val transitions = countColorTransitions(columnDominantClass, clusterStart, clusterEnd)
        if (transitions < minColorTransitions) return null

        // Vertical extent uses the SAME gap-tolerant clustering as the horizontal pass
        // above, not a simple min/max across every touched row — a simple min/max was
        // found on a real device to extend the region far past the real candle area
        // when a handful of columns also touched an unrelated same-hue UI element
        // (the Up/Down trade buttons, which use the identical bullish/bearish color
        // family) much further down the screen, dragging region.bottom deep into the
        // trading-panel UI and starving the time-axis OCR crop of any real label text
        // to find. Any single/few outlier columns touching a distant colored element no
        // longer extend the bounds; only a genuinely contiguous row-cluster does.
        val (top0, bottom0) = findVerticalBounds(frame, clusterStart, clusterEnd) ?: return null

        val top = (top0 - verticalPaddingPx).coerceAtLeast(0)
        val bottom = (bottom0 + verticalPaddingPx).coerceAtMost(frame.height)

        val densityScore = candleColumnCount.toFloat() / (clusterEnd - clusterStart + 1)
        val transitionScore = (transitions.toFloat() / minColorTransitions).coerceAtMost(1.5f) / 1.5f
        val confidence = (0.6f * densityScore + 0.4f * transitionScore).coerceIn(0f, 1f)

        val region = ChartRegion(
            left = clusterStart,
            top = top,
            right = clusterEnd + 1,
            bottom = bottom,
            confidence = confidence,
            source = ChartRegion.Source.AUTO_DETECTED
        )
        return if (region.isUsable()) region else null
    }

    /**
     * Finds the widest contiguous run of rows (within the already-determined
     * horizontal cluster) with enough candle-colored pixel density, tolerating
     * gaps up to [maxRowGapPx] — the same algorithm as [findBestColumnCluster],
     * applied to the other axis. A second, real pixel-classification pass over
     * just the horizontal cluster's columns (not the full frame width), since
     * per-row density wasn't accumulated during the first pass.
     */
    private fun findVerticalBounds(frame: PixelBuffer, clusterStart: Int, clusterEnd: Int): Pair<Int, Int>? {
        val clusterWidth = clusterEnd - clusterStart + 1
        val rowHasCandleColor = BooleanArray(frame.height)

        for (y in 0 until frame.height) {
            var count = 0
            for (x in clusterStart..clusterEnd) {
                if (colorProfile.classify(frame.get(x, y)) != PixelClassification.OTHER) count++
            }
            rowHasCandleColor[y] = (count.toFloat() / clusterWidth) >= minRowDensityFraction
        }

        return findBestRowCluster(rowHasCandleColor)
    }

    private fun findBestRowCluster(rowHasCandleColor: BooleanArray): Pair<Int, Int>? {
        var bestStart = -1
        var bestEnd = -1
        var bestScore = 0

        var clusterStart = -1
        var lastRow = -1

        for (y in rowHasCandleColor.indices) {
            if (rowHasCandleColor[y]) {
                if (clusterStart == -1) {
                    clusterStart = y
                } else if (y - lastRow > maxRowGapPx) {
                    val score = lastRow - clusterStart
                    if (score > bestScore) {
                        bestScore = score
                        bestStart = clusterStart
                        bestEnd = lastRow
                    }
                    clusterStart = y
                }
                lastRow = y
            }
        }
        if (clusterStart != -1) {
            val score = lastRow - clusterStart
            if (score > bestScore) {
                bestScore = score
                bestStart = clusterStart
                bestEnd = lastRow
            }
        }

        return if (bestStart == -1) null else bestStart to bestEnd
    }

    /** Finds the widest run of candle-colored columns, tolerating gaps up to [maxColumnGapPx]. */
    private fun findBestColumnCluster(columnHasCandleColor: BooleanArray): Pair<Int, Int>? {
        var bestStart = -1
        var bestEnd = -1
        var bestScore = 0

        var clusterStart = -1
        var lastCandleColumn = -1

        for (x in columnHasCandleColor.indices) {
            if (columnHasCandleColor[x]) {
                if (clusterStart == -1) {
                    clusterStart = x
                } else if (x - lastCandleColumn > maxColumnGapPx) {
                    // gap too large — close current cluster, evaluate, start a new one
                    val score = lastCandleColumn - clusterStart
                    if (score > bestScore) {
                        bestScore = score
                        bestStart = clusterStart
                        bestEnd = lastCandleColumn
                    }
                    clusterStart = x
                }
                lastCandleColumn = x
            }
        }
        if (clusterStart != -1) {
            val score = lastCandleColumn - clusterStart
            if (score > bestScore) {
                bestScore = score
                bestStart = clusterStart
                bestEnd = lastCandleColumn
            }
        }

        return if (bestStart == -1) null else bestStart to bestEnd
    }

    private fun countColorTransitions(
        columnDominantClass: Array<PixelClassification?>,
        start: Int,
        end: Int
    ): Int {
        var transitions = 0
        var previous: PixelClassification? = null
        for (x in start..end) {
            val current = columnDominantClass[x] ?: continue
            if (previous != null && current != previous) transitions++
            previous = current
        }
        return transitions
    }
}
