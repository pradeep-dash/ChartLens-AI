package com.chartlens.ai.analytics

/** [total] includes wins/losses/neutral/invalid within this bucket; accuracy is
 * computed only from decisive (win or loss) outcomes, per [AccuracyStats]. */
data class AccuracyBucket(val label: String, val total: Int, val wins: Int, val losses: Int) {
    val accuracyPercent: Float?
        get() {
            val decisive = wins + losses
            return if (decisive == 0) null else (wins.toFloat() / decisive) * 100f
        }
}

/**
 * [overallAccuracyPercent] and every bucket's accuracy are computed only from
 * decisive (WIN or LOSS) outcomes — NEUTRAL and INVALID_DATA entries are
 * counted in totals but don't count as either a win or a loss, since neither
 * represents the prediction's direction being right or wrong.
 *
 * [hasEnoughDataForEdgeClaim] is the direct implementation of the spec's "do
 * NOT claim the model has an edge until enough observations exist" — the
 * minimum sample size is a documented judgment call
 * ([AccuracyAnalytics.MIN_EVALUATED_FOR_EDGE_CLAIM]), not a statistically
 * derived threshold. The UI must check this before displaying accuracy as
 * if it means something.
 */
data class AccuracyStats(
    val totalPredictions: Int,
    val evaluatedPredictions: Int,
    val wins: Int,
    val losses: Int,
    val neutral: Int,
    val invalidData: Int,
    val unresolved: Int,
    val overallAccuracyPercent: Float?,
    val accuracyByInstrument: List<AccuracyBucket>,
    val accuracyByTimeframe: List<AccuracyBucket>,
    val accuracyByConfidenceBucket: List<AccuracyBucket>,
    val accuracyBySetup: List<AccuracyBucket>,
    /** Positive = current winning streak, negative = current losing streak, 0 = none yet. */
    val currentStreak: Int,
    val maxWinningStreak: Int,
    val maxLosingStreak: Int,
    val hasEnoughDataForEdgeClaim: Boolean
)
