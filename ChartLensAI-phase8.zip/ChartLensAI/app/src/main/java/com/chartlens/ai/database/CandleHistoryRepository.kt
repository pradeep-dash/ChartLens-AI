package com.chartlens.ai.database

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CandleHistoryRepository @Inject constructor(
    private val dao: CandleHistoryDao
) {
    suspend fun record(candle: CandleHistoryEntity): Long = dao.insert(candle)

    suspend fun getSessionIds(): List<Long> = dao.getSessionIds()

    suspend fun getSession(sessionId: Long): List<CandleHistoryEntity> = dao.getSession(sessionId)

    suspend fun countForSession(sessionId: Long): Int = dao.countForSession(sessionId)
}
