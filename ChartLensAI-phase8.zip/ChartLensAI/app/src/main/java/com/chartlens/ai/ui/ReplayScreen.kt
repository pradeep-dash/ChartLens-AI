package com.chartlens.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.chartlens.ai.prediction.PredictionOutcome
import com.chartlens.ai.replay.ReplayResult
import com.chartlens.ai.replay.ReplayStep
import kotlinx.coroutines.launch

data class ReplaySessionSummary(val sessionId: Long, val candleCount: Int)

/**
 * Sessions are only ever built from real recorded history
 * ([com.chartlens.ai.replay.CandleHistoryRecorder]) — there is no synthetic
 * or sample dataset to demo this screen with. An empty list here means
 * exactly what it says: no live session has recorded enough candles yet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReplayScreen(
    loadSessions: suspend () -> List<ReplaySessionSummary>,
    runReplay: suspend (sessionId: Long) -> ReplayResult,
    onBack: () -> Unit
) {
    var sessions by remember { mutableStateOf<List<ReplaySessionSummary>>(emptyList()) }
    var isLoadingSessions by remember { mutableStateOf(true) }
    var selectedResult by remember { mutableStateOf<ReplayResult?>(null) }
    var isRunningReplay by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        sessions = loadSessions()
        isLoadingSessions = false
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Replay / Backtest") }) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).padding(16.dp)) {
            val result = selectedResult
            if (result != null) {
                item {
                    Text("Replay Result", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "${result.steps.size} predictions generated from " +
                            "${result.totalCandlesInSession} recorded candles. Each prediction only " +
                            "ever saw candles that existed before it — never anything after.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AccuracySummaryCard(result.accuracyStats)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Steps", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                }
                items(result.steps) { step ->
                    ReplayStepRow(step)
                    Spacer(modifier = Modifier.height(6.dp))
                }
                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(onClick = { selectedResult = null }, modifier = Modifier.fillMaxWidth()) {
                        Text("Back to sessions")
                    }
                }
            } else {
                item {
                    Text("Recorded Sessions", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                }
                when {
                    isLoadingSessions -> item { Text("Loading…") }
                    sessions.isEmpty() -> item {
                        Text(
                            "No recorded sessions yet. Real candles get recorded automatically " +
                                "during a live capture session as they close — run one first."
                        )
                    }
                    else -> items(sessions) { session ->
                        SessionRow(
                            session = session,
                            isRunningReplay = isRunningReplay,
                            onRun = {
                                scope.launch {
                                    isRunningReplay = true
                                    selectedResult = runReplay(session.sessionId)
                                    isRunningReplay = false
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                        Text("Back")
                    }
                }
            }
        }
    }
}

@Composable
private fun SessionRow(session: ReplaySessionSummary, isRunningReplay: Boolean, onRun: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column {
                Text("Session ${session.sessionId}")
                Text("${session.candleCount} recorded candles", style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = onRun, enabled = !isRunningReplay) {
                Text(if (isRunningReplay) "Running…" else "Run Replay")
            }
        }
    }
}

@Composable
private fun ReplayStepRow(step: ReplayStep) {
    val outcomeColor = when (step.outcome) {
        PredictionOutcome.WIN -> Color(0xFF26A69A)
        PredictionOutcome.LOSS -> Color(0xFFEF5350)
        PredictionOutcome.NEUTRAL -> Color(0xFF90A4AE)
        else -> Color(0xFFFFA726)
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth().padding(10.dp)
        ) {
            Text("#${step.candleIndex} ${step.prediction.direction} · ${step.prediction.modelConfidence}/100")
            Text(step.outcome.name, color = outcomeColor)
        }
    }
}
