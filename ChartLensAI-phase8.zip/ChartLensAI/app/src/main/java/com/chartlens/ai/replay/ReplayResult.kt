package com.chartlens.ai.replay

import com.chartlens.ai.analytics.AccuracyStats
import com.chartlens.ai.prediction.PredictionOutcome
import com.chartlens.ai.prediction.PredictionResult

data class ReplayStep(
    val candleIndex: Int,
    val timestampMillis: Long,
    val prediction: PredictionResult,
    val outcome: PredictionOutcome,
    val entryPrice: Double,
    val evaluationPrice: Double
)

/**
 * [accuracyStats] is computed via the exact same [com.chartlens.ai.analytics.AccuracyAnalytics]
 * a live session uses, from ordinary [com.chartlens.ai.database.PredictionEntity] rows built
 * in-memory during replay — these are never written to the real database, so a
 * backtest run can never pollute Phase 7's live accuracy numbers.
 */
data class ReplayResult(
    val sessionId: Long,
    val totalCandlesInSession: Int,
    val steps: List<ReplayStep>,
    val accuracyStats: AccuracyStats
)
