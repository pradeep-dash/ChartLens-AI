package com.chartlens.ai.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.AnalysisStateRepository
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import com.chartlens.ai.prediction.PredictionDirection
import com.chartlens.ai.service.ScreenCaptureService
import dagger.hilt.android.AndroidEntryPoint
import kotlin.math.roundToInt
import javax.inject.Inject

/**
 * Draws the floating "ChartLens AI" status card above whatever app is currently in
 * the foreground, using [WindowManager] directly (not an Activity window).
 *
 * Phase 1 scope: shows real capture status only (fps, frame size, uptime) — no
 * bias/confidence/pattern fields, because that layer does not exist yet. Adding
 * those fields is Phase 6's job (AiAnalysisProvider) wired through the same
 * CaptureStateRepository pattern extended with a MarketState/PredictionState flow.
 */
@AndroidEntryPoint
class OverlayService : Service() {

    @Inject lateinit var captureStateRepository: CaptureStateRepository
    @Inject lateinit var analysisStateRepository: AnalysisStateRepository

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission not granted — cannot show floating status")
            stopSelf()
            return
        }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val owner = OverlayLifecycleOwner().also { it.onCreate() }
        lifecycleOwner = owner

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }
        layoutParams = params

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent {
                MaterialTheme {
                    OverlayCard(
                        captureStateRepository = captureStateRepository,
                        analysisStateRepository = analysisStateRepository,
                        onDrag = { dx, dy -> onOverlayDragged(dx, dy) },
                        onStop = { onStopRequested() }
                    )
                }
            }
        }
        composeView = view

        owner.onStart()
        wm.addView(view, params)
    }

    private fun onOverlayDragged(dx: Float, dy: Float) {
        val params = layoutParams ?: return
        val view = composeView ?: return
        params.x += dx.roundToInt()
        params.y += dy.roundToInt()
        try {
            windowManager?.updateViewLayout(view, params)
        } catch (t: Throwable) {
            Log.w(TAG, "updateViewLayout failed", t)
        }
    }

    private fun onStopRequested() {
        ScreenCaptureService.stop(this)
        stopSelf()
    }

    override fun onDestroy() {
        try {
            composeView?.let { windowManager?.removeView(it) }
        } catch (t: Throwable) {
            Log.w(TAG, "removeView failed (already detached?)", t)
        }
        lifecycleOwner?.onDestroy()
        composeView = null
        windowManager = null
        layoutParams = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "OverlayService"

        fun start(context: Context) {
            context.startService(Intent(context, OverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}

/**
 * Correctness-critical detail: MediaProjection captures the full composited
 * display, not just the target app's content — it cannot distinguish "the
 * chart" from "this app's own floating overlay window." That means whatever
 * this panel renders while expanded is itself part of the raw frame
 * [com.chartlens.ai.cv.FrameAnalyzer] analyzes. A real device test showed
 * exactly this: candle counts swinging wildly (37/38 GOOD one frame, 0/1
 * POOR eleven frames later) with no corresponding chart-side event — the
 * likely cause was this panel's own content sitting over real candles the
 * whole time, since every screenshot across this project has shown it
 * expanded and positioned over the chart's lower-center area.
 *
 * [expanded] therefore now genuinely gates the large debug block (it
 * previously only gated the opacity slider — a real design flaw, not a
 * deliberate choice; the collapse button looked like it was hiding the bulk
 * of the panel but never actually was) and defaults to collapsed. This
 * reduces, but cannot fully eliminate, the risk — the only complete fix
 * would be genuinely excluding this window from capture (not currently
 * implemented; `FLAG_SECURE` was considered and rejected, since it replaces
 * this panel's content with a black rectangle in the capture rather than
 * making it transparent to whatever's underneath, which would still hide
 * the same candles just as fully). Collapsed footprint is now roughly one
 * line rather than seven. An earlier version of this panel also carried a
 * persistent warning about this in the expanded view; removed once it had
 * served its purpose of explaining the risk, since a user who already
 * understands it and is positioning the overlay correctly doesn't need it
 * repeated on every expand.
 */
@Composable
private fun OverlayCard(
    captureStateRepository: CaptureStateRepository,
    analysisStateRepository: AnalysisStateRepository,
    onDrag: (Float, Float) -> Unit,
    onStop: () -> Unit
) {
    val state by captureStateRepository.state.collectAsState()
    val analysisFrame by analysisStateRepository.latestFrame.collectAsState()
    var expanded by remember { mutableStateOf(false) }
    var opacity by remember { mutableFloatStateOf(0.95f) }

    Surface(
        modifier = Modifier
            .widthIn(min = 200.dp, max = 260.dp)
            .alpha(opacity)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            },
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF121212),
        contentColor = Color.White,
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.widthIn(min = 180.dp)
            ) {
                Text(
                    text = "CHARTLENS AI",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFB0BEC5)
                )
                Row {
                    IconButton(onClick = { expanded = !expanded }, modifier = Modifier.width(28.dp)) {
                        Icon(
                            imageVector = if (expanded) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp,
                            contentDescription = if (expanded) "Collapse" else "Expand",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onStop, modifier = Modifier.width(28.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Stop analysis",
                            tint = Color(0xFFEF5350)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.padding(top = 4.dp))
            if (expanded) {
                StatusLine(state)
            } else {
                CompactStatusLine(state)
            }

            if (state is CaptureState.Capturing) {
                Spacer(modifier = Modifier.padding(top = 6.dp))
                if (expanded) {
                    AnalysisStatusLine(analysisFrame)
                } else {
                    CompactAnalysisLine(analysisFrame)
                }
            }

            if (expanded) {
                Spacer(modifier = Modifier.padding(top = 8.dp))
                Text(
                    text = "Overlay opacity",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF90A4AE)
                )
                Slider(
                    value = opacity,
                    onValueChange = { opacity = it.coerceIn(0.3f, 1f) },
                    valueRange = 0.3f..1f
                )
            }
        }
    }
}

@Composable
private fun CompactStatusLine(state: CaptureState) {
    val (label, color) = when (state) {
        is CaptureState.Idle -> "IDLE" to Color(0xFF90A4AE)
        is CaptureState.AwaitingPermission -> "WAITING" to Color(0xFFFFA726)
        is CaptureState.Capturing -> "CAPTURING" to Color(0xFF26A69A)
        is CaptureState.Stopped -> "STOPPED" to Color(0xFF90A4AE)
        is CaptureState.Error -> "ERROR" to Color(0xFFEF5350)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.padding(end = 6.dp).size(8.dp)) {
            drawCircle(color = color, radius = size.minDimension / 2)
        }
        Text(text = label, style = MaterialTheme.typography.labelLarge, color = color)
    }
}

/** The single line this whole fix exists to make the *default*, not a fallback — see
 * [OverlayCard]'s doc comment. Deliberately just the prediction, nothing else: candle
 * counts, quality, price mapping, timeframe, and RSI are all still available by
 * expanding, but none of that needs to sit on top of the chart continuously. */
@Composable
private fun CompactAnalysisLine(frame: AnalysisFrame?) {
    val prediction = frame?.prediction
    if (prediction == null) {
        Text(text = "Analyzing…", style = MaterialTheme.typography.bodySmall, color = Color(0xFF90A4AE))
        return
    }
    val (label, color) = when (prediction.direction) {
        PredictionDirection.UP -> "🟢 BULLISH ${prediction.modelConfidence}" to Color(0xFF26A69A)
        PredictionDirection.DOWN -> "🔴 BEARISH ${prediction.modelConfidence}" to Color(0xFFEF5350)
        PredictionDirection.NO_TRADE -> "⚠ NO SETUP" to Color(0xFFFFA726)
    }
    Text(text = label, style = MaterialTheme.typography.labelLarge, color = color)
}

@Composable
private fun AnalysisStatusLine(frame: AnalysisFrame?) {
    if (frame == null) {
        Text(
            text = "Analyzing…",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF90A4AE)
        )
        return
    }

    val qualityColor = when (frame.dataQuality) {
        DataQuality.GOOD -> Color(0xFF26A69A)
        DataQuality.FAIR -> Color(0xFFFFA726)
        DataQuality.POOR -> Color(0xFFFF7043)
        DataQuality.INVALID -> Color(0xFFEF5350)
    }

    Column {
        if (frame.chartRegion == null || !frame.chartRegion.isUsable()) {
            Text(
                text = "No chart detected — try Manual Chart Selection",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFF7043)
            )
        } else {
            Text(
                text = "${frame.closedCandleCount}/${frame.candles.size} candles · " +
                    "region ${(frame.chartRegion.confidence * 100).toInt()}% · " +
                    "quality ${frame.dataQuality.name}",
                style = MaterialTheme.typography.bodySmall,
                color = qualityColor
            )

            frame.prediction?.let { prediction ->
                Spacer(modifier = Modifier.padding(top = 4.dp))
                val (label, predictionColor) = when (prediction.direction) {
                    PredictionDirection.UP -> "🟢 BULLISH" to Color(0xFF26A69A)
                    PredictionDirection.DOWN -> "🔴 BEARISH" to Color(0xFFEF5350)
                    PredictionDirection.NO_TRADE -> "⚠ NO CLEAR SETUP" to Color(0xFFFFA726)
                }
                Text(text = label, style = MaterialTheme.typography.labelLarge, color = predictionColor)
                if (prediction.direction != PredictionDirection.NO_TRADE) {
                    Text(
                        text = "Model Confidence: ${prediction.modelConfidence}/100",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCFD8DC)
                    )
                }
            }

            val mapping = frame.priceScaleMapping
            if (mapping != null) {
                val trusted = mapping.confidence >= 0.6f
                Text(
                    text = "Price mapping: ${(mapping.confidence * 100).toInt()}% confidence " +
                        "(${mapping.sampleCount} labels)" + if (!trusted) " — too weak, not used" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (trusted) Color(0xFF90A4AE) else Color(0xFFFF7043)
                )
            } else {
                Text(
                    text = "Price: unmapped (waiting on OCR)",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF90A4AE)
                )
            }

            val timeframe = frame.timeframeResult?.timeframe
            Text(
                text = "Timeframe: ${timeframe?.let { "${it.minutes}m" } ?: "Unknown"}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF90A4AE)
            )

            frame.technicalAnalysis?.rsi14?.let { rsi ->
                Text(
                    text = "RSI(14): ${"%.1f".format(rsi)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF90A4AE)
                )
            }
        }
    }
}

@Composable
private fun StatusLine(state: CaptureState) {
    val (label, detail, color) = when (state) {
        is CaptureState.Idle -> Triple("IDLE", "Not analyzing", Color(0xFF90A4AE))
        is CaptureState.AwaitingPermission -> Triple("WAITING", "Awaiting permission", Color(0xFFFFA726))
        is CaptureState.Capturing -> Triple(
            "CAPTURING",
            "${state.frameWidth}×${state.frameHeight} · ${state.analyzedFrameCount} analyzed",
            Color(0xFF26A69A)
        )
        is CaptureState.Stopped -> Triple("STOPPED", "Capture ended", Color(0xFF90A4AE))
        is CaptureState.Error -> Triple("ERROR", state.message, Color(0xFFEF5350))
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(
            modifier = Modifier
                .padding(end = 6.dp)
                .size(8.dp)
        ) {
            drawCircle(color = color, radius = size.minDimension / 2)
        }
        Column {
            Text(text = label, style = MaterialTheme.typography.labelLarge, color = color)
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = Color(0xFFCFD8DC))
        }
    }
}
