package com.chartlens.ai.ai

/**
 * Abstraction over "something that can reason about structured market state
 * and return a validated opinion." Kept as an interface, not a concrete
 * network class used directly, per the spec's "keep the architecture modular
 * so the CV engine, analysis engine and AI provider can be replaced
 * independently" requirement — swapping [RemoteAiAnalysisProvider] for a
 * different backend, or a fully local model someday, doesn't require
 * touching [AiInsightCoordinator] or anything upstream of it.
 */
interface AiAnalysisProvider {
    suspend fun analyze(request: AiAnalysisRequest): Result<AiAnalysisResponse>
}
