package com.chartlens.ai.ui

import androidx.lifecycle.ViewModel
import com.chartlens.ai.ai.AiInsight
import com.chartlens.ai.ai.AiInsightRepository
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.AnalysisStateRepository
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    captureStateRepository: CaptureStateRepository,
    analysisStateRepository: AnalysisStateRepository,
    aiInsightRepository: AiInsightRepository
) : ViewModel() {

    val captureState: StateFlow<CaptureState> = captureStateRepository.state
    val analysisFrame: StateFlow<AnalysisFrame?> = analysisStateRepository.latestFrame
    val aiInsight: StateFlow<AiInsight> = aiInsightRepository.insight
}
