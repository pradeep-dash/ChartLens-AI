package com.chartlens.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.chartlens.ai.analytics.AccuracyAnalytics
import com.chartlens.ai.analytics.AccuracyBucket
import com.chartlens.ai.analytics.AccuracyStats
import com.chartlens.ai.database.PredictionEntity
import com.chartlens.ai.prediction.PredictionOutcome
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(entries: List<PredictionEntity>, onBack: () -> Unit) {
    val stats = remember(entries) { AccuracyAnalytics.compute(entries) }

    Scaffold(topBar = { TopAppBar(title = { Text("Prediction Journal") }) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).padding(16.dp)) {
            item { AccuracySummaryCard(stats) }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Recent Predictions", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (entries.isEmpty()) {
                item {
                    Text(
                        "No predictions journaled yet — this fills in as the local " +
                            "prediction engine makes real BULLISH/BEARISH calls."
                    )
                }
            } else {
                items(entries.take(50)) { entry ->
                    PredictionRow(entry)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                    Text("Back")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
internal fun AccuracySummaryCard(stats: AccuracyStats) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Accuracy", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(8.dp))

            Text("Total predictions: ${stats.totalPredictions} (${stats.unresolved} pending)")
            Text("Wins: ${stats.wins} · Losses: ${stats.losses} · Neutral: ${stats.neutral} · Invalid: ${stats.invalidData}")

            Spacer(modifier = Modifier.height(8.dp))

            if (!stats.hasEnoughDataForEdgeClaim) {
                Text(
                    "Not enough evaluated predictions yet to claim any real accuracy or edge " +
                        "(${stats.wins + stats.losses} decisive so far, " +
                        "${AccuracyAnalytics.MIN_EVALUATED_FOR_EDGE_CLAIM} needed). Numbers below " +
                        "are shown for visibility only, not as a meaningful statistic yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            } else {
                stats.overallAccuracyPercent?.let {
                    Text(
                        "Overall accuracy: ${"%.1f".format(it)}% (${stats.wins + stats.losses} decisive predictions)",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("Current streak: ${describeStreak(stats.currentStreak)}")
            Text("Max winning streak: ${stats.maxWinningStreak} · Max losing streak: ${stats.maxLosingStreak}")

            if (stats.accuracyByConfidenceBucket.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("By confidence bucket", style = MaterialTheme.typography.labelMedium)
                stats.accuracyByConfidenceBucket.forEach { bucket -> BucketRow(bucket) }
            }
            if (stats.accuracyBySetup.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("By setup", style = MaterialTheme.typography.labelMedium)
                stats.accuracyBySetup.forEach { bucket -> BucketRow(bucket) }
            }
            if (stats.accuracyByTimeframe.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("By timeframe", style = MaterialTheme.typography.labelMedium)
                stats.accuracyByTimeframe.forEach { bucket -> BucketRow(bucket) }
            }
        }
    }
}

@Composable
internal fun BucketRow(bucket: AccuracyBucket) {
    val accuracyText = bucket.accuracyPercent?.let { "${"%.0f".format(it)}%" } ?: "—"
    Text(
        "${bucket.label}: $accuracyText (${bucket.wins}W/${bucket.losses}L, ${bucket.total} total)",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
private fun PredictionRow(entry: PredictionEntity) {
    val outcomeColor = when (entry.outcome) {
        PredictionOutcome.WIN.name -> Color(0xFF26A69A)
        PredictionOutcome.LOSS.name -> Color(0xFFEF5350)
        PredictionOutcome.NEUTRAL.name -> Color(0xFF90A4AE)
        PredictionOutcome.INVALID_DATA.name -> Color(0xFFFFA726)
        else -> Color(0xFF90A4AE) // UNRESOLVED
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("${entry.direction} · ${entry.modelConfidence}/100", style = MaterialTheme.typography.bodyMedium)
                Text(entry.outcome, color = outcomeColor, style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                "${entry.timeframe} · ${formatTime(entry.timestampMillis)} · entry ${"%.5f".format(entry.entryPrice)}",
                style = MaterialTheme.typography.bodySmall
            )
            entry.evaluationPrice?.let {
                Text("Evaluated at ${"%.5f".format(it)}", style = MaterialTheme.typography.bodySmall)
            }
            entry.setup?.let { Text("Setup: ${it.replace('_', ' ')}", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private fun describeStreak(streak: Int): String = when {
    streak > 0 -> "$streak win(s)"
    streak < 0 -> "${-streak} loss(es)"
    else -> "none yet"
}

private fun formatTime(millis: Long): String {
    val formatter = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
    return formatter.format(Date(millis))
}
