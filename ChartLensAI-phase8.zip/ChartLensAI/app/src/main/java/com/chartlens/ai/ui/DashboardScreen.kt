package com.chartlens.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.chartlens.ai.ai.AiInsight
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.prediction.NoTradeReason
import com.chartlens.ai.prediction.PredictionDirection
import com.chartlens.ai.prediction.PredictionResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@Composable
fun DashboardScreen(
    state: CaptureState,
    analysisFrame: AnalysisFrame?,
    aiInsight: AiInsight,
    onStartClick: () -> Unit,
    onStopClick: () -> Unit,
    onSelectChartRegionClick: () -> Unit,
    onAiSettingsClick: () -> Unit,
    onJournalClick: () -> Unit,
    onReplayClick: () -> Unit
) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "ChartLens AI",
                style = MaterialTheme.typography.headlineMedium
            )
            Text(
                text = "Real-time chart analysis assistant",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            StatusCard(state)

            if (state is CaptureState.Capturing) {
                Spacer(modifier = Modifier.height(12.dp))
                AnalysisCard(analysisFrame)
                Spacer(modifier = Modifier.height(12.dp))
                AiInsightCard(aiInsight)
            }

            Spacer(modifier = Modifier.height(24.dp))

            val isRunning = state is CaptureState.Capturing || state is CaptureState.AwaitingPermission

            if (isRunning) {
                OutlinedButton(
                    onClick = onStopClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Stop Analysis")
                }
            } else {
                Button(
                    onClick = onStartClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start Analysis")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onSelectChartRegionClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Manual Chart Selection")
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onAiSettingsClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("AI Backend Settings")
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onJournalClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Prediction Journal")
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onReplayClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Replay / Backtest")
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Analysis/decision-support only. ChartLens AI never places trades " +
                    "or interacts with buttons on your screen.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun AnalysisCard(frame: AnalysisFrame?) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Chart Analysis", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(6.dp))

            when {
                frame == null ->
                    Text("Waiting for the first analyzed frame…")

                frame.chartRegion == null || !frame.chartRegion.isUsable() ->
                    Text(
                        "No chart detected automatically. Try Manual Chart Selection below.",
                        color = MaterialTheme.colorScheme.error
                    )

                else -> Column {
                    Text("Candles detected: ${frame.closedCandleCount} closed" +
                        if (frame.candles.any { it.isForming }) " + 1 forming" else "")
                    Text("Chart region confidence: ${(frame.chartRegion.confidence * 100).toInt()}%")
                    Text("Data quality: ${frame.dataQuality.qualityLabel()}")
                    val patternCount = frame.patternMatches.count { it.patterns.isNotEmpty() }
                    if (patternCount > 0) {
                        Text("Patterns flagged on $patternCount candle(s)")
                    }
                    if (frame.viewChanged) {
                        Text(
                            "⚠ Chart view shifted significantly since the last frame — caches " +
                                "were reset and predictions are being re-verified from scratch. " +
                                "If you scrolled/zoomed the chart, this is expected.",
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Price mapping", style = MaterialTheme.typography.labelMedium)
                    val mapping = frame.priceScaleMapping
                    if (mapping != null) {
                        val trusted = mapping.confidence >= 0.6f
                        Text(
                            "${(mapping.confidence * 100).toInt()}% confidence " +
                                "from ${mapping.sampleCount} OCR'd price labels" +
                                if (!trusted) " — too weak to trust, not used for analysis" else "",
                            color = if (trusted) Color.Unspecified else MaterialTheme.colorScheme.error
                        )
                    } else {
                        Text("Not yet mapped — waiting on price-axis OCR", color = MaterialTheme.colorScheme.error)
                    }

                    val timeframeResult = frame.timeframeResult
                    Text(
                        "Timeframe: " + (timeframeResult?.timeframe?.let { "${it.minutes}m" } ?: "Unknown")
                    )

                    frame.ocrDebug?.let { debug ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "OCR raw text (price axis, ${debug.priceAxisRawTexts.size} found" +
                                (debug.priceAxisCropSize?.let { ", crop ${it}px" } ?: "") + "): " +
                                if (debug.priceAxisRawTexts.isEmpty()) "none" else debug.priceAxisRawTexts.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall
                        )
                        debug.priceAxisError?.let {
                            Text("Price axis OCR error: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        Text(
                            "OCR raw text (time axis, ${debug.timeAxisRawTexts.size} found" +
                                (debug.timeAxisCropSize?.let { ", crop ${it}px" } ?: "") + "): " +
                                if (debug.timeAxisRawTexts.isEmpty()) "none" else debug.timeAxisRawTexts.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall
                        )
                        debug.timeAxisError?.let {
                            Text("Time axis OCR error: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }

                    frame.technicalAnalysis?.let { ta ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Technical analysis", style = MaterialTheme.typography.labelMedium)
                        Text("Trend: ${ta.trend.trend.name} (strength ${(ta.trend.trendStrength * 100).toInt()}%)")
                        Text("Momentum: ${ta.momentum.direction.name}")
                        ta.rsi14?.let { Text("RSI(14): ${"%.1f".format(it)}") }
                        ta.ema9?.let { ema9 -> ta.ema21?.let { ema21 ->
                            Text("EMA9/21: ${"%.5f".format(ema9)} / ${"%.5f".format(ema21)}")
                        } }
                        if (ta.chartStructureMatches.isNotEmpty()) {
                            Text(
                                "Chart structure: " + ta.chartStructureMatches.joinToString(", ") {
                                    "${it.pattern.name} (${(it.confidence * 100).toInt()}%)"
                                }
                            )
                        }
                    }

                    frame.prediction?.let { prediction ->
                        Spacer(modifier = Modifier.height(8.dp))
                        PredictionSection(prediction)
                    }
                }
            }
        }
    }
}

@Composable
private fun PredictionSection(prediction: PredictionResult) {
    Text("Prediction", style = MaterialTheme.typography.labelMedium)
    when (prediction.direction) {
        PredictionDirection.UP -> {
            Text("🟢 BULLISH", color = Color(0xFF26A69A))
            Text("Model Confidence: ${prediction.modelConfidence}/100 — a heuristic score, not a probability")
            prediction.setup?.let { Text("Setup: ${it.replace('_', ' ')}") }
        }
        PredictionDirection.DOWN -> {
            Text("🔴 BEARISH", color = Color(0xFFEF5350))
            Text("Model Confidence: ${prediction.modelConfidence}/100 — a heuristic score, not a probability")
            prediction.setup?.let { Text("Setup: ${it.replace('_', ' ')}") }
        }
        PredictionDirection.NO_TRADE -> {
            Text("⚠ NO CLEAR SETUP", color = Color(0xFFFFA726))
            if (prediction.noTradeReasons.isNotEmpty()) {
                Text(
                    "Why: " + prediction.noTradeReasons.joinToString(", ") { it.readableLabel() },
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
    if (prediction.evidence.any { it.applicable }) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            "Evidence considered: " + prediction.evidence.filter { it.applicable }.joinToString(", ") {
                "${it.name}=${"%.2f".format(it.score)}"
            },
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun NoTradeReason.readableLabel(): String = when (this) {
    NoTradeReason.INSUFFICIENT_DATA -> "not enough data yet"
    NoTradeReason.INSUFFICIENT_CANDLES -> "not enough closed candles yet"
    NoTradeReason.CONFLICTING_EVIDENCE -> "evidence conflicts"
    NoTradeReason.LOW_DIRECTIONAL_CONFIDENCE -> "no clear directional lean"
    NoTradeReason.UNKNOWN_TIMEFRAME -> "timeframe not confirmed"
    NoTradeReason.PRICE_NEAR_KEY_LEVEL -> "price sitting at a key level"
    NoTradeReason.ABNORMAL_VOLATILITY -> "volatility is elevated"
    NoTradeReason.DOJI_CHOP -> "last candle shows indecision"
}

@Composable
private fun AiInsightCard(insight: AiInsight) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "AI Reasoning", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(6.dp))

            when (insight) {
                is AiInsight.Idle ->
                    Text(
                        "No AI backend consulted yet — this only fires when a candle " +
                            "closes with a real BULLISH/BEARISH prediction. Configure a " +
                            "backend under AI Backend Settings to enable this.",
                        style = MaterialTheme.typography.bodySmall
                    )

                is AiInsight.Loading ->
                    Text("Consulting AI backend…", style = MaterialTheme.typography.bodySmall)

                is AiInsight.Error ->
                    Text(
                        "AI backend unavailable: ${insight.message}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )

                is AiInsight.Success -> {
                    val response = insight.response
                    val color = when (response.bias) {
                        "BULLISH" -> Color(0xFF26A69A)
                        "BEARISH" -> Color(0xFFEF5350)
                        else -> Color(0xFFFFA726)
                    }
                    Text("${response.bias} — confidence ${response.confidence}/100", color = color)
                    response.setup?.let { Text("Setup: ${it.replace('_', ' ')}") }
                    response.keyLevel?.let { Text("Key level: %.5f".format(it)) }
                    response.invalidationLevel?.let { Text("Invalidation: %.5f".format(it)) }
                    Spacer(modifier = Modifier.height(4.dp))
                    response.reasoning.forEach { line ->
                        Text("• $line", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

private fun DataQuality.qualityLabel(): String = when (this) {
    DataQuality.GOOD -> "Good"
    DataQuality.FAIR -> "Fair"
    DataQuality.POOR -> "Poor"
    DataQuality.INVALID -> "Invalid"
}

@Composable
private fun StatusCard(state: CaptureState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Status", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(6.dp))
            when (state) {
                is CaptureState.Idle ->
                    Text("Not analyzing. Tap Start Analysis to begin.")

                is CaptureState.AwaitingPermission ->
                    Text("Waiting for screen-capture permission…")

                is CaptureState.Capturing -> Column {
                    Text("Capturing — ${state.frameWidth}×${state.frameHeight}px")
                    Text("Frames analyzed: ${state.analyzedFrameCount} / ${state.capturedFrameCount} captured")
                    Text("Running for ${formatDuration(state.startedAtMillis)}")
                    Text("Last frame: ${formatTime(state.lastFrameAtMillis)}")
                }

                is CaptureState.Stopped ->
                    Text("Analysis stopped.")

                is CaptureState.Error -> Column {
                    Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
                    if (state.recoverable) {
                        Text(
                            "You can try Start Analysis again.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

private fun formatDuration(startedAtMillis: Long): String {
    val elapsedMs = (System.currentTimeMillis() - startedAtMillis).coerceAtLeast(0)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(elapsedMs)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(elapsedMs) % 60
    return if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"
}

private fun formatTime(millis: Long): String {
    if (millis <= 0) return "—"
    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return formatter.format(Date(millis))
}
