package com.chartlens.ai.ai

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface AiAnalysisApi {
    @POST("v1/analyze")
    suspend fun analyze(
        @Header("Authorization") authorization: String,
        @Body request: AiAnalysisRequest
    ): AiAnalysisResponse
}
