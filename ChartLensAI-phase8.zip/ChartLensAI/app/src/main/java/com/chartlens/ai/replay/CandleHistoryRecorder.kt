package com.chartlens.ai.replay

import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.NewCandleFinder
import com.chartlens.ai.candle.Candle
import com.chartlens.ai.database.CandleHistoryEntity
import com.chartlens.ai.database.CandleHistoryRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Appends one [CandleHistoryEntity] row per newly-closed candle during a live
 * session — this is the only source of data Phase 8's [ReplayEngine] ever
 * replays. Only records when [AnalysisFrame.priceCandles] actually has a
 * trusted-price entry; if price mapping was too weak to trust at that
 * moment, the candle is silently skipped, not fabricated — the same honesty
 * rule [com.chartlens.ai.journal.JournalCoordinator] follows for predictions.
 *
 * Compares the whole currently-visible window against the last recorded
 * candle ([NewCandleFinder]) rather than relying on a single frame-to-frame
 * close-event signal — a real device workflow surfaced why this matters:
 * when the trading platform's chart doesn't auto-follow live price, the user
 * has to periodically scroll to catch up, and several real candles can close
 * entirely off-screen in between scrolls. The original design (record only
 * the single candle tied to a close event) would have silently lost all but
 * the most recent of those the moment the view caught up. This backfills
 * every genuinely-missing candle at once instead.
 */
@Singleton
class CandleHistoryRecorder @Inject constructor(
    private val repository: CandleHistoryRepository
) {
    private var lastRecordedClose: Double? = null
    private var sessionId: Long? = null

    suspend fun onNewFrame(frame: AnalysisFrame) {
        val currentSessionId = sessionId ?: return
        if (frame.priceCandles.isEmpty()) return

        val newCandles = NewCandleFinder.findNewSuffix(lastRecordedClose, frame.priceCandles)
        if (newCandles.isEmpty()) return

        for (priceCandle in newCandles) {
            val pixelCandle: Candle = frame.candles.find { it.index == priceCandle.index } ?: continue
            repository.record(
                CandleHistoryEntity(
                    sessionId = currentSessionId,
                    candleIndex = priceCandle.index,
                    timestampMillis = frame.timestampMillis,
                    open = priceCandle.open,
                    high = priceCandle.high,
                    low = priceCandle.low,
                    close = priceCandle.close,
                    direction = pixelCandle.direction.name,
                    upperWickPx = (pixelCandle.bodyTopY - pixelCandle.wickTopY).coerceAtLeast(0),
                    lowerWickPx = (pixelCandle.wickBottomY - pixelCandle.bodyBottomY).coerceAtLeast(0),
                    patterns = frame.patternMatches
                        .find { it.candleIndex == priceCandle.index }
                        ?.patterns
                        ?.joinToString(",") { it.name }
                        .orEmpty(),
                    timeframeLabel = frame.timeframeResult?.timeframe?.let { "${it.minutes}m" },
                    instrument = "Unknown" // see AiRequestMapper's doc comment — no instrument OCR yet
                )
            )
        }
        lastRecordedClose = newCandles.last().close
    }

    /** Call at the start of every new capture session — both to start a fresh session
     * grouping and so a stale price from a previous session can't suppress a real
     * recording in this one. */
    fun startSession(sessionId: Long) {
        this.sessionId = sessionId
        this.lastRecordedClose = null
    }
}
