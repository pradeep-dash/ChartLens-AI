package com.chartlens.ai.replay

import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.database.CandleHistoryEntity
import com.chartlens.ai.database.CandleHistoryRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Appends one [CandleHistoryEntity] row per newly-closed candle during a live
 * session — this is the only source of data Phase 8's [ReplayEngine] ever
 * replays. Only records when [AnalysisFrame.priceCandles] actually has a
 * trusted-price entry matching the closed candle's index; if price mapping
 * was too weak to trust at that moment, the candle is silently skipped, not
 * fabricated. This is the same honesty rule
 * [com.chartlens.ai.journal.JournalCoordinator] follows for prediction
 * entries, applied here to raw historical data instead.
 */
@Singleton
class CandleHistoryRecorder @Inject constructor(
    private val repository: CandleHistoryRepository
) {
    private var lastRecordedCandleIndex: Int? = null
    private var sessionId: Long? = null

    suspend fun onNewFrame(frame: AnalysisFrame) {
        val closeEvent = frame.candleCloseEvent ?: return
        val closedCandle = closeEvent.closedCandle
        if (closedCandle.index == lastRecordedCandleIndex) return

        val priceCandle = frame.priceCandles.find { it.index == closedCandle.index } ?: return
        val currentSessionId = sessionId ?: return

        lastRecordedCandleIndex = closedCandle.index

        repository.record(
            CandleHistoryEntity(
                sessionId = currentSessionId,
                candleIndex = closedCandle.index,
                timestampMillis = frame.timestampMillis,
                open = priceCandle.open,
                high = priceCandle.high,
                low = priceCandle.low,
                close = priceCandle.close,
                direction = closedCandle.direction.name,
                upperWickPx = (closedCandle.bodyTopY - closedCandle.wickTopY).coerceAtLeast(0),
                lowerWickPx = (closedCandle.wickBottomY - closedCandle.bodyBottomY).coerceAtLeast(0),
                patterns = frame.patternMatches
                    .find { it.candleIndex == closedCandle.index }
                    ?.patterns
                    ?.joinToString(",") { it.name }
                    .orEmpty(),
                timeframeLabel = frame.timeframeResult?.timeframe?.let { "${it.minutes}m" },
                instrument = "Unknown" // see AiRequestMapper's doc comment — no instrument OCR yet
            )
        )
    }

    /** Call at the start of every new capture session — both to start a fresh session
     * grouping and so a stale candle index from a previous session can't suppress a
     * real recording in this one. */
    fun startSession(sessionId: Long) {
        this.sessionId = sessionId
        this.lastRecordedCandleIndex = null
    }
}
