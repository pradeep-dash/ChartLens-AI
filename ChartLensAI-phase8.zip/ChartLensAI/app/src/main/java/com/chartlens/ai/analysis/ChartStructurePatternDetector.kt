package com.chartlens.ai.analysis

import kotlin.math.abs

/**
 * Broader, multi-candle structural patterns — distinct from
 * [com.chartlens.ai.candle.CandlePattern], which covers single-candle
 * patterns (doji, hammer, engulfing) detected from one candle's geometry.
 * These are detected from the swing-high/swing-low sequence
 * [TrendAnalyzer] already computes — no new screen-capture capability
 * needed, since this only needs price data the pipeline already has.
 */
enum class ChartStructurePattern {
    DOUBLE_TOP,
    DOUBLE_BOTTOM,
    HEAD_AND_SHOULDERS,
    INVERSE_HEAD_AND_SHOULDERS,
    ASCENDING_TRIANGLE,
    DESCENDING_TRIANGLE,
    SYMMETRICAL_TRIANGLE
}

data class ChartStructureMatch(val pattern: ChartStructurePattern, val confidence: Float)

/**
 * Detects [ChartStructurePattern]s from a trend's swing-high/swing-low
 * sequence. Double-top/bottom and head-and-shoulders confidence scales with
 * how closely the peaks/troughs actually match (a real magnitude, not a
 * fixed guess) — triangle detection is inherently weaker (a 2-3 point line
 * fit has little statistical weight) and uses a fixed, deliberately modest
 * confidence rather than a fabricated precise-looking number.
 */
class ChartStructurePatternDetector(
    private val peakToleranceFraction: Double = 0.003,
    private val minValleyDepthFraction: Double = 0.004,
    private val minSeparationCandles: Int = 3,
    private val shoulderToleranceFraction: Double = 0.006,
    private val minHeadProminenceFraction: Double = 0.004,
    private val necklineToleranceFraction: Double = 0.006,
    private val flatSlopeFractionThreshold: Double = 0.0008,
    private val triangleConfidence: Float = 0.5f
) {

    fun detect(swingHighs: List<SwingPoint>, swingLows: List<SwingPoint>): List<ChartStructureMatch> {
        val matches = mutableListOf<ChartStructureMatch>()
        detectDoubleTop(swingHighs, swingLows)?.let { matches += it }
        detectDoubleBottom(swingLows, swingHighs)?.let { matches += it }
        detectHeadAndShoulders(swingHighs, swingLows)?.let { matches += it }
        detectInverseHeadAndShoulders(swingLows, swingHighs)?.let { matches += it }
        detectTriangle(swingHighs, swingLows)?.let { matches += it }
        return matches
    }

    private fun detectDoubleTop(swingHighs: List<SwingPoint>, swingLows: List<SwingPoint>): ChartStructureMatch? {
        if (swingHighs.size < 2) return null
        val first = swingHighs[swingHighs.size - 2]
        val second = swingHighs.last()
        if (second.index - first.index < minSeparationCandles) return null

        val avgPeak = (first.price + second.price) / 2.0
        if (avgPeak <= 0) return null
        val peakRelDiff = abs(first.price - second.price) / avgPeak
        if (peakRelDiff > peakToleranceFraction) return null

        val valley = swingLows.filter { it.index in (first.index + 1) until second.index }.minByOrNull { it.price }
            ?: return null
        val valleyDepth = (avgPeak - valley.price) / avgPeak
        if (valleyDepth < minValleyDepthFraction) return null

        val confidence = (1.0 - peakRelDiff / peakToleranceFraction).toFloat().coerceIn(0f, 1f)
        return ChartStructureMatch(ChartStructurePattern.DOUBLE_TOP, confidence)
    }

    private fun detectDoubleBottom(swingLows: List<SwingPoint>, swingHighs: List<SwingPoint>): ChartStructureMatch? {
        if (swingLows.size < 2) return null
        val first = swingLows[swingLows.size - 2]
        val second = swingLows.last()
        if (second.index - first.index < minSeparationCandles) return null

        val avgTrough = (first.price + second.price) / 2.0
        if (avgTrough <= 0) return null
        val troughRelDiff = abs(first.price - second.price) / avgTrough
        if (troughRelDiff > peakToleranceFraction) return null

        val peak = swingHighs.filter { it.index in (first.index + 1) until second.index }.maxByOrNull { it.price }
            ?: return null
        val peakHeight = (peak.price - avgTrough) / avgTrough
        if (peakHeight < minValleyDepthFraction) return null

        val confidence = (1.0 - troughRelDiff / peakToleranceFraction).toFloat().coerceIn(0f, 1f)
        return ChartStructureMatch(ChartStructurePattern.DOUBLE_BOTTOM, confidence)
    }

    private fun detectHeadAndShoulders(swingHighs: List<SwingPoint>, swingLows: List<SwingPoint>): ChartStructureMatch? {
        if (swingHighs.size < 3) return null
        val n = swingHighs.size
        val leftShoulder = swingHighs[n - 3]
        val head = swingHighs[n - 2]
        val rightShoulder = swingHighs[n - 1]

        if (head.price <= leftShoulder.price || head.price <= rightShoulder.price) return null

        val shoulderAvg = (leftShoulder.price + rightShoulder.price) / 2.0
        if (shoulderAvg <= 0) return null
        val shoulderRelDiff = abs(leftShoulder.price - rightShoulder.price) / shoulderAvg
        if (shoulderRelDiff > shoulderToleranceFraction) return null

        val headProminence = (head.price - shoulderAvg) / shoulderAvg
        if (headProminence < minHeadProminenceFraction) return null

        val leftNeck = swingLows.filter { it.index in (leftShoulder.index + 1) until head.index }.minByOrNull { it.price }
            ?: return null
        val rightNeck = swingLows.filter { it.index in (head.index + 1) until rightShoulder.index }.minByOrNull { it.price }
            ?: return null
        val necklineAvg = (leftNeck.price + rightNeck.price) / 2.0
        if (necklineAvg <= 0) return null
        val necklineRelDiff = abs(leftNeck.price - rightNeck.price) / necklineAvg
        if (necklineRelDiff > necklineToleranceFraction) return null

        val confidence = (1.0 - shoulderRelDiff / shoulderToleranceFraction).toFloat().coerceIn(0f, 1f)
        return ChartStructureMatch(ChartStructurePattern.HEAD_AND_SHOULDERS, confidence)
    }

    private fun detectInverseHeadAndShoulders(swingLows: List<SwingPoint>, swingHighs: List<SwingPoint>): ChartStructureMatch? {
        if (swingLows.size < 3) return null
        val n = swingLows.size
        val leftShoulder = swingLows[n - 3]
        val head = swingLows[n - 2]
        val rightShoulder = swingLows[n - 1]

        if (head.price >= leftShoulder.price || head.price >= rightShoulder.price) return null

        val shoulderAvg = (leftShoulder.price + rightShoulder.price) / 2.0
        if (shoulderAvg <= 0) return null
        val shoulderRelDiff = abs(leftShoulder.price - rightShoulder.price) / shoulderAvg
        if (shoulderRelDiff > shoulderToleranceFraction) return null

        val headProminence = (shoulderAvg - head.price) / shoulderAvg
        if (headProminence < minHeadProminenceFraction) return null

        val leftNeck = swingHighs.filter { it.index in (leftShoulder.index + 1) until head.index }.maxByOrNull { it.price }
            ?: return null
        val rightNeck = swingHighs.filter { it.index in (head.index + 1) until rightShoulder.index }.maxByOrNull { it.price }
            ?: return null
        val necklineAvg = (leftNeck.price + rightNeck.price) / 2.0
        if (necklineAvg <= 0) return null
        val necklineRelDiff = abs(leftNeck.price - rightNeck.price) / necklineAvg
        if (necklineRelDiff > necklineToleranceFraction) return null

        val confidence = (1.0 - shoulderRelDiff / shoulderToleranceFraction).toFloat().coerceIn(0f, 1f)
        return ChartStructureMatch(ChartStructurePattern.INVERSE_HEAD_AND_SHOULDERS, confidence)
    }

    /** Triangle detection is deliberately the weakest signal here — a 2-3 point line
     * fit has very little statistical backing — hence the fixed, modest [triangleConfidence]
     * rather than a precise-looking computed number that would overstate how much this
     * small a sample actually supports. */
    private fun detectTriangle(swingHighs: List<SwingPoint>, swingLows: List<SwingPoint>): ChartStructureMatch? {
        if (swingHighs.size < 2 || swingLows.size < 2) return null
        val highSlope = slopeFraction(swingHighs.takeLast(3)) ?: return null
        val lowSlope = slopeFraction(swingLows.takeLast(3)) ?: return null

        val highFlat = abs(highSlope) < flatSlopeFractionThreshold
        val lowFlat = abs(lowSlope) < flatSlopeFractionThreshold
        val highFalling = highSlope < -flatSlopeFractionThreshold
        val lowRising = lowSlope > flatSlopeFractionThreshold

        val pattern = when {
            highFlat && lowRising -> ChartStructurePattern.ASCENDING_TRIANGLE
            highFalling && lowFlat -> ChartStructurePattern.DESCENDING_TRIANGLE
            highFalling && lowRising -> ChartStructurePattern.SYMMETRICAL_TRIANGLE
            else -> return null
        }
        return ChartStructureMatch(pattern, triangleConfidence)
    }

    /** Simple least-squares slope, expressed as a fraction of the average price so it's
     * comparable across instruments at very different price scales. Null if the points
     * don't span more than one index (can't define a slope) or average price is zero. */
    private fun slopeFraction(points: List<SwingPoint>): Double? {
        if (points.size < 2) return null
        val n = points.size
        val meanX = points.sumOf { it.index.toDouble() } / n
        val meanY = points.sumOf { it.price } / n
        if (meanY == 0.0) return null
        val ssXX = points.sumOf { (it.index - meanX) * (it.index - meanX) }
        val ssXY = points.sumOf { (it.index - meanX) * (it.price - meanY) }
        if (ssXX == 0.0) return null
        return (ssXY / ssXX) / meanY
    }
}
