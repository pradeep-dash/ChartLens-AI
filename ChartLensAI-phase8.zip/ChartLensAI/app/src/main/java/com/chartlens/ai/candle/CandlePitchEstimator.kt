package com.chartlens.ai.candle

/**
 * Estimates the horizontal pitch (start-to-start distance) between candles.
 *
 * Why this exists: `clusterIntoBars` segments by colour boundaries, which fails
 * badly whenever adjacent candles share a colour and touch — dozens of real
 * candles collapse into a handful of bars (a real device test showed 7 bars on
 * a chart with ~40 candles). `splitMergedRuns` was written to compensate, and
 * made things worse in the opposite direction: with only 7 bars to estimate
 * from, it fabricated 138 candles out of 7 real ones on the same chart.
 *
 * Pitch is a far stronger signal than colour boundaries, because candlestick
 * charts render candles at a FIXED repeating interval. Even when many bars are
 * merged, the un-merged ones reveal that interval directly: the distance from
 * one bar's start to the next bar's start reveals the pitch — merged runs
 * simply contribute larger multiples, which a low percentile ignores as long as
 * enough genuine single steps survive.
 */
object CandlePitchEstimator {

    const val MIN_PLAUSIBLE_PITCH_PX = 3

    /**
     * @return estimated pitch in px, or null when there isn't enough evidence to
     *   estimate one confidently — in which case the caller must NOT guess, since
     *   fabricating candles from a bad pitch is exactly the failure this replaces.
     */
    fun estimate(barStarts: List<Int>, barWidths: List<Int>): Int? {
        if (barStarts.size < 2) {
            // A single merged run tells us nothing about spacing between candles.
            // Return nothing rather than inventing a pitch.
            return null
        }

        val deltas = barStarts.sorted().zipWithNext { a, b -> b - a }.filter { it > 0 }
        if (deltas.isEmpty()) return null

        // The smallest deltas are the most likely to be genuine single-candle steps:
        // a merged run contributes a delta that's a multiple of the true pitch, never
        // smaller than it. Taking a low percentile (not the median) keeps the estimate
        // anchored to real single steps even when most runs are merged.
        val sorted = deltas.sorted()
        val candidatePitch = sorted[(sorted.size - 1) / 4]
        if (candidatePitch < MIN_PLAUSIBLE_PITCH_PX) return null

        // Sanity check against body width: pitch must be at least as wide as a typical
        // candle body, since candles cannot overlap. A typical width exceeding the
        // estimated pitch means the estimate is too small and would over-split.
        val sortedWidths = barWidths.sorted()
        val typicalWidth = if (sortedWidths.isEmpty()) 0 else sortedWidths[(sortedWidths.size - 1) / 4]
        if (typicalWidth > candidatePitch) return null

        return candidatePitch
    }
}
