plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.chartlens.ai"
    compileSdk = 35

    signingConfigs {
        // A fixed, checked-in debug keystore — see keystore/README.md for why this
        // exists. Without it, every CI build (a fresh GitHub Actions runner has no
        // pre-existing ~/.android/debug.keystore) gets signed with a different,
        // randomly-generated debug certificate, and Android refuses to install an
        // update over an app signed with a different key — forcing an uninstall before
        // every single reinstall. This is a completely standard, safe practice: a debug
        // keystore is not a secret the way a release signing key is, and committing one
        // is exactly what fixes this class of problem.
        getByName("debug") {
            storeFile = file("${rootDir}/keystore/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    defaultConfig {
        applicationId = "com.chartlens.ai"
        // MediaProjection + WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY require API 26+.
        // MediaProjection foreground service type (FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        // requires API 29+ to declare correctly, so we set minSdk there to avoid a service
        // that silently fails to actually capture on modern Android versions.
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-mvp"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.service)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.savedstate.ktx)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons.extended)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.core)

    implementation(libs.retrofit.core)
    implementation(libs.retrofit.kotlinx.serialization)
    implementation(libs.okhttp.core)
    implementation(libs.okhttp.logging)

    implementation(libs.mlkit.text.recognition)
    // OpenCV is not used until Phase 2 (chart/candle detection). Left commented out so
    // Phase 1 builds cleanly without needing the OpenCV Maven repo or a vendored SDK
    // module configured — see README section 4.2 before uncommenting.
    // implementation(libs.opencv)

    testImplementation(libs.junit)
    testImplementation(libs.mockk)
    testImplementation(libs.turbine)
    testImplementation(libs.kotlinx.coroutines.test)
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
