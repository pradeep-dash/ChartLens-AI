# ChartLens AI — Phases 1-8

Analysis/decision-support only. This app never places trades, clicks buttons, or
interacts with any trading platform — it only reads the screen and displays
information.

This milestone covers **Phases 1-8 of 9**. Not yet present: performance and
accessibility polish (Phase 9).

---

## 1. What was implemented, phase by phase

### Phase 1 — Foundation
Full MediaProjection capture pipeline (`ScreenCaptureService`,
`ScreenCaptureController`), a draggable/collapsible floating overlay
(`OverlayService`), and the full permission sequence (notifications → overlay
→ MediaProjection consent). Verified working on-device early on.

### Phase 2 — Vision (chart/candle detection)
`ChartDetector` (automatic chart-region detection via candle-color density,
no hardcoded coordinates), `CandleDetector` (column clustering + row-coverage
body/wick separation), `CandlePatternDetector` (doji, engulfing, hammer,
etc. — geometry-scored, not name-matched), and a manual chart-selection
fallback (`ChartRegionSelectionScreen`). Pure Kotlin/Android pixel
processing, not OpenCV — a deliberate call made early on given how much
friction OpenCV's Maven setup risked adding for capability not needed at
this scale.

### Phase 3 — OCR, price mapping, timeframe, candle-close detection
`OcrEngine` (ML Kit, fully on-device), `PriceScaleMapper` (least-squares
regression from OCR'd price labels to real prices, with X-position
clustering and iterative outlier removal), `TimeframeDetector`,
`CandleCloseTracker`. This phase went through the most real-device iteration
of any — see section 2 below for the full account, because the failure
patterns and fixes here are worth understanding, not just the end state.

### Phase 4 — Technical Analysis Engine
`EMA`/`RSI`/`MACD`/`ATR`/`BollingerBands`, `TrendAnalyzer` (swing-structure
based), `MomentumAnalyzer`, `SupportResistanceAnalyzer` (breakout/rejection
detection). Fully pure Kotlin, fully unit tested against hand-calculated
values. Built before Phase 3's OCR existed, deliberately decoupled from
Phase 2's pixel-based `Candle` model (a separate `PriceCandle` model) so it
could be built and verified without waiting on real price data.

### Phase 5 — Prediction Engine
`PredictionEngine` combines every evidence source above (trend, momentum,
EMA alignment, RSI, MACD, support/resistance, candle patterns, recent candle
sequence) into a weighted directional score. NO_TRADE is a first-class,
actively-sought output — insufficient data/candles, conflicting evidence,
low confidence, an unknown timeframe, a doji/chop candle, price sitting at
an unbroken level, and elevated volatility are each independent hard gates;
any one firing forces NO_TRADE regardless of how strong the rest of the
evidence looks. `modelConfidence` is displayed everywhere as "NN/100," never
a percentage chance, per the spec's explicit requirement. Confirmed working
end-to-end on a real device after Phase 3's fixes landed — see section 2.

### Phase 6 — AI Reasoning Layer
- **Android client, fully wired and testable**: `AiAnalysisRequest`/
  `AiAnalysisResponse` (kotlinx.serialization DTOs), `AiRequestMapper` (pure,
  reshapes already-computed local data into the request — never derives new
  information), `AiTriggerPolicy` (pure — only fires on a fresh candle close
  with a real non-NO_TRADE prediction, per the spec's "prefer deterministic
  local analysis over unnecessary AI calls"), `AiResponseValidator` (pure —
  rejects malformed shapes, out-of-range confidence, and critically,
  fabricated price levels not close to anything the request actually
  supplied), `RemoteAiAnalysisProvider` (Retrofit/OkHttp, builds its client
  dynamically from a user-configured URL — there is no baked-in default
  backend), `AiInsightCoordinator` (fires the async call without ever
  blocking the fast local frame pipeline on network I/O), full Settings UI
  for entering the backend URL and auth token.
- **A real, complete reference backend** (`/backend`): Node/Express,
  bearer-token auth, in-memory rate limiting, request AND response
  validation server-side (defense in depth alongside the client's own
  validation), a prompt that encodes the spec's exact behavioral rules
  (never invent indicators or price levels, never claim certainty, prefer
  NO_CLEAR_SETUP over a fabricated call), and a full deployment guide for
  free-tier hosts (Render/Railway/Fly.io).

**A real constraint worth being direct about**: this sandbox has no
persistent hosting and no network access, so the backend is genuinely
unrunnable here — it's real, carefully-written source code, reviewed by
hand, but literally never executed. This is the same "unverified until a
real environment exercises it" caveat that's applied to every
Bitmap/ML-Kit/network boundary class throughout this project, just at a
larger scale (an entire server, not one class). There's also a first-use
risk worth flagging: `retrofit2-kotlinx-serialization-converter` has sat as
a declared-but-unused dependency since Phase 1's initial setup — this is the
first code that actually exercises it, so a version/API mismatch here is a
real possibility that earlier phases' testing couldn't have caught.

### Phase 7 — Prediction Journal & Accuracy Analytics (NEW)
- **Room database** (`PredictionEntity`, `PredictionDao`, `ChartLensDatabase`):
  every real (non-NO_TRADE) local prediction gets journaled automatically —
  independent of whether Phase 6's AI backend is even configured, since
  Phase 5's local prediction is what's actually being scored. Per the spec's
  "do not modify historical predictions after evaluation except to record
  their actual outcome" — the DAO's `recordOutcome` query updates only the
  three outcome-related columns; there is no update method that touches
  anything else.
- **`OutcomeEvaluator`** (pure, tested): compares the price at prediction
  time against the price once the prediction's horizon is actually reached —
  never evaluated early. A small neutral-zone threshold (0.02%) keeps
  noise-level moves from counting as a real win or loss.
- **`JournalCoordinator`**: wires recording and evaluation into the live
  pipeline. Evaluation is index-based (which candle number to check), not
  wall-clock based, since real candle timestamps still don't exist. If a
  target candle never reappears within a generous buffer after its horizon
  (most likely scrolled out of the visible/cropped chart region), it's
  marked INVALID_DATA rather than left pending forever — a disclosed
  limitation of index-based tracking, not silently ignored.
- **`AccuracyAnalytics`** (pure, tested): total/win/loss/neutral/invalid
  counts, overall accuracy (computed only from decisive WIN/LOSS outcomes —
  neutral and invalid entries don't dilute or inflate it), breakdowns by
  instrument/timeframe/confidence-bucket/setup, current streak, and max
  win/loss streaks. Sorts chronologically internally, so callers never need
  to worry about the DAO's own ordering convention.
- **The mandatory "don't claim an edge" gate**: `hasEnoughDataForEdgeClaim`
  requires at least 30 decisive predictions (a documented judgment call, not
  a statistically derived number) before the Journal screen will display
  accuracy as a real statistic — below that, it shows raw counts with an
  explicit "not enough data yet" message instead.
- A full Journal screen (`JournalScreen`) showing the accuracy summary and
  recent predictions with color-coded outcomes.

### Phase 8 — Replay / Backtest Mode (NEW)
- **`CandleHistoryRecorder`**: persists one real closed candle per candle
  close during live sessions (`CandleHistoryEntity`, a new Room table) — this
  is the only source of data replay ever uses. Follows the same honesty rule
  as Phase 7's journal: a candle only gets recorded when price mapping was
  actually trusted at that moment; if not, it's silently skipped rather than
  fabricated, which means recorded history can have real gaps.
- **`ReplayEngine`** — the core of this phase, and the direct, structural
  implementation of the spec's "prevent look-ahead bias" requirement, not
  just a design intention. At step `i`, the technical analysis engine only
  ever receives `history.subList(0, i + 1)` — there is no code path that can
  hand it a later index. Reuses `TechnicalAnalysisEngine` and
  `PredictionEngine` directly (the exact same code a live session runs, not
  a reimplementation that could drift), and reuses `AccuracyAnalytics` for
  the summary by building ordinary `PredictionEntity` rows in memory —
  these are never written to the real database, so a backtest run can never
  pollute Phase 7's live accuracy numbers.
- **The centerpiece test, `ReplayEngineTest`**: replays two candle histories
  that are byte-for-byte identical up to a point and diverge sharply after
  it (one keeps rising, one crashes), then asserts every prediction made at
  or before that point is identical between the two runs. This doesn't just
  check that replay "runs" — it empirically proves a later candle can never
  influence an earlier step's prediction.
- A Replay screen listing recorded sessions (built only from real history,
  no synthetic/sample dataset to demo it with) and showing full results —
  every step, its outcome, and the same accuracy summary Journal uses.

**Worth being honest about**: the look-ahead-bias test's price data is
synthetic (a gently oscillating uptrend, deliberately not a perfectly
monotonic line — a straight-line rise would push RSI to ~100 from never
having a single down candle, which could trigger `PredictionEngine`'s
conflicting-evidence gate on every single step and make the test pass
vacuously with zero real predictions to compare). I reasoned through why
this pattern should produce at least one real prediction within the shared
prefix, and structured it with 21 independent candidate steps to make that
likely — but I can't execute this test here, so "should reliably produce a
real prediction" is a reasoned expectation, not a confirmed fact. If it
turns out to fail by producing zero comparable steps, that's a test-data
tuning problem, not evidence the look-ahead-bias prevention itself is
broken — the structural guarantee (`subList(0, i + 1)`) holds regardless of
what the test data does.

### Post-Phase-8 fix — undisclosed prediction jumps from chart scroll/pan
A real device test showed the prediction flipping between "no clear setup"
and a real directional call within 15 seconds, with the visible time-axis
window having shifted ~16 minutes between the two frames — almost certainly
a manual chart scroll, not natural candle progression. This wasn't actually
wrong analysis (the pipeline only ever reads whatever's currently on screen
by design, with no persistent memory of "true" history beyond that) — but
two real problems sat underneath the confusing symptom: nothing disclosed
that a shift had happened, so a legitimate re-analysis of genuinely
different data looked like arbitrary instability; and the region/OCR
caches (good for 20-30 frames on a stable chart) could keep serving a now-
mismatched stale crop for several frames after a shift, before naturally
refreshing.

Fixed with `ViewShiftDetector`: compares the visible candles' vertical
pixel extent frame to frame, and when overlap drops below 30% (a real pan/
zoom, not gradual progression), forces an immediate region/OCR cache
invalidation and a `CandleCloseTracker` reset instead of waiting out the
normal cache interval, and surfaces "⚠ Chart view shifted" in the Dashboard
debug view so a sudden jump is explained rather than mysterious. This is
explicitly a heuristic, not a perfect signal — the pipeline has no real
per-candle timestamps or persistent candle identity to compare against
instead, which would be the more precise fix but is a materially bigger
undertaking. A genuine, very sharp price spike could in principle also trip
it; an accepted false-positive rate, since the cost of an unnecessary
re-verification is small next to the cost of silently trusting a stale
cache after a real shift.

### Post-Phase-8 fix — live analysis was silently bounded by the screen's current width
A user question surfaced a real architectural gap: `CandleHistoryRecorder`
was already building a growing, persistent record of every real candle as
it closed (used for Phase 8's replay), but the **live** prediction engine
never read it — every frame recomputed trend/RSI/EMA/momentum from only
whatever was currently visible on screen. If more candles fit in history
than fit on screen at once, the rest effectively didn't exist to live
analysis; scrolling or a narrower view could make indicators "forget"
things that had already happened, even though they were being recorded
correctly the whole time.

Fixed with `CandleHistoryMerger`: the live pipeline now optionally reads
the full recorded session history (via a `sessionHistoryProvider` passed
into `FrameAnalyzer`, null and fully backward-compatible in every existing
unit test) and merges it with the current frame's own candles before
feeding `TechnicalAnalysisEngine` — recorded history is authoritative for
everything except the newest candle, which gets appended only if it isn't
already represented (matched by closing price, not a stable ID, since
neither the recorded history's nor the current frame's candle `index` is a
reliable cross-frame identifier — both are positional, assigned fresh from
whatever's currently visible). This was scoped deliberately narrowly:
`AnalysisFrame.priceCandles` and everything that matches against it by
this-frame index (`lastCandleContext`, `JournalCoordinator`,
`AiRequestMapper`) is completely untouched — only what feeds the technical-
analysis engine itself was widened, to avoid risking the correctness of
already-working index-matching logic elsewhere in the pipeline.

### Post-Phase-8 fix #2 — missed candles when the chart doesn't auto-follow price
Immediate follow-up from the same conversation: it turned out scrolling
wasn't optional for this user — their trading platform's chart doesn't
auto-advance to keep the latest price in view, so periodically scrolling
right to catch up is a required part of the workflow, not an avoidable
habit. That exposed a real gap in `CandleHistoryRecorder`'s original
design: it only recorded a candle when `CandleCloseTracker` fired a single
frame-to-frame close-event signal. If several real candles closed entirely
off-screen while the chart sat still, then a catch-up scroll suddenly
revealed all of them at once, only the single most recent would ever have
been recorded — the rest silently lost, with no trace they'd ever existed.

Fixed with `NewCandleFinder`: instead of relying on a single close-event
signal, `CandleHistoryRecorder` now compares the *whole* currently-visible
window against the last recorded candle's closing price every frame, and
backfills every genuinely-new candle it finds — one at a time during normal
progression, or several at once after a catch-up scroll. Same disclosed
price-matching limitation as `CandleHistoryMerger` (no stable candle
identity to match on instead), with the same reasonable fallback: if the
last-recorded price isn't found anywhere in the current view at all (it
scrolled off entirely), the whole visible window is treated as new —
occasionally risking a re-recorded candle, preferred over silently
recording nothing for that frame.

**Still an open, disclosed limitation**: none of this can recover a candle
that closed off-screen and then scrolled *back* off-screen again before the
next analyzed frame — this only backfills what's actually visible at the
moment of analysis. If the chart genuinely never shows a stretch of price
action at all, that stretch is unrecoverable, the same honest ceiling as
"this app only ever knows what it can currently see" that's applied
everywhere else in this project. The best real fix is checking whether the
trading platform has its own "resume live" / follow-price control, which
this app has no ability to invoke itself (it never interacts with the
page, only reads it).

### Post-Phase-8 addition — broader chart structure patterns
A direct feature request, evaluated honestly against a competitor's claimed
capability list rather than built blindly: of five gaps identified (VWAP,
volume behavior, broader chart patterns, Level 2 pressure, existing
position status), only one was genuinely buildable and testable —
**Level 2 and volume/VWAP were declined**, not built as non-functional
placeholders. No screenshot across this entire project has ever shown a
volume histogram or VWAP line on QX Broker's charts, and VWAP is
literally volume-weighted, so it shares the same blocker; writing
detection code for a UI element that may not exist on this platform would
be untestable, unverifiable code. No Level 2/order-book panel has ever
appeared either — QX Broker is a binary-options OTC platform, which
plausibly doesn't expose this kind of data at all. Existing position
status was set aside as a different category of feature (account
monitoring, not chart analysis) rather than declined outright.

**Built: `ChartStructurePatternDetector`** — Double Top, Double Bottom,
Head & Shoulders, Inverse Head & Shoulders, and three triangle types
(ascending/descending/symmetrical), detected from the same swing-high/
swing-low sequence `TrendAnalyzer` already computes — no new capture
capability needed, since this only needs price data already in hand.
Double-top/bottom and head-and-shoulders confidence scales with how
closely the peaks/troughs actually match (a real computed magnitude);
triangle detection uses a fixed, deliberately modest confidence instead,
since a 2-3 point line fit has very little real statistical weight and a
precise-looking computed number there would overstate what the data
actually supports.

Wired in as a 9th weighted evidence source in `PredictionEngine`,
deliberately designed to be fully backward-compatible: when no pattern is
detected (`chartStructureMatches` defaults to an empty list), the evidence
signal reports itself inapplicable and contributes exactly nothing to the
weighted score — the same rule every other evidence source already
follows. This was verified directly: the existing hand-computed baseline
tests (`PredictionEngineTest`'s clean bullish/bearish fixtures) don't set
this field at all, so their expected confidence values are provably
unaffected by this addition. A symmetrical triangle scores exactly 0
regardless of its own confidence — its breakout direction is genuinely
unknown until it actually breaks, so it registers as "worth noting" without
pushing the prediction either direction.



Phase 3 needed far more device iteration than any other phase, and the
sequence of what broke and how it got fixed is worth keeping as a reference
for future debugging, not just historical trivia:

1. **Crop landed in blank space.** The price-axis crop was anchored to
   `region.right` + a small fixed width, assuming labels sit close to the
   last candle. Real charts often reserve blank space before the axis —
   the crop missed the labels entirely, finding nothing.
2. **A wide-layout crop grabbed the wrong content.** Anchoring to the
   screen's right edge instead (fix for #1) broke on a landscape layout with
   a persistent sidebar — it read "Withdrawal," trade amounts, instead of
   the price axis.
3. **A too-narrow crop truncated labels.** Widening the crop (fix for #2)
   used a floor just above ML Kit's 32px minimum — enough to stop a crash,
   not enough to capture full label text. "92.700" truncated to "700," and
   because the fragments were still evenly spaced, the fit was confidently
   wrong (87% confidence on garbage) rather than obviously failed.
3b. **Bare integers accepted as prices.** Fixed by requiring a decimal point
   in `PriceTextParser` — a truncated fragment like "700" no longer parses
   as a price at all.
4. **Comma-grouped UI figures leaked through.** A thousands-separator
   parsing path (added for a hypothetical "1,234.56"-style price) was exempt
   from the decimal requirement above. "19,400" (a payout amount) parsed
   clean, wasn't excluded by X-position clustering on that layout, and
   produced EMA values in the thousands on a sub-1.0 price chart. Comma
   support was removed entirely — every real price label observed across
   this whole project has used a plain period, every comma-containing
   candidate has been a false positive.
5. **`ChartDetector`'s vertical bounds extended past the real chart.** Not
   an OCR bug at all — the region's bottom edge was computed as an absolute
   min/max across every column touching a candle-colored pixel anywhere,
   with no contiguity check. The Up/Down trade buttons share the same
   bullish/bearish color family as candles; a few columns touching them
   dragged `region.bottom` deep into the trading-panel UI, starving the
   time-axis crop of anything real to find below it. Fixed by applying the
   same gap-tolerant clustering the horizontal pass already used, to rows.
6. **A countdown timer parsed as a clock time.** Once #5 was fixed and real
   time labels started appearing, timeframe detection *still* failed — the
   1-minute trade countdown ("00:01:00") was in the same OCR pass, and a
   naive `HH:mm` regex found "00:01" inside it. Fixed the same way as #3b/#4:
   reject the whole string outright if it has the wrong overall shape
   (an H:MM:SS pattern), rather than extracting a plausible-but-wrong value.
7. **Timeframe estimation had no outlier tolerance at all.** After #6, a real
   device test still showed 15m on a chart that was actually 1m — a ~15x
   error, plausibly caused by a single bad OCR reading. Unlike
   `PriceScaleMapper`, which got X-clustering and outlier removal back in
   bug #4's fix, `TimeframeDetector`'s regression over time labels had zero
   tolerance for one bad point, and its candle-spacing calculation used a
   plain mean (vulnerable to a single missed-candle gap the same way #4's
   fix targeted for prices). Fixed by applying the identical
   median-residual outlier removal `PriceScaleMapper` already had, plus
   switching candle spacing from mean to median. Worth noting for anyone
   reading the regression test: a synthetic outlier placed at the *edge* of
   the X range gets disproportionate regression leverage and becomes harder
   to detect via residuals — the test had to place it in the middle of the
   range to be a valid check, a real statistics subtlety worth knowing
   about if extending this further.

**The throughline**: bugs #3b, #4, and #6 are the same failure shape
appearing three times in three different parsers — a regex finding a
valid-looking sub-match inside text that has the wrong shape overall. Once
that pattern was recognized, the fix (reject the whole string, don't extract
from it) got faster to apply each time. Bug #5 is a reminder that a
downstream symptom (OCR finding nothing) doesn't always mean the bug is in
the OCR layer — it was two phases upstream, in the pixel-geometry code
Phase 2 shipped before OCR even existed. Bug #7 is a reminder that a
robustness fix built for one class (`PriceScaleMapper`) doesn't
automatically protect a sibling class solving a structurally similar
problem (`TimeframeDetector`) — the same defense had to be built twice.
All seven were caught either by adding real diagnostics (`OcrDebugInfo`
surfacing raw text, crop dimensions, and exceptions) and reading what they
actually said, or by hand-tracing the exact regex/math against the exact
failing string — not by guessing and re-testing blind.

## 3. Project structure

```
app/src/main/java/com/chartlens/ai/
  common/            ColorMath, PixelBuffer, CaptureState(+Repository), LatestFrameHolder
  capture/           CapturedFrame, FrameChangeDetector, ScreenCaptureController
  service/           ScreenCaptureService
  overlay/           OverlayService, OverlayLifecycleOwner
  ui/                MainActivity, MainViewModel, DashboardScreen,
                      ChartRegionSelectionScreen, AiSettingsScreen, JournalScreen, ReplayScreen
  cv/                CandleColorProfile, ChartRegion, ChartDetector, FrameAnalyzer,
                      ViewShiftDetector
  candle/            Candle, CandleDetector, CandlePattern(+Detector)
  settings/          NormalizedRect, ManualChartRegionStore, AiBackendSettingsStore
  ocr/               OcrTextBlock, OcrEngine, OcrDebugInfo, PriceTextParser, TimeTextParser
  indicators/        EMA, RSI, MACD, ATR, BollingerBands
  analysis/          PriceCandle, DataQuality, AnalysisFrame(+Repository),
                      PriceScaleMapper(+Mapping), TimeframeDetector, CandleCloseTracker,
                      TrendAnalyzer, MomentumAnalyzer, SupportResistanceAnalyzer,
                      TechnicalAnalysisEngine, CandleHistoryMerger, NewCandleFinder,
                      ChartStructurePatternDetector
  prediction/        PredictionEngine, PredictionModels, PredictionWeights, LastCandleContext,
                      PredictionOutcome, OutcomeEvaluator
  ai/                AiAnalysisRequest/Response, AiAnalysisProvider(+Remote impl),
                      AiAnalysisApi, AiRequestMapper, AiTriggerPolicy, AiResponseValidator,
                      AiInsight(+Repository), AiInsightCoordinator, AiModule
  database/          PredictionEntity, PredictionDao, CandleHistoryEntity, CandleHistoryDao,
                      ChartLensDatabase, DatabaseModule, PredictionJournalRepository,
                      CandleHistoryRepository
  analytics/         AccuracyBucket, AccuracyStats, AccuracyAnalytics
  journal/           JournalCoordinator
  replay/            CandleHistoryRecorder, ReplayEngine, ReplayResult/ReplayStep
backend/             Node/Express reference AI backend (separate deployment target)
```

## 4. Configuring the build

- **Gradle wrapper**: pinned to Gradle 8.9 in `gradle/wrapper/`, jar not
  checked in — open in Android Studio or run `gradle wrapper --gradle-version
  8.9` once.
- **`gradle.properties`** must include `android.useAndroidX=true` (a real
  early build failure without it).
- **OpenCV**: not a dependency — see Phase 2's architecture note above.
- **ML Kit text recognition** is active (Phase 3's OCR).
- **`retrofit2-kotlinx-serialization-converter`**: declared since Phase 1,
  first actually exercised by Phase 6's code — see the risk note in section 1.
- **KSP/Kotlin pairing**: `2.0.20-1.0.24` — verify against
  https://github.com/google/ksp/releases if bumping Kotlin.
- **AI backend**: not configured by default — see section 6.

## 5. How to build / install

```
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 6. Configuring the AI backend (Phase 6, optional)

The app works fully without this — Phase 5's local prediction engine never
depends on it. To get AI-written explanations on top of a BULLISH/BEARISH
prediction:

1. Deploy `/backend` yourself — see `backend/README.md` for step-by-step
   instructions (Render/Railway/Fly.io free tiers all work).
2. Set `ANTHROPIC_API_KEY` and `CLIENT_AUTH_TOKEN` as environment variables
   on your hosting platform — never in the app, never committed to source.
3. In the app: **AI Backend Settings** → enter your backend's URL and the
   same auth token → Save.

## 7. Permissions required

`SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PROJECTION`,
`POST_NOTIFICATIONS`, `INTERNET`/`ACCESS_NETWORK_STATE` (now actually used, by
Phase 6's AI backend calls). ML Kit OCR runs fully on-device — no network
permission needed for it specifically.

## 8. Known limitations

- **Phase 6's backend has never been run.** See section 1's caveat — real,
  complete, hand-reviewed source code, genuinely unverified until deployed.
- **No instrument-name detection.** `AiRequestMapper` sends `instrument:
  "Unknown"` — there's no OCR pass reading the instrument label (e.g.
  "AUD/USD (OTC)") anywhere in the pipeline yet. Honest gap, not fabricated.
- **Phase 3's OCR crop/parsing logic has been tuned against real device
  testing across ~6 rounds of bugs (see section 2) but only on a handful of
  actual layouts.** Confidence is much higher than earlier phases, but
  "robust across every possible trading app layout" hasn't been proven.
- **Manual chart selection is global, not per-app.**
- **No accessibility-service-based foreground-app detection.**
- **Phase 5's weights/thresholds are reasonable defaults, not calibrated**
  — real calibration needs Phase 7's outcome journal, which doesn't exist yet.
- **No real candle timestamps** (`PriceCandle.timestampMillis` stays null) —
  deriving one needs a reference wall-clock anchor OCR doesn't reliably give.

## 9. Tests performed

**Phases 1-4:** `FrameChangeDetectorTest` (6), `CandleDetectorTest` (6),
`ChartDetectorTest` (5, including the vertical-bounds regression test),
`CandlePatternDetectorTest` (7), `EMATest`/`RSITest`/`ATRTest`/
`BollingerBandsTest`/`MACDTest` (18 total), `TrendAnalyzerTest`/
`MomentumAnalyzerTest`/`SupportResistanceAnalyzerTest` (13 total).

**Phase 3:** `PriceTextParserTest` (8, including regressions for the bare-
integer and comma-grouping bugs), `TimeTextParserTest` (6, including the
countdown-timer regression), `PriceScaleMapperTest` (9), `TimeframeDetectorTest`
(6, including regressions for the outlier-removal and median-spacing bugs), `CandleCloseTrackerTest` (5), `DataQualityCalculatorTest` (5).

**Phase 5:** `PredictionEngineTest` (11) — a hand-computed baseline scenario
plus one isolated test per NO_TRADE gate.

**Phase 6 (new, all pure Kotlin):**
- `AiResponseValidatorTest` (12): well-formed acceptance, invalid bias/
  confidence/dataQuality rejection, empty/oversized reasoning rejection,
  the NO_CLEAR_SETUP-with-high-confidence inconsistency check, and — the
  most important set — a real known level accepted, a fabricated level
  rejected, and a level rejected outright when the request supplied none
- `AiTriggerPolicyTest` (6): fires on a fresh close with a real prediction,
  correctly withholds for no-close/NO_TRADE/missing-technical-analysis/
  already-triggered-candle cases, fires again for a genuinely new candle
- `AiRequestMapperTest` (7): null-propagation when data is missing, correct
  field mapping, pattern-to-string joining (including the empty-set →
  null-not-empty-string case), EMA alignment description correctness

`OcrEngine`, `RemoteAiAnalysisProvider`, and the rest of the Android
network/ML-Kit boundary remain reviewed-by-hand rather than unit tested —
same boundary as every other phase's un-testable-here classes. The backend
itself (`/backend`) has no test suite — see section 1's caveat.

**Phase 7 (new, all pure Kotlin):**
- `OutcomeEvaluatorTest` (7): WIN/LOSS correctness for both UP and DOWN
  predictions, the neutral-zone threshold, NO_TRADE always invalid, a
  zero/negative entry price handled as invalid data rather than a crash
- `AccuracyAnalyticsTest` (13): empty-journal handling, accuracy computed
  only from decisive outcomes (neutral/invalid don't dilute it), unresolved
  entries counted in totals but excluded from accuracy, the edge-claim gate
  at exactly the minimum threshold, current streak computed correctly
  regardless of input ordering (a scrambled-order test confirms the
  function sorts internally rather than trusting the caller), a losing
  streak represented as negative, max win/loss streaks found across a mixed
  history, per-instrument/confidence-bucket bucketing correctness, a null
  setup bucketed under "unknown" rather than crashing

`PredictionDao`/`ChartLensDatabase` (real Room, needs an instrumented test
or a device to exercise) and `JournalCoordinator`'s Android/coroutine
wiring remain reviewed-by-hand — same boundary as always. `PredictionEntity`
itself, despite its Room annotations, is a plain data class and is directly
usable in the pure-Kotlin analytics tests above without any database.

**Phase 8 (new, all pure Kotlin):**
- `ReplayEngineTest` (4) — the centerpiece is the look-ahead-bias test:
  replays two histories identical up to index 39 and diverging sharply
  after it, asserting every prediction at or before that point is identical
  between the two runs. Also: too-few-candles produces zero steps, replay
  stops rather than guessing when there's no future candle to evaluate
  against, and the accuracy stats account for exactly the steps produced.
  See section 1's honesty note on this test's synthetic price data — the
  look-ahead-bias *guarantee* is structural (enforced by `subList(0, i+1)`
  in the engine itself) regardless of whether the test data reliably
  triggers it, but the test's ability to *demonstrate* that guarantee
  depends on producing at least one real prediction to compare, which is a
  reasoned expectation rather than a confirmed one.

`CandleHistoryDao` and `CandleHistoryRecorder`'s Android/coroutine wiring
remain reviewed-by-hand — same boundary as always.

**Post-Phase-8 fix:**
- `ViewShiftDetectorTest` (6): no shift reported on the first frame (nothing
  to compare against), a stable overlapping range across frames is not a
  shift, a large non-overlapping jump is, the comparison stays correct even
  when the region's own top offset changes between frames (not just the
  candle geometry), only-forming-candles is treated as no data rather than
  a false shift, and `reset()` correctly clears prior state.
- `CandleHistoryMergerTest` (5): no recorded history falls back to on-
  screen candles as-is, no current-frame candles returns history unchanged,
  a genuinely new closed candle gets appended, an already-recorded candle
  is not appended twice, and a tiny floating-point difference in the same
  candle's close still correctly counts as "already represented" rather
  than a false new-candle detection.
- `NewCandleFinderTest` (7): every candle is new with no prior state,
  nothing is new with no currently-visible candles, normal one-at-a-time
  progression finds exactly the single new candle, a catch-up scroll
  revealing several missed closes backfills all of them at once (the
  actual bug this was built for), nothing new returns empty rather than
  re-recording, a last-recorded price not found anywhere visible falls
  back to treating the whole window as new, and a repeated price level
  correctly anchors to the most recent occurrence rather than the first.
- `ChartStructurePatternDetectorTest` (13): a clean, hand-verified match
  per pattern type (double top/bottom, head & shoulders and its inverse,
  all three triangle types), plus rejection cases — peaks too far apart,
  no valley between them, insufficient time separation, a "head" that
  isn't actually higher than its shoulders, too few swing points, both
  lines flat (no triangle), and no swing data at all.

## 10. Remaining work (next phases)

- **Phase 9** — Battery/performance tuning, accessibility, polish. The last
  phase.

**Recommended immediate next step**: run `ReplayEngineTest` in CI/Android
Studio and confirm the look-ahead-bias test actually produces comparable
steps rather than an empty (vacuous) pass — this is the one thing in Phase 8
I flagged as a reasoned-but-unconfirmed risk rather than a verified fact.
Separately, on a real device: run a live session long enough to record
candle history, then open Replay / Backtest and confirm a session actually
appears and produces sensible results — Phase 8 has had no real-device
verification at all yet, same as Phase 7 before its first test and Phase 6
still today. Also still outstanding: deploying `/backend` and confirming
Phase 6 actually works end-to-end — it remains the one piece in this whole
project with zero real-environment verification of any kind.
