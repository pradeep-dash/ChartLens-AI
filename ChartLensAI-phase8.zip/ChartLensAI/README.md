# ChartLens AI — Phases 1-8

Analysis/decision-support only. This app never places trades, clicks buttons, or
interacts with any trading platform — it only reads the screen and displays
information.

This milestone covers **Phases 1-8 of 9**. Not yet present: performance and
accessibility polish (Phase 9).

---

## 1. What was implemented, phase by phase

### Phase 1 — Foundation
Full MediaProjection capture pipeline (`ScreenCaptureService`,
`ScreenCaptureController`), a draggable/collapsible floating overlay
(`OverlayService`), and the full permission sequence (notifications → overlay
→ MediaProjection consent). Verified working on-device early on.

### Phase 2 — Vision (chart/candle detection)
`ChartDetector` (automatic chart-region detection via candle-color density,
no hardcoded coordinates), `CandleDetector` (column clustering + row-coverage
body/wick separation), `CandlePatternDetector` (doji, engulfing, hammer,
etc. — geometry-scored, not name-matched), and a manual chart-selection
fallback (`ChartRegionSelectionScreen`). Pure Kotlin/Android pixel
processing, not OpenCV — a deliberate call made early on given how much
friction OpenCV's Maven setup risked adding for capability not needed at
this scale.

### Phase 3 — OCR, price mapping, timeframe, candle-close detection
`OcrEngine` (ML Kit, fully on-device), `PriceScaleMapper` (least-squares
regression from OCR'd price labels to real prices, with X-position
clustering and iterative outlier removal), `TimeframeDetector`,
`CandleCloseTracker`. This phase went through the most real-device iteration
of any — see section 2 below for the full account, because the failure
patterns and fixes here are worth understanding, not just the end state.

### Phase 4 — Technical Analysis Engine
`EMA`/`RSI`/`MACD`/`ATR`/`BollingerBands`, `TrendAnalyzer` (swing-structure
based), `MomentumAnalyzer`, `SupportResistanceAnalyzer` (breakout/rejection
detection). Fully pure Kotlin, fully unit tested against hand-calculated
values. Built before Phase 3's OCR existed, deliberately decoupled from
Phase 2's pixel-based `Candle` model (a separate `PriceCandle` model) so it
could be built and verified without waiting on real price data.

### Phase 5 — Prediction Engine
`PredictionEngine` combines every evidence source above (trend, momentum,
EMA alignment, RSI, MACD, support/resistance, candle patterns, recent candle
sequence) into a weighted directional score. NO_TRADE is a first-class,
actively-sought output — insufficient data/candles, conflicting evidence,
low confidence, an unknown timeframe, a doji/chop candle, price sitting at
an unbroken level, and elevated volatility are each independent hard gates;
any one firing forces NO_TRADE regardless of how strong the rest of the
evidence looks. `modelConfidence` is displayed everywhere as "NN/100," never
a percentage chance, per the spec's explicit requirement. Confirmed working
end-to-end on a real device after Phase 3's fixes landed — see section 2.

### Phase 6 — AI Reasoning Layer
- **Android client, fully wired and testable**: `AiAnalysisRequest`/
  `AiAnalysisResponse` (kotlinx.serialization DTOs), `AiRequestMapper` (pure,
  reshapes already-computed local data into the request — never derives new
  information), `AiTriggerPolicy` (pure — only fires on a fresh candle close
  with a real non-NO_TRADE prediction, per the spec's "prefer deterministic
  local analysis over unnecessary AI calls"), `AiResponseValidator` (pure —
  rejects malformed shapes, out-of-range confidence, and critically,
  fabricated price levels not close to anything the request actually
  supplied), `RemoteAiAnalysisProvider` (Retrofit/OkHttp, builds its client
  dynamically from a user-configured URL — there is no baked-in default
  backend), `AiInsightCoordinator` (fires the async call without ever
  blocking the fast local frame pipeline on network I/O), full Settings UI
  for entering the backend URL and auth token.
- **A real, complete reference backend** (`/backend`): Node/Express,
  bearer-token auth, in-memory rate limiting, request AND response
  validation server-side (defense in depth alongside the client's own
  validation), a prompt that encodes the spec's exact behavioral rules
  (never invent indicators or price levels, never claim certainty, prefer
  NO_CLEAR_SETUP over a fabricated call), and a full deployment guide for
  free-tier hosts (Render/Railway/Fly.io).

**A real constraint worth being direct about**: this sandbox has no
persistent hosting and no network access, so the backend is genuinely
unrunnable here — it's real, carefully-written source code, reviewed by
hand, but literally never executed. This is the same "unverified until a
real environment exercises it" caveat that's applied to every
Bitmap/ML-Kit/network boundary class throughout this project, just at a
larger scale (an entire server, not one class). There's also a first-use
risk worth flagging: `retrofit2-kotlinx-serialization-converter` has sat as
a declared-but-unused dependency since Phase 1's initial setup — this is the
first code that actually exercises it, so a version/API mismatch here is a
real possibility that earlier phases' testing couldn't have caught.

### Phase 7 — Prediction Journal & Accuracy Analytics (NEW)
- **Room database** (`PredictionEntity`, `PredictionDao`, `ChartLensDatabase`):
  every real (non-NO_TRADE) local prediction gets journaled automatically —
  independent of whether Phase 6's AI backend is even configured, since
  Phase 5's local prediction is what's actually being scored. Per the spec's
  "do not modify historical predictions after evaluation except to record
  their actual outcome" — the DAO's `recordOutcome` query updates only the
  three outcome-related columns; there is no update method that touches
  anything else.
- **`OutcomeEvaluator`** (pure, tested): compares the price at prediction
  time against the price once the prediction's horizon is actually reached —
  never evaluated early. A small neutral-zone threshold (0.02%) keeps
  noise-level moves from counting as a real win or loss.
- **`JournalCoordinator`**: wires recording and evaluation into the live
  pipeline. Evaluation is index-based (which candle number to check), not
  wall-clock based, since real candle timestamps still don't exist. If a
  target candle never reappears within a generous buffer after its horizon
  (most likely scrolled out of the visible/cropped chart region), it's
  marked INVALID_DATA rather than left pending forever — a disclosed
  limitation of index-based tracking, not silently ignored.
- **`AccuracyAnalytics`** (pure, tested): total/win/loss/neutral/invalid
  counts, overall accuracy (computed only from decisive WIN/LOSS outcomes —
  neutral and invalid entries don't dilute or inflate it), breakdowns by
  instrument/timeframe/confidence-bucket/setup, current streak, and max
  win/loss streaks. Sorts chronologically internally, so callers never need
  to worry about the DAO's own ordering convention.
- **The mandatory "don't claim an edge" gate**: `hasEnoughDataForEdgeClaim`
  requires at least 30 decisive predictions (a documented judgment call, not
  a statistically derived number) before the Journal screen will display
  accuracy as a real statistic — below that, it shows raw counts with an
  explicit "not enough data yet" message instead.
- A full Journal screen (`JournalScreen`) showing the accuracy summary and
  recent predictions with color-coded outcomes.

### Phase 8 — Replay / Backtest Mode (NEW)
- **`CandleHistoryRecorder`**: persists one real closed candle per candle
  close during live sessions (`CandleHistoryEntity`, a new Room table) — this
  is the only source of data replay ever uses. Follows the same honesty rule
  as Phase 7's journal: a candle only gets recorded when price mapping was
  actually trusted at that moment; if not, it's silently skipped rather than
  fabricated, which means recorded history can have real gaps.
- **`ReplayEngine`** — the core of this phase, and the direct, structural
  implementation of the spec's "prevent look-ahead bias" requirement, not
  just a design intention. At step `i`, the technical analysis engine only
  ever receives `history.subList(0, i + 1)` — there is no code path that can
  hand it a later index. Reuses `TechnicalAnalysisEngine` and
  `PredictionEngine` directly (the exact same code a live session runs, not
  a reimplementation that could drift), and reuses `AccuracyAnalytics` for
  the summary by building ordinary `PredictionEntity` rows in memory —
  these are never written to the real database, so a backtest run can never
  pollute Phase 7's live accuracy numbers.
- **The centerpiece test, `ReplayEngineTest`**: replays two candle histories
  that are byte-for-byte identical up to a point and diverge sharply after
  it (one keeps rising, one crashes), then asserts every prediction made at
  or before that point is identical between the two runs. This doesn't just
  check that replay "runs" — it empirically proves a later candle can never
  influence an earlier step's prediction.
- A Replay screen listing recorded sessions (built only from real history,
  no synthetic/sample dataset to demo it with) and showing full results —
  every step, its outcome, and the same accuracy summary Journal uses.

**Worth being honest about**: the look-ahead-bias test's price data is
synthetic (a gently oscillating uptrend, deliberately not a perfectly
monotonic line — a straight-line rise would push RSI to ~100 from never
having a single down candle, which could trigger `PredictionEngine`'s
conflicting-evidence gate on every single step and make the test pass
vacuously with zero real predictions to compare). I reasoned through why
this pattern should produce at least one real prediction within the shared
prefix, and structured it with 21 independent candidate steps to make that
likely — but I can't execute this test here, so "should reliably produce a
real prediction" is a reasoned expectation, not a confirmed fact. If it
turns out to fail by producing zero comparable steps, that's a test-data
tuning problem, not evidence the look-ahead-bias prevention itself is
broken — the structural guarantee (`subList(0, i + 1)`) holds regardless of
what the test data does.

### Post-Phase-8 fix — undisclosed prediction jumps from chart scroll/pan
A real device test showed the prediction flipping between "no clear setup"
and a real directional call within 15 seconds, with the visible time-axis
window having shifted ~16 minutes between the two frames — almost certainly
a manual chart scroll, not natural candle progression. This wasn't actually
wrong analysis (the pipeline only ever reads whatever's currently on screen
by design, with no persistent memory of "true" history beyond that) — but
two real problems sat underneath the confusing symptom: nothing disclosed
that a shift had happened, so a legitimate re-analysis of genuinely
different data looked like arbitrary instability; and the region/OCR
caches (good for 20-30 frames on a stable chart) could keep serving a now-
mismatched stale crop for several frames after a shift, before naturally
refreshing.

Fixed with `ViewShiftDetector`: compares the visible candles' vertical
pixel extent frame to frame, and when overlap drops below 30% (a real pan/
zoom, not gradual progression), forces an immediate region/OCR cache
invalidation and a `CandleCloseTracker` reset instead of waiting out the
normal cache interval, and surfaces "⚠ Chart view shifted" in the Dashboard
debug view so a sudden jump is explained rather than mysterious. This is
explicitly a heuristic, not a perfect signal — the pipeline has no real
per-candle timestamps or persistent candle identity to compare against
instead, which would be the more precise fix but is a materially bigger
undertaking. A genuine, very sharp price spike could in principle also trip
it; an accepted false-positive rate, since the cost of an unnecessary
re-verification is small next to the cost of silently trusting a stale
cache after a real shift.

### Post-Phase-8 fix — live analysis was silently bounded by the screen's current width
A user question surfaced a real architectural gap: `CandleHistoryRecorder`
was already building a growing, persistent record of every real candle as
it closed (used for Phase 8's replay), but the **live** prediction engine
never read it — every frame recomputed trend/RSI/EMA/momentum from only
whatever was currently visible on screen. If more candles fit in history
than fit on screen at once, the rest effectively didn't exist to live
analysis; scrolling or a narrower view could make indicators "forget"
things that had already happened, even though they were being recorded
correctly the whole time.

Fixed with `CandleHistoryMerger`: the live pipeline now optionally reads
the full recorded session history (via a `sessionHistoryProvider` passed
into `FrameAnalyzer`, null and fully backward-compatible in every existing
unit test) and merges it with the current frame's own candles before
feeding `TechnicalAnalysisEngine` — recorded history is authoritative for
everything except the newest candle, which gets appended only if it isn't
already represented (matched by closing price, not a stable ID, since
neither the recorded history's nor the current frame's candle `index` is a
reliable cross-frame identifier — both are positional, assigned fresh from
whatever's currently visible). This was scoped deliberately narrowly:
`AnalysisFrame.priceCandles` and everything that matches against it by
this-frame index (`lastCandleContext`, `JournalCoordinator`,
`AiRequestMapper`) is completely untouched — only what feeds the technical-
analysis engine itself was widened, to avoid risking the correctness of
already-working index-matching logic elsewhere in the pipeline.

### Post-Phase-8 fix #2 — missed candles when the chart doesn't auto-follow price
Immediate follow-up from the same conversation: it turned out scrolling
wasn't optional for this user — their trading platform's chart doesn't
auto-advance to keep the latest price in view, so periodically scrolling
right to catch up is a required part of the workflow, not an avoidable
habit. That exposed a real gap in `CandleHistoryRecorder`'s original
design: it only recorded a candle when `CandleCloseTracker` fired a single
frame-to-frame close-event signal. If several real candles closed entirely
off-screen while the chart sat still, then a catch-up scroll suddenly
revealed all of them at once, only the single most recent would ever have
been recorded — the rest silently lost, with no trace they'd ever existed.

Fixed with `NewCandleFinder`: instead of relying on a single close-event
signal, `CandleHistoryRecorder` now compares the *whole* currently-visible
window against the last recorded candle's closing price every frame, and
backfills every genuinely-new candle it finds — one at a time during normal
progression, or several at once after a catch-up scroll. Same disclosed
price-matching limitation as `CandleHistoryMerger` (no stable candle
identity to match on instead), with the same reasonable fallback: if the
last-recorded price isn't found anywhere in the current view at all (it
scrolled off entirely), the whole visible window is treated as new —
occasionally risking a re-recorded candle, preferred over silently
recording nothing for that frame.

**Still an open, disclosed limitation**: none of this can recover a candle
that closed off-screen and then scrolled *back* off-screen again before the
next analyzed frame — this only backfills what's actually visible at the
moment of analysis. If the chart genuinely never shows a stretch of price
action at all, that stretch is unrecoverable, the same honest ceiling as
"this app only ever knows what it can currently see" that's applied
everywhere else in this project. The best real fix is checking whether the
trading platform has its own "resume live" / follow-price control, which
this app has no ability to invoke itself (it never interacts with the
page, only reads it).

### Post-Phase-8 addition — broader chart structure patterns
A direct feature request, evaluated honestly against a competitor's claimed
capability list rather than built blindly: of five gaps identified (VWAP,
volume behavior, broader chart patterns, Level 2 pressure, existing
position status), only one was genuinely buildable and testable —
**Level 2 and volume/VWAP were declined**, not built as non-functional
placeholders. No screenshot across this entire project has ever shown a
volume histogram or VWAP line on QX Broker's charts, and VWAP is
literally volume-weighted, so it shares the same blocker; writing
detection code for a UI element that may not exist on this platform would
be untestable, unverifiable code. No Level 2/order-book panel has ever
appeared either — QX Broker is a binary-options OTC platform, which
plausibly doesn't expose this kind of data at all. Existing position
status was set aside as a different category of feature (account
monitoring, not chart analysis) rather than declined outright.

**Built: `ChartStructurePatternDetector`** — Double Top, Double Bottom,
Head & Shoulders, Inverse Head & Shoulders, and three triangle types
(ascending/descending/symmetrical), detected from the same swing-high/
swing-low sequence `TrendAnalyzer` already computes — no new capture
capability needed, since this only needs price data already in hand.
Double-top/bottom and head-and-shoulders confidence scales with how
closely the peaks/troughs actually match (a real computed magnitude);
triangle detection uses a fixed, deliberately modest confidence instead,
since a 2-3 point line fit has very little real statistical weight and a
precise-looking computed number there would overstate what the data
actually supports.

Wired in as a 9th weighted evidence source in `PredictionEngine`,
deliberately designed to be fully backward-compatible: when no pattern is
detected (`chartStructureMatches` defaults to an empty list), the evidence
signal reports itself inapplicable and contributes exactly nothing to the
weighted score — the same rule every other evidence source already
follows. This was verified directly: the existing hand-computed baseline
tests (`PredictionEngineTest`'s clean bullish/bearish fixtures) don't set
this field at all, so their expected confidence values are provably
unaffected by this addition. A symmetrical triangle scores exactly 0
regardless of its own confidence — its breakout direction is genuinely
unknown until it actually breaks, so it registers as "worth noting" without
pushing the prediction either direction.

### Post-Phase-8 finding — the overlay itself was likely corrupting analysis
A real device test showed candle counts swinging wildly between frames only
eleven analyzed frames apart (37/38 candles, quality GOOD → 0/1 candles,
quality POOR) with no corresponding chart-side event to explain it. That
symptom, combined with a basic fact about how Android screen capture works,
points to a genuinely significant, previously-undiscovered architectural
bug: **MediaProjection captures the full composited display — every window
currently on screen, including this app's own floating overlay** — not
just "the chart" in some app-aware sense. It cannot tell the difference.
Every screenshot across this entire project has shown the overlay expanded
and positioned over the chart's lower-center area — exactly where recent
candles render. That means the overlay's own debug panel was very likely
part of the raw frame `FrameAnalyzer` analyzed the whole time, hiding real
candles underneath it from the CV pipeline, not just from the user's view.

Investigating this surfaced a second, compounding problem: the "collapse"
button never actually collapsed the thing that mattered. `expanded` only
ever gated the opacity slider — the entire large debug block (candle
count, quality, prediction, confidence, price mapping, timeframe, RSI,
seven lines) was rendered unconditionally whenever capturing, regardless
of the collapse state. The collapse button looked functional but wasn't
actually reducing the panel's screen footprint in any meaningful way. This
was a real design flaw introduced across Phases 1-8 as more debug detail
kept getting added to `AnalysisStatusLine` without anyone (including me)
re-examining whether `expanded` still meaningfully gated it.

**Fixed, two parts:**
1. `expanded` now genuinely gates the full debug block. Collapsed
   (the new default) shows only a one-line prediction summary
   (`🟢 BULLISH 78` / `⚠ NO SETUP`) plus a compact status line — roughly
   one line instead of seven.
2. The expanded view now carries an explicit, persistent warning that the
   panel is captured along with the chart and can hide real data while
   parked over it.

**Honestly incomplete**: this reduces the risk significantly but doesn't
eliminate it — an expanded panel, or even the smaller collapsed one, can
still occlude a few candles if left directly over the chart. The complete
fix would be genuinely excluding this window from MediaProjection's
capture. `FLAG_SECURE` was considered and rejected: it doesn't make a
window transparent to capture, it replaces that window's content with a
black rectangle in the captured output — the candles underneath would
still be just as hidden, only by black pixels instead of debug text.
Actually hiding the overlay for the brief instant of each capture and
restoring it afterward is possible in principle but requires careful
cross-thread timing (the capture callback runs off the main UI thread,
and View visibility changes don't take effect atomically) that isn't safe
to ship without real device testing to verify it doesn't introduce visible
flicker or a race that recreates the same problem differently. Documented
here as the natural next step, not attempted blind.

**Practical guidance in the meantime**: drag the overlay to a corner or
edge that doesn't sit over the candles, or keep it collapsed and only
expand briefly to read details, then collapse again.

### Post-Phase-8 investigation (open) — candle undercount on a real, densely-packed chart
A real device test still showed a plateaued candle count (24/25) on a
chart that visibly had far more than that. Reasoned through why this is
likely a *different* bug from the overlay-occlusion one above, not the
same issue resurfacing: the chart was a strong uptrend, so recent candles
(right side) render high on screen while the overlay sat bottom-right —
geometrically, the panel likely wasn't overlapping much real candle
content in that specific screenshot. Not confirmed, since I don't have a
controlled comparison (same chart, overlay fully out of the way) yet.

Better-reasoned suspicion: every `CandleDetector` test case so far, going
all the way back to Phase 2, used comfortably wide synthetic candles.
A real chart with 40-50+ candles compressed into ~1248px would have each
candle only ~20px wide including its gap — meaningfully narrower than
anything ever actually tested. It's plausible the column-density/gap-
tolerance thresholds that work correctly at a wider scale are quietly
dropping or merging some candles at this real, narrower one — but I don't
have enough evidence yet to blindly retune thresholds and trust the
result, especially against a scale I have no way to reproduce or verify
here.

**Added, not yet a fix**: the Dashboard's Chart Analysis panel now shows
detected region width and average candle spacing in pixels alongside the
candle count. This is the evidence needed to actually distinguish two
different possible bugs with two different fixes: a region that's too
narrow to contain all the real candles (region width would stay roughly
constant while spacing keeps shrinking as more candles compress into it)
versus a region that's fine but individual candles within it are being
missed (spacing would look reasonable for the candle count reported, just
the count itself would be wrong). Next real step: a screenshot of this
debug panel during another undercount, ideally with the overlay confirmed
completely clear of the chart so that variable is controlled for.

### Post-Phase-8 fix — a real inconsistency between what fed technical analysis and what gated it
The requested debug screenshot delivered real, decisive evidence — and
revealed a genuinely different bug than the one being investigated,
confirming (this time with real proof, not just geometric reasoning) that
the candle-undercount concern above was not the overlay-occlusion issue
resurfacing: `RSI(14): 50.6`, real EMA values, and a coherent `SIDEWAYS`
trend all appeared on a frame reporting `0 closed + 1 forming` candles —
technical analysis was clearly working correctly, computed from the
accumulated session history via `CandleHistoryMerger`, exactly as
designed. But the prediction still said "not enough closed candles yet."

The cause: `FrameAnalyzer` passed `closedCandleCount = closedPixelCandles.size`
(the narrow, this-frame-only on-screen count) to `PredictionEngine.predict()`,
while `technicalAnalysis` itself was computed from `analysisInputCandles`
(the merged, accumulated series). On any frame where on-screen detection
was momentarily low — even with a perfectly good, richly-informed
technical analysis available — the prediction engine's `INSUFFICIENT_CANDLES`
gate fired anyway, because it was checking the wrong count. This was a
direct, if unintentional, side effect of the `CandleHistoryMerger` fix
itself: it correctly widened what feeds technical analysis but missed
widening the gate that checks alongside it. Fixed by passing
`analysisInputCandles.size` instead, so the count actually reflects the
same data the analysis was computed from.

Also fixed in the same pass: the region-width diagnostic added to help
investigate the *original* undercount question never actually appeared at
low candle counts (it required 2+ closed candles to compute average
spacing) — exactly the case where it was needed most. Region width now
shows unconditionally; spacing is added alongside it only when there's
enough data to compute it meaningfully. The original undercount question
remains open and still needs its own dedicated debug screenshot — this
fix addressed a different, real problem the investigation surfaced along
the way, not the candle-detection question itself.

### Post-Phase-8 fix — the original candle undercount, finally diagnosed and fixed
A later screenshot made the undercount unambiguous enough to act on
without waiting for the ideal diagnostic screen: a chart spanning roughly
96 minutes on a confirmed 1-minute timeframe, essentially continuous with
no large visible gaps, reporting only 21/22 candles — a real gap of
roughly 4x against a reasoned visual estimate (~80-90 candles), with the
overlay confirmed positioned away from the chart entirely, ruling out the
occlusion bug as the cause this time.

Traced the actual cause in `CandleDetector`: `clusterIntoBars` only starts
a new bar on a color change or a background gap wider than 2px — a real,
deliberate fix from earlier in this project for touching candles of
*different* colors. But it does nothing for a run of several consecutive
*same*-colored candles with little or no gap between them — routine
during any sustained directional move, and exactly what this chart's
extended decline showed. Several real candles were silently merging into
one detected bar, with no color change or background gap ever occurring
to split them apart. The ~4x undercount ratio is consistent with typical
same-direction runs of around four candles each merging into one.

Fixed with a new post-processing pass, `splitMergedRuns`: estimates a
typical single-candle width from the MEDIAN width across all detected
bars (robust to some merged outliers, since genuinely single candles —
correctly split by color changes — are the majority on any chart with
reasonably frequent color alternation), then splits any bar that's a
confident whole-number multiple of that width (checked with tolerance,
not exact-integer division, since real rendered width varies by a pixel
or two) into that many equal sub-bars. A bar with no clean multiple
relationship is left alone rather than guessed at — a genuinely wide
single candle is possible, and splitting it would fabricate candles that
were never actually there. Requires at least 3 detected bars before
attempting any split at all, since fewer than that gives no reliable
width estimate to work from.

Three new tests hand-verify this precisely: a 12px run against a 4px
median splits cleanly into three 4px candles; a 6px bar (not a clean
multiple of 4px — nearest candidate is 8px, outside tolerance) is
correctly left as one real candle rather than fabricated into two; and a
2-bar scenario that would otherwise look like a clean multiple never
attempts splitting at all, since there's no reliable width estimate with
so few bars. Every existing `CandleDetectorTest` case was individually
re-checked against the new `bars.size < 3` guard and confirmed unaffected
(all of them detect fewer than 3 bars, so the new logic never engages).

### Post-Phase-8 fix — the actual root cause of the candle undercount (after three wrong guesses)
The merged-same-color-run fix above did not resolve it. Worth recording
honestly: this bug took **four attempts** — overlay occlusion, region
width, merged same-color runs, and finally the real cause. The first three
were each reasoned from a plausible theory and shipped without being able
to observe the actual failure, which is precisely the failure mode this
project's own README warns about in the Phase 3 saga section. What
eventually cracked it was not more code inspection but a specific,
detailed user observation of the *behavioral pattern* across sessions.

The decisive evidence: counts were wildly unstable rather than
consistently low — 0/1 on a normal view, then 37/38 after zooming around,
then 4/5 zoomed *in* (a view with ~30 large, clearly-separated candles —
the easiest possible detection case, which ruled out every
candle-geometry theory), then 0/1 again after switching charts, and
critically: **never recovering on its own even after a minute idle**,
while region confidence stayed at 98-99% and price mapping at 99%
throughout. That pattern points at cached *state*, not pixels.

Root cause, in `FrameAnalyzer.resolveAutoRegion`: the detected chart
region was cached and reused for 20 frames with **no check that it was
actually working**. A stale or subtly-wrong region can still score high
confidence, because `ChartDetector` scores candle-color density *within
whatever region it found* — a region that has drifted onto a narrow or
unrepresentative slice genuinely contains candle-colored pixels and scores
98-99%, while containing almost no complete, detectable candles. Once a
session cached a bad region, nothing ever re-evaluated it: rediscovery ran
on schedule but could simply re-cache an equally bad one, so the session
stayed broken indefinitely. Zooming appeared to "fix" it only because it
triggers `ViewShiftDetector`, forcing an invalidation that sometimes
happened to land on a good region.

Fixed with `RegionRediscoveryPolicy` (extracted as a pure class so it's
directly unit-testable, unlike `FrameAnalyzer` itself which takes an
Android `Bitmap`): the cached region is now re-detected immediately when
the previous frame produced almost no candles, rather than being trusted
for the full interval. The threshold (5 candles) sits far below any
plausible real chart, so it's a "this region has clearly stopped working"
signal rather than a quality bar, and a `framesSinceRediscovery > 0` guard
ensures a region is never judged by the very frame it was detected on
(which would cause endless re-detection). This works rather than looping
uselessly because `FrameChangeDetector` means only materially-changed
frames reach the analyzer at all, so each retry sees genuinely different
pixel data. Six hand-traced tests cover every branch. Also fixed in
passing: the policy was being constructed with a hardcoded 20 instead of
`FrameAnalyzer`'s own `rediscoverEveryNFrames` parameter — harmless at
default values, silently wrong if anyone ever customized it.

The overlay's persistent occlusion warning (added when the overlay-
occlusion bug was fixed) was removed at the user's request once it had
served its purpose — a reasonable call once someone has already
internalized the risk and is positioning the overlay correctly.

### Post-Phase-8 discussion — why NO_TRADE is common, and what was and wasn't changed
Direct user feedback: too few BULLISH/BEARISH signals relative to what
they expected for their trading cadence. Worth explaining clearly rather
than either dismissing it or silently loosening everything to please the
request — the "prefer NO CLEAR SETUP over fabricated confidence" principle
has been load-bearing since Phase 5 and shouldn't bend just because a
signal would be more convenient.

**Why this is structurally common by design, not a bug**: `PredictionEngine`
has six independent hard gates, each capable of forcing NO_TRADE on its
own — deliberately not a points system where a strong trend can outvote a
doji candle. Even if each gate only fires, say, 20-30% of the time
independently, requiring *all six* to stay clear simultaneously compounds
multiplicatively — NO_TRADE being the majority outcome is close to
mathematically inevitable with this structure, not evidence something is
broken.

**But one specific threshold was a real, well-reasoned overreach**:
`nearLevelToleranceFraction` (the "is price sitting right at a support/
resistance level" gate) was 0.3%. On a 1-minute OTC chart, swing-based S/R
levels tend to sit close together relative to typical intraday movement —
0.3% could span most of a session's actual price range, meaning this gate
was plausibly firing far more often than its "avoid calling a direction
exactly at a critical breakout point" intent. Halved to 0.15%. Explicitly
not a calibrated fix — a reasoned adjustment to a threshold that was
always a guess to begin with; Phase 7's prediction journal, once enough
real evaluated predictions accumulate, is the actual way to find the
right number here, and a checked-in test now protects the specific
existing near-level scenario so this doesn't drift silently in the future.

**Added: `DirectionalLean`** — when a gate blocks a call the raw evidence
would otherwise have made, the direction it was leaning (and its raw
score) is now surfaced on the Dashboard, explicitly worded as "not a
signal, just context," never journaled, never counted toward accuracy
stats, never shown when the raw evidence itself was too weak or mixed to
have a real lean (a genuinely unclear market correctly shows nothing to
lean toward). This was the actual right way to address "I want more
information," instead of loosening any of the six gates further —
gives real, honest information without ever fabricating a confidence
level a NO_TRADE explicitly declined to claim.

**What was deliberately NOT done**: no gate was removed or drastically
weakened, and `directionalThreshold`/`minConfidencePercent`/
`conflictRatioThreshold` were left untouched — I found genuine evidence
the near-level tolerance was miscalibrated (a real chart geometry
argument), but no comparable evidence for the others, and loosening them
on the strength of "the user wants more signals" alone would be exactly
the kind of fabricated-confidence-for-convenience tradeoff this project
has consistently declined to make.

**Follow-up, same conversation — a real confidence-ceiling bug, not just an
explanation**: asked why observed confidence scores were consistently
under 45. Traced the exact math rather than guess: `supportResistanceEvidence`
marked itself `applicable = true` whenever a support/resistance level
simply *existed* — true on nearly every frame — even when nothing was
actively happening there (score 0 in that case). Its full weight still
counted in the confidence denominator regardless, diluting the average
toward zero on most frames. Every other evidence source in the file
already follows "inapplicable when there's nothing real to report" (see
`candlePatternEvidence`) — this was a genuine inconsistency, not a
deliberate design choice, and the fix (require an active breakout/
rejection, not just a level's existence) brings it in line with that
established convention. Confirmed with real numbers: the hand-computed
"clean bullish" baseline test's confidence rose from 61 to 71 once this
stopped diluting an otherwise strongly-aligned set of evidence — meaning
real confidence scores were structurally capped well below what the
*other* evidence sources actually supported. All 12 existing tests were
individually re-traced by hand against this change; only the one baseline
number needed updating, everything else either used non-exact assertions
already robust to it or wasn't touched by the change at all. A new,
direct regression test locks in the specific behavior (inapplicable with
no active event, applicable with a real score once something happens).



Phase 3 needed far more device iteration than any other phase, and the
sequence of what broke and how it got fixed is worth keeping as a reference
for future debugging, not just historical trivia:

1. **Crop landed in blank space.** The price-axis crop was anchored to
   `region.right` + a small fixed width, assuming labels sit close to the
   last candle. Real charts often reserve blank space before the axis —
   the crop missed the labels entirely, finding nothing.
2. **A wide-layout crop grabbed the wrong content.** Anchoring to the
   screen's right edge instead (fix for #1) broke on a landscape layout with
   a persistent sidebar — it read "Withdrawal," trade amounts, instead of
   the price axis.
3. **A too-narrow crop truncated labels.** Widening the crop (fix for #2)
   used a floor just above ML Kit's 32px minimum — enough to stop a crash,
   not enough to capture full label text. "92.700" truncated to "700," and
   because the fragments were still evenly spaced, the fit was confidently
   wrong (87% confidence on garbage) rather than obviously failed.
3b. **Bare integers accepted as prices.** Fixed by requiring a decimal point
   in `PriceTextParser` — a truncated fragment like "700" no longer parses
   as a price at all.
4. **Comma-grouped UI figures leaked through.** A thousands-separator
   parsing path (added for a hypothetical "1,234.56"-style price) was exempt
   from the decimal requirement above. "19,400" (a payout amount) parsed
   clean, wasn't excluded by X-position clustering on that layout, and
   produced EMA values in the thousands on a sub-1.0 price chart. Comma
   support was removed entirely — every real price label observed across
   this whole project has used a plain period, every comma-containing
   candidate has been a false positive.
5. **`ChartDetector`'s vertical bounds extended past the real chart.** Not
   an OCR bug at all — the region's bottom edge was computed as an absolute
   min/max across every column touching a candle-colored pixel anywhere,
   with no contiguity check. The Up/Down trade buttons share the same
   bullish/bearish color family as candles; a few columns touching them
   dragged `region.bottom` deep into the trading-panel UI, starving the
   time-axis crop of anything real to find below it. Fixed by applying the
   same gap-tolerant clustering the horizontal pass already used, to rows.
6. **A countdown timer parsed as a clock time.** Once #5 was fixed and real
   time labels started appearing, timeframe detection *still* failed — the
   1-minute trade countdown ("00:01:00") was in the same OCR pass, and a
   naive `HH:mm` regex found "00:01" inside it. Fixed the same way as #3b/#4:
   reject the whole string outright if it has the wrong overall shape
   (an H:MM:SS pattern), rather than extracting a plausible-but-wrong value.
7. **Timeframe estimation had no outlier tolerance at all.** After #6, a real
   device test still showed 15m on a chart that was actually 1m — a ~15x
   error, plausibly caused by a single bad OCR reading. Unlike
   `PriceScaleMapper`, which got X-clustering and outlier removal back in
   bug #4's fix, `TimeframeDetector`'s regression over time labels had zero
   tolerance for one bad point, and its candle-spacing calculation used a
   plain mean (vulnerable to a single missed-candle gap the same way #4's
   fix targeted for prices). Fixed by applying the identical
   median-residual outlier removal `PriceScaleMapper` already had, plus
   switching candle spacing from mean to median. Worth noting for anyone
   reading the regression test: a synthetic outlier placed at the *edge* of
   the X range gets disproportionate regression leverage and becomes harder
   to detect via residuals — the test had to place it in the middle of the
   range to be a valid check, a real statistics subtlety worth knowing
   about if extending this further.

**The throughline**: bugs #3b, #4, and #6 are the same failure shape
appearing three times in three different parsers — a regex finding a
valid-looking sub-match inside text that has the wrong shape overall. Once
that pattern was recognized, the fix (reject the whole string, don't extract
from it) got faster to apply each time. Bug #5 is a reminder that a
downstream symptom (OCR finding nothing) doesn't always mean the bug is in
the OCR layer — it was two phases upstream, in the pixel-geometry code
Phase 2 shipped before OCR even existed. Bug #7 is a reminder that a
robustness fix built for one class (`PriceScaleMapper`) doesn't
automatically protect a sibling class solving a structurally similar
problem (`TimeframeDetector`) — the same defense had to be built twice.
All seven were caught either by adding real diagnostics (`OcrDebugInfo`
surfacing raw text, crop dimensions, and exceptions) and reading what they
actually said, or by hand-tracing the exact regex/math against the exact
failing string — not by guessing and re-testing blind.

### Post-Phase-8 fix — false signals from screen content that isn't a chart at all
A real device test found the app reporting "60/61 candles · region 80% ·
quality GOOD" while displaying a **text conversation**, no chart on screen
at all — `ChartDetector` scores candle-color density and `CandleDetector`
segments colored runs, but nothing anywhere in the pipeline verified that
what was found actually looked like a candlestick chart. Red/green
syntax-highlighted text and colored UI icons were being counted as
candles. This is a fundamentally more dangerous class of bug than an
inaccurate count on a real chart — the output isn't merely imprecise, it's
meaningless while still looking confident, and could in principle have
produced a fully fabricated BULLISH/BEARISH prediction from pure noise.

Fixed with `ChartStructureValidator`, checking four properties true of
real candlestick charts and false of arbitrary colored pixels: enough
candles, consistent horizontal pitch, consistent width, and vertical
overlap in a shared price band. Wired into `FrameAnalyzer` as a hard gate
before any analysis runs — rejection produces `DataQuality.INVALID` and no
prediction at all, with the specific reason surfaced on both the overlay
and Dashboard. Deliberately fails safe: it can only ever suppress a
signal, never fabricate one. Thresholds were verified numerically, not
eyeballed — a realistic synthetic chart scores 100% pitch consistency
against a 60% threshold, and a text-like scattered fixture scores 18%,
comfortable margins on both sides.

**A real prioritization correction, worth recording honestly**: this was
built as the first response to the false-signal discovery, but the user
then clarified their actual concern was broader — an accurate candle count
is how they verify the technical analysis is using *all* visible candles,
not a partial subset, which matters even on a genuinely real chart that
passes structural validation. The false-signal fix and the undercount fix
are both real, both necessary, and address different failure modes; they
were initially conflated as "the candle count problem" when they're not
the same problem.

### Post-Phase-8 fix — the candle undercount, second refinement
Following the prioritization correction above: even after the median-
inflation fix, a real device test still showed a stable ~15% undercount on
a normal chart (53/54 reported against roughly 64-65 estimated). Traced to
two remaining gaps in `splitMergedRuns`: a single fixed 35% tolerance
regardless of merge size, and only one estimate of the typical width ever
computed.

Fixed with two changes. First, tolerance now scales gently with candidate
count (`0.30 + 0.03 * count`, so a 2-candle merge gets ~36% tolerance and a
6-candle merge gets ~48%) — real per-candle pixel noise accumulates across
a longer merged run, so a fixed tolerance was always going to under-serve
larger merges specifically. Second, splitting now runs in two passes: the
first pass roughly triples the number of narrow (likely-genuine-single)
bars available, and the second pass re-estimates the typical width from
that larger, more accurate sample to catch stragglers that didn't fit the
necessarily rougher first-pass estimate. A new test hand-verifies the
scaled-tolerance improvement specifically: a 6-candle merge (64px against
an expected 60px, 10px typical width) that the OLD fixed 0.35 tolerance
would have rejected outright (actual error 4px against a 3.5px cap) now
splits correctly. All four pre-existing splitting tests were individually
re-traced by hand against the two-pass, range-searched logic and confirmed
to produce identical results.

**Still not proven on a real device** — this is reasoned from the
mechanism (accumulated pixel noise needing proportional tolerance) and
verified against synthetic test fixtures, not confirmed against the exact
device data that motivated it, since that would need the `Detection:` debug
line from a real session showing the specific `raw`/`split`/`typW` numbers.

### Post-Phase-8 diagnostic — the two-pass split fix wasn't the cause, more evidence needed
The `Detection:` debug line from a real device delivered decisive evidence
for the first time in this investigation: `raw=38, split=38, built=38` on a
chart where 38 was still too low. Nothing merged and nothing was dropped —
`splitMergedRuns` correctly found nothing to split, because there was
nothing merged. The gap is happening at the very first stage,
`classifyColumn`, before clustering ever runs: only 322 of a 1224px-wide
region's columns were classified as candle-colored at all.

Two competing explanations fit that number equally well and require
opposite fixes: either the real gaps between candles are genuinely wide
(in which case 38 might already be correct), or specific candles' actual
rendered pixels aren't matching the bullish/bearish color classifier at
all and are invisible before detection even begins. The math for "genuinely
wide gaps" would require a uniform ~13px gap between every single candle —
but every screenshot across this entire project has shown QX Broker
rendering candles close together, not spaced nearly as far apart as their
own width, which makes the second explanation more likely on inspection —
not confirmed.

Rather than guess between them, added the diagnostic that settles it: median
and maximum gap size between consecutive raw bars. Uniform real spacing
would show both numbers close together and moderately large; missed
candles would show a small median next to a large outlier maximum. One new
test hand-verifies the computation directly (a synthetic case with three
small 4px gaps and one 50px outlier correctly reports median 4, max 50).
Next real step: the actual `gap(med/max)=` numbers from a real device,
which will point at exactly one of the two explanations rather than
requiring another guess.

### Post-Phase-8 finding — the gap diagnostic delivered decisive evidence: real candles are being missed
Three real device screenshots gave three `gap(med/max)` readings: 4px/6px,
4px/18px, and 6px/**162px**. The last one is decisive on its own — a
missing-candle-sized gap 27x the median, nothing close to what real market
spacing would ever produce. This confirms conclusively that candles are
being missed by color classification somewhere on the chart, not that the
count was already correct with genuinely wide real spacing.

What's still unknown is *where*. Added `maxGapPositionPercent`: the
location of the largest gap as a percentage of the region's width, which
distinguishes two different remaining causes — a gap near 0% or 100%
would mean the region boundary is clipping real candles at an edge, while
a gap in the middle would mean something is interfering with detection at
that specific spot instead (a candidate worth naming honestly: the
broker's own horizontal current-price reference line, visible crossing
directly through the candles in every one of the screenshots that
motivated this). The existing gap regression test now also asserts the
computed position for its known synthetic gap location, verified by hand
(19px into a 120px region = 15%).

### Post-Phase-8 rewrite — replacing splitMergedRuns with pitch-based segmentation, and a stability fix
Five more real screenshots delivered the decisive evidence the gap
diagnostic was built to find, and it wasn't what any prior round assumed:
`raw=7 → split=138` on one chart. `splitMergedRuns` wasn't undercounting
anymore — it was fabricating candles wholesale, because it estimated a
"typical candle width" from the very bars `clusterIntoBars` had already
badly under-segmented (7 bars where roughly 40 candles existed), making
the estimate itself meaningless.

Deleted `splitMergedRuns` and `estimateTypicalWidth` entirely rather than
patching a third time. Replaced with `CandlePitchEstimator` +
`segmentByPitch`: pitch (the fixed start-to-start interval real
candlestick charts render at) is measured from the DISTANCE BETWEEN bar
starts, not from bar widths — a merged run contributes a clean multiple of
the true pitch to that measurement rather than corrupting it, which is
exactly what made the old width-based estimate fail. Critically, when
fewer than 2 bars exist to measure a pitch from, or the estimate fails a
sanity check (implausibly small, or narrower than a typical candle body),
segmentation is skipped entirely — bars are left exactly as
`clusterIntoBars` produced them. No fallback guess, because guessing is
what caused the fabrication in the first place. Three new
`CandlePitchEstimator` and three new `CandleDetector` tests hand-verify
this, including the exact real-device shape (a run of touching same-
colored candles resolving correctly at a measured 12px pitch) and the
exact failure this replaces (too few bars to measure a pitch, confirmed to
leave a single merged run as one candle rather than fabricating many).

**A second, unrelated fix requested explicitly in the same round**: "no
chart detected" was flashing frequently and abruptly during ordinary
zooming. Traced to something that had nothing to do with detection
accuracy at all — `ChartStructureValidator` rejecting a single transient
bad frame (a capture mid-zoom-transition) immediately flipped the whole UI
to rejected, with zero tolerance and no memory of the previous good state.
Fixed with `StructuralRejectionDebouncer`: a rejection is only actually
surfaced after 3 consecutive bad frames; anything shorter coasts on the
last known-good `AnalysisFrame` (timestamp updated, nothing fabricated —
it's a genuine result from a recent earlier frame) instead of flashing a
false alarm. A real, sustained "you're not looking at a chart" situation
still surfaces within a few frames, unaffected by this.

### Post-Phase-8 fix — overlay decluttered, and a real backwards-icon bug
Direct user feedback: the overlay "feels cluttered," plus a specific arrow-
icon issue. Both real, both fixed.

The icon: the expand/collapse chevron had the standard convention
backwards — it showed a down-arrow while already expanded and an up-arrow
while collapsed, rather than down-while-collapsed ("tap to open") and
up-while-expanded ("tap to close"). Not a style choice, an actual
inversion of what every other expand/collapse control does. Swapped.

The clutter: `AnalysisStatusLine` (the expanded overlay's detail view) had
accumulated, across many rounds of debugging this session, the raw
`Detection:` breakdown line (`cols=X raw=Y split=Z built=W pitch=Npx
gap=...`), candle counts, region confidence, price-mapping percentages,
timeframe, and RSI — every one of them a genuine debugging aid added to
diagnose the candle-count investigation, none of them something a trader
glancing at a floating overlay mid-session actually needs. All of it
already exists in full on the Dashboard's Chart Analysis panel, which is
where it belongs — a dedicated screen for diagnostics, not an always-
visible overlay. Trimmed the overlay down to exactly what changes a
trading decision: whether a chart was found at all, the prediction itself
(direction, confidence, or the NO_TRADE reason in plain language), and the
directional lean when applicable. Also fixed while touching this code: the
NO_TRADE reason wording (`readableLabel()`) was duplicated between the
Dashboard and the overlay — a real risk of the two silently drifting out
of sync — now lives once, as a shared extension on `NoTradeReason` itself,
imported by both.

### Post-Phase-8 addition — start/stop control from the overlay itself
Direct user request: be able to start analysis from the overlay, not just
stop it. This is a real behavior change to the overlay's lifecycle, not
just a new button — previously, stopping analysis and the overlay window
disappearing were the same action (`onStopRequested()` called both
`ScreenCaptureService.stop()` and `stopSelf()`). Since MediaProjection
consent can only be requested from an Activity (never from a bare
Service), a genuine "Start" action requires launching `MainActivity`, and
that only makes sense if the overlay survives long enough afterward to
show the result — so stopping no longer closes the overlay window.

`OverlayService.onStartRequested()` launches `MainActivity` with a new
`EXTRA_AUTO_START` intent extra; `MainActivity` re-runs the exact same
permission chain (notifications → overlay → MediaProjection) a normal
manual start already uses, handled in both `onCreate` (fresh launch) and
`onNewIntent` (the Activity is `launchMode="singleTop"`, so a second
launch while already on top arrives there instead) — not a separate,
less-tested path. The extra is explicitly consumed (`removeExtra`)
immediately after being read in both places, since otherwise an Activity
recreation (a rotation, a process restart) holding the same Intent object
would see the flag still set and silently re-trigger the whole permission
flow again.

Since stopping no longer implies closing, the header now shows different
icons depending on state: a single Stop (✕) while capturing, or both a
Start (▶) and a genuinely separate Close (✕) while not — two distinct
actions with two distinct icons, so neither is mistaken for the other.
`MainActivity`'s own `stopAnalysis()` (the Dashboard's stop button) was
updated to match — it no longer calls `OverlayService.stop()` either, for
the same reason: stopping analysis from any surface should leave the
overlay exactly where the user positioned it, not force them to reopen
and redrag it for the next session.

### Post-Phase-8 fix — every build required an uninstall first, unrelated to any app code
Direct user report: every new debug APK required uninstalling the previous
one first, rather than updating in place. Nothing to do with the app's own
code — this project had no committed keystore and no explicit
`signingConfigs` block, meaning every build relied on whatever
`~/.android/debug.keystore` happened to exist on the machine running
Gradle. A fresh GitHub Actions runner has no such file, so Android Gradle
Plugin auto-generates a brand-new, randomly-signed one on every single CI
run — every build was effectively signed by a different key, and Android
correctly refuses to install an update over an app signed with a
different certificate than the one already installed.

Fixed by generating one fixed debug keystore (standard convention: alias
`androiddebugkey`, password `android` for both store and key, valid until
2054 — the same defaults Android Studio's own auto-generated debug
keystore has always used) and committing it at `keystore/debug.keystore`,
referenced explicitly in `app/build.gradle.kts`'s new `signingConfigs`
block so every build, on any machine, signs with the same key going
forward. A real, easy-to-miss trap avoided along the way: this repo's
`.gitignore` had a broad `*.keystore` rule (correctly protecting a real
release signing key, which genuinely is a secret) that would have
silently excluded this file from ever being committed had it not been
given an explicit exception — verified directly with `git check-ignore`
and a real `git add`, not just assumed from reading the pattern.

### Post-Phase-8 reversal — the overlay decluttering was partially undone
A follow-up request reverted the information-trimming part of the earlier
decluttering pass: `AnalysisStatusLine`'s expanded view once again shows
full detail (candle counts, region confidence, the raw `Detection:`
breakdown, price-mapping percentages, timeframe, RSI), not the minimal
prediction-only version. The expand/collapse arrow-direction fix from that
same original pass was explicitly kept, since it was a correctness bug
(the icon was genuinely backwards), not a content decision — and
everything from the two rounds since (start/stop control from the
overlay, the debug-keystore fix) was left untouched, since the request
was scoped specifically to the decluttering content.

Worth recording plainly: the request that triggered this ("revert these
changes") was ambiguous on its own — it could have meant undoing any of
three different recent changes. Rather than guess, the ambiguity was
named directly and the user was asked which was meant; "redo everything
except decluttering changes" was the answer, interpreted as keep the
icon fix and the two later rounds, revert only the information removal.
Restoring the removed content required care beyond a simple copy-paste of
the old version, since the start/stop-control changes had been layered on
top of the same function in the meantime — the two changes were merged by
hand rather than one silently overwriting the other.

### Post-Phase-8 addition — pause/resume, so resuming from the overlay no longer re-triggers consent
Direct user report: resuming from the overlay always re-opened the full
"Share your screen with ChartLens AI?" MediaProjection consent screen,
every single time. This is a hard Android requirement, not a bug in this
app — starting a genuinely NEW screen-capture session always needs fresh
consent, no app can skip or pre-fill that dialog. But the actual fix isn't
to work around Android's consent requirement (impossible) — it's to stop
treating every resume as a new session at all.

Added `CaptureState.Paused`, a new state distinct from `Stopped`: analysis
stops (no CPU work, no predictions, nothing written to the journal), but
the `MediaProjection` grant itself is deliberately kept alive rather than
released, so a later Resume can reuse it directly with zero dialog. The
mechanism already existed in this codebase for a different reason —
`onConfigurationChanged` (handling screen rotation) already tears down and
recreates just the `VirtualDisplay`/`ImageReader` while reusing the same
`MediaProjection` instance, since Android allows multiple
`createVirtualDisplay()` calls against one still-valid grant. Pause/resume
reuses that exact same proven pattern rather than inventing a new one:
`beginCaptureLoop()` was extracted as the shared "actually start
capturing" logic, called from both a genuinely fresh grant
(`startCaptureSession`) and a reused one (`handleResume`).

**The real, explicit tradeoff, accepted directly rather than hidden**:
Android requires a persistent, visible indicator for the entire duration
any app holds a live `MediaProjection` grant, whether or not anything is
actively being captured. So while Paused, the system's screen-recording
indicator and this app's own foreground notification both stay visible —
there is no way to suppress this, and pretending otherwise would be
dishonest about what "paused but still granted" actually means to
Android. The notification's own action button and text change to reflect
this (`Resume` instead of `Stop Analysis`, "screen access is still
granted" instead of "analysis running") so it's honest about state rather
than looking identical to actively capturing.

A genuine full stop — releasing the grant, clearing the indicator for
real — now only happens via the overlay's explicit Dismiss action, or
Android's own system-level "stop sharing" control (already correctly
handled via the existing `onProjectionLost()` → full `handleStop()`
path, unchanged). Both the overlay's Stop and the Dashboard's "Stop
Analysis" now pause rather than fully stop — kept deliberately consistent
between the two surfaces rather than the same button label meaning two
different things depending on which screen triggered it. The Dashboard
gained a genuine third button state (`Resume Analysis`, calling
`ScreenCaptureService.resume()` directly) rather than folding Paused into
the existing Start button, specifically so tapping it can never
accidentally re-trigger the full permission chain when an instant resume
was available. Since `CaptureState` is a sealed interface, adding `Paused`
required updating every exhaustive `when` over it or the build would not
compile — found and updated all three (both overlay status-line
composables, and the Dashboard's status card) by direct search rather than
trusting memory of where they all were.

## 3. Project structure


```
app/src/main/java/com/chartlens/ai/
  common/            ColorMath, PixelBuffer, CaptureState(+Repository), LatestFrameHolder
  capture/           CapturedFrame, FrameChangeDetector, ScreenCaptureController
  service/           ScreenCaptureService
  overlay/           OverlayService, OverlayLifecycleOwner
  ui/                MainActivity, MainViewModel, DashboardScreen,
                      ChartRegionSelectionScreen, AiSettingsScreen, JournalScreen, ReplayScreen
  cv/                CandleColorProfile, ChartRegion, ChartDetector, FrameAnalyzer,
                      ViewShiftDetector, RegionRediscoveryPolicy, StructuralRejectionDebouncer
  candle/            Candle, CandleDetector, CandlePattern(+Detector),
                      CandleDetectionDebug, ChartStructureValidator, CandlePitchEstimator
  settings/          NormalizedRect, ManualChartRegionStore, AiBackendSettingsStore
  ocr/               OcrTextBlock, OcrEngine, OcrDebugInfo, PriceTextParser, TimeTextParser
  indicators/        EMA, RSI, MACD, ATR, BollingerBands
  analysis/          PriceCandle, DataQuality, AnalysisFrame(+Repository),
                      PriceScaleMapper(+Mapping), TimeframeDetector, CandleCloseTracker,
                      TrendAnalyzer, MomentumAnalyzer, SupportResistanceAnalyzer,
                      TechnicalAnalysisEngine, CandleHistoryMerger, NewCandleFinder,
                      ChartStructurePatternDetector
  prediction/        PredictionEngine, PredictionModels, PredictionWeights, LastCandleContext,
                      PredictionOutcome, OutcomeEvaluator
  ai/                AiAnalysisRequest/Response, AiAnalysisProvider(+Remote impl),
                      AiAnalysisApi, AiRequestMapper, AiTriggerPolicy, AiResponseValidator,
                      AiInsight(+Repository), AiInsightCoordinator, AiModule
  database/          PredictionEntity, PredictionDao, CandleHistoryEntity, CandleHistoryDao,
                      ChartLensDatabase, DatabaseModule, PredictionJournalRepository,
                      CandleHistoryRepository
  analytics/         AccuracyBucket, AccuracyStats, AccuracyAnalytics
  journal/           JournalCoordinator
  replay/            CandleHistoryRecorder, ReplayEngine, ReplayResult/ReplayStep
backend/             Node/Express reference AI backend (separate deployment target)
```

## 4. Configuring the build

- **Gradle wrapper**: pinned to Gradle 8.9 in `gradle/wrapper/`, jar not
  checked in — open in Android Studio or run `gradle wrapper --gradle-version
  8.9` once.
- **`gradle.properties`** must include `android.useAndroidX=true` (a real
  early build failure without it).
- **OpenCV**: not a dependency — see Phase 2's architecture note above.
- **ML Kit text recognition** is active (Phase 3's OCR).
- **`retrofit2-kotlinx-serialization-converter`**: declared since Phase 1,
  first actually exercised by Phase 6's code — see the risk note in section 1.
- **KSP/Kotlin pairing**: `2.0.20-1.0.24` — verify against
  https://github.com/google/ksp/releases if bumping Kotlin.
- **AI backend**: not configured by default — see section 6.

## 5. How to build / install

```
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 6. Configuring the AI backend (Phase 6, optional)

The app works fully without this — Phase 5's local prediction engine never
depends on it. To get AI-written explanations on top of a BULLISH/BEARISH
prediction:

1. Deploy `/backend` yourself — see `backend/README.md` for step-by-step
   instructions (Render/Railway/Fly.io free tiers all work).
2. Set `ANTHROPIC_API_KEY` and `CLIENT_AUTH_TOKEN` as environment variables
   on your hosting platform — never in the app, never committed to source.
3. In the app: **AI Backend Settings** → enter your backend's URL and the
   same auth token → Save.

## 7. Permissions required

`SYSTEM_ALERT_WINDOW`, `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PROJECTION`,
`POST_NOTIFICATIONS`, `INTERNET`/`ACCESS_NETWORK_STATE` (now actually used, by
Phase 6's AI backend calls). ML Kit OCR runs fully on-device — no network
permission needed for it specifically.

## 8. Known limitations

- **Phase 6's backend has never been run.** See section 1's caveat — real,
  complete, hand-reviewed source code, genuinely unverified until deployed.
- **No instrument-name detection.** `AiRequestMapper` sends `instrument:
  "Unknown"` — there's no OCR pass reading the instrument label (e.g.
  "AUD/USD (OTC)") anywhere in the pipeline yet. Honest gap, not fabricated.
- **Phase 3's OCR crop/parsing logic has been tuned against real device
  testing across ~6 rounds of bugs (see section 2) but only on a handful of
  actual layouts.** Confidence is much higher than earlier phases, but
  "robust across every possible trading app layout" hasn't been proven.
- **Manual chart selection is global, not per-app.**
- **No accessibility-service-based foreground-app detection.**
- **Phase 5's weights/thresholds are reasonable defaults, not calibrated**
  — real calibration needs Phase 7's outcome journal, which doesn't exist yet.
- **No real candle timestamps** (`PriceCandle.timestampMillis` stays null) —
  deriving one needs a reference wall-clock anchor OCR doesn't reliably give.

## 9. Tests performed

**Phases 1-4:** `FrameChangeDetectorTest` (6), `CandleDetectorTest` (10, 7
core geometry tests plus 3 regression tests for pitch-based segmentation —
see the post-Phase-8 rewrite section above; the tests for the deleted
splitMergedRuns approach were removed along with the code they tested,
not left stale), `CandlePitchEstimatorTest` (6), `ChartStructureValidatorTest` (8, including the exact text-
conversation scenario that motivated it),
`ChartDetectorTest` (5, including the vertical-bounds regression test),
`CandlePatternDetectorTest` (7), `EMATest`/`RSITest`/`ATRTest`/
`BollingerBandsTest`/`MACDTest` (18 total), `TrendAnalyzerTest`/
`MomentumAnalyzerTest`/`SupportResistanceAnalyzerTest` (13 total).

**Phase 3:** `PriceTextParserTest` (8, including regressions for the bare-
integer and comma-grouping bugs), `TimeTextParserTest` (6, including the
countdown-timer regression), `PriceScaleMapperTest` (9), `TimeframeDetectorTest`
(6, including regressions for the outlier-removal and median-spacing bugs), `CandleCloseTrackerTest` (5), `DataQualityCalculatorTest` (5).

**Phase 5:** `PredictionEngineTest` (13) — a hand-computed baseline scenario
plus one isolated test per NO_TRADE gate, plus regression tests for the
DirectionalLean addition and the support/resistance applicability fix
(see the post-Phase-8 discussion above).

**Phase 6 (new, all pure Kotlin):**
- `AiResponseValidatorTest` (12): well-formed acceptance, invalid bias/
  confidence/dataQuality rejection, empty/oversized reasoning rejection,
  the NO_CLEAR_SETUP-with-high-confidence inconsistency check, and — the
  most important set — a real known level accepted, a fabricated level
  rejected, and a level rejected outright when the request supplied none
- `AiTriggerPolicyTest` (6): fires on a fresh close with a real prediction,
  correctly withholds for no-close/NO_TRADE/missing-technical-analysis/
  already-triggered-candle cases, fires again for a genuinely new candle
- `AiRequestMapperTest` (7): null-propagation when data is missing, correct
  field mapping, pattern-to-string joining (including the empty-set →
  null-not-empty-string case), EMA alignment description correctness

`OcrEngine`, `RemoteAiAnalysisProvider`, and the rest of the Android
network/ML-Kit boundary remain reviewed-by-hand rather than unit tested —
same boundary as every other phase's un-testable-here classes. The backend
itself (`/backend`) has no test suite — see section 1's caveat.

**Phase 7 (new, all pure Kotlin):**
- `OutcomeEvaluatorTest` (7): WIN/LOSS correctness for both UP and DOWN
  predictions, the neutral-zone threshold, NO_TRADE always invalid, a
  zero/negative entry price handled as invalid data rather than a crash
- `AccuracyAnalyticsTest` (13): empty-journal handling, accuracy computed
  only from decisive outcomes (neutral/invalid don't dilute it), unresolved
  entries counted in totals but excluded from accuracy, the edge-claim gate
  at exactly the minimum threshold, current streak computed correctly
  regardless of input ordering (a scrambled-order test confirms the
  function sorts internally rather than trusting the caller), a losing
  streak represented as negative, max win/loss streaks found across a mixed
  history, per-instrument/confidence-bucket bucketing correctness, a null
  setup bucketed under "unknown" rather than crashing

`PredictionDao`/`ChartLensDatabase` (real Room, needs an instrumented test
or a device to exercise) and `JournalCoordinator`'s Android/coroutine
wiring remain reviewed-by-hand — same boundary as always. `PredictionEntity`
itself, despite its Room annotations, is a plain data class and is directly
usable in the pure-Kotlin analytics tests above without any database.

**Phase 8 (new, all pure Kotlin):**
- `ReplayEngineTest` (4) — the centerpiece is the look-ahead-bias test:
  replays two histories identical up to index 39 and diverging sharply
  after it, asserting every prediction at or before that point is identical
  between the two runs. Also: too-few-candles produces zero steps, replay
  stops rather than guessing when there's no future candle to evaluate
  against, and the accuracy stats account for exactly the steps produced.
  See section 1's honesty note on this test's synthetic price data — the
  look-ahead-bias *guarantee* is structural (enforced by `subList(0, i+1)`
  in the engine itself) regardless of whether the test data reliably
  triggers it, but the test's ability to *demonstrate* that guarantee
  depends on producing at least one real prediction to compare, which is a
  reasoned expectation rather than a confirmed one.

`CandleHistoryDao` and `CandleHistoryRecorder`'s Android/coroutine wiring
remain reviewed-by-hand — same boundary as always.

**Post-Phase-8 fix:**
- `ViewShiftDetectorTest` (6): no shift reported on the first frame (nothing
  to compare against), a stable overlapping range across frames is not a
  shift, a large non-overlapping jump is, the comparison stays correct even
  when the region's own top offset changes between frames (not just the
  candle geometry), only-forming-candles is treated as no data rather than
  a false shift, and `reset()` correctly clears prior state.
- `RegionRediscoveryPolicyTest` (6): no cached region always rediscovers, a
  healthy region within its interval is reused, the normal interval still
  forces rediscovery, a region that stopped producing candles is
  re-detected immediately (the actual undercount bug), a region is never
  judged by the frame it was detected on, and a count at the threshold
  doesn't trigger unnecessary rediscovery.
- `StructuralRejectionDebouncerTest` (6): a valid frame is never surfaced
  as a rejection, one or two isolated bad frames are coasted through
  (the actual real-device complaint this fixes), a sustained run of 3+
  surfaces, rejections keep surfacing for as long as the failure
  continues, a single good frame mid-run resets the count so a fresh run
  needs the full threshold again, and `reset()` clears an in-progress run.
- `CandleHistoryMergerTest` (5): no recorded history falls back to on-
  screen candles as-is, no current-frame candles returns history unchanged,
  a genuinely new closed candle gets appended, an already-recorded candle
  is not appended twice, and a tiny floating-point difference in the same
  candle's close still correctly counts as "already represented" rather
  than a false new-candle detection.
- `NewCandleFinderTest` (7): every candle is new with no prior state,
  nothing is new with no currently-visible candles, normal one-at-a-time
  progression finds exactly the single new candle, a catch-up scroll
  revealing several missed closes backfills all of them at once (the
  actual bug this was built for), nothing new returns empty rather than
  re-recording, a last-recorded price not found anywhere visible falls
  back to treating the whole window as new, and a repeated price level
  correctly anchors to the most recent occurrence rather than the first.
- `ChartStructurePatternDetectorTest` (13): a clean, hand-verified match
  per pattern type (double top/bottom, head & shoulders and its inverse,
  all three triangle types), plus rejection cases — peaks too far apart,
  no valley between them, insufficient time separation, a "head" that
  isn't actually higher than its shoulders, too few swing points, both
  lines flat (no triangle), and no swing data at all.

## 10. Remaining work (next phases)

- **Phase 9** — Battery/performance tuning, accessibility, polish. The last
  phase.

**Recommended immediate next step**: run `ReplayEngineTest` in CI/Android
Studio and confirm the look-ahead-bias test actually produces comparable
steps rather than an empty (vacuous) pass — this is the one thing in Phase 8
I flagged as a reasoned-but-unconfirmed risk rather than a verified fact.
Separately, on a real device: run a live session long enough to record
candle history, then open Replay / Backtest and confirm a session actually
appears and produces sensible results — Phase 8 has had no real-device
verification at all yet, same as Phase 7 before its first test and Phase 6
still today. Also still outstanding: deploying `/backend` and confirming
Phase 6 actually works end-to-end — it remains the one piece in this whole
project with zero real-environment verification of any kind.
