# Hilt / Dagger generated code is annotation-driven; keep generated components.
-keep class dagger.hilt.internal.aggregatedroot.codegen.** { *; }
-keep class hilt_aggregated_deps.** { *; }
-keep,allowobfuscation @interface dagger.hilt.android.lifecycle.HiltViewModel

# Room entities/DAOs referenced via generated code (added ahead of Phase 7 Room work).
-keep class androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class **$$serializer {
    *** INSTANCE;
}
