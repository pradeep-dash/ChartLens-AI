package com.chartlens.ai.ocr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimeTextParserTest {

    @Test
    fun `parses a standard HH-mm label`() {
        assertEquals(21 * 60 + 36, TimeTextParser.parseMinutesSinceMidnight("21:36"))
    }

    @Test
    fun `parses a single-digit hour`() {
        assertEquals(9 * 60 + 5, TimeTextParser.parseMinutesSinceMidnight("9:05"))
    }

    @Test
    fun `rejects an out-of-range hour`() {
        assertNull(TimeTextParser.parseMinutesSinceMidnight("25:00"))
    }

    @Test
    fun `rejects an out-of-range minute`() {
        assertNull(TimeTextParser.parseMinutesSinceMidnight("12:75"))
    }

    @Test
    fun `text with no time pattern returns null`() {
        assertNull(TimeTextParser.parseMinutesSinceMidnight("Beginning of trade"))
    }
}
