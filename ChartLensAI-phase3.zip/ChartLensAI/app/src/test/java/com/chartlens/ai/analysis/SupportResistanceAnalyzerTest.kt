package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SupportResistanceAnalyzerTest {

    private val analyzer = SupportResistanceAnalyzer()

    private fun candle(index: Int, high: Double, low: Double, close: Double) =
        PriceCandle(index, null, open = close, high = high, low = low, close = close)

    @Test
    fun `repeated touches near the same price cluster into one level with a touch count`() {
        // Two swing highs close together (~120 and ~120.1, within the default 0.15%
        // cluster tolerance), each confirmed via the fractal method (2 candles lower
        // on both sides). Padding candles after the second high ensure it still has
        // its full confirmation window even after analyze() drops the latest candle.
        val candles = listOf(
            candle(0, 110.0, 108.0, 109.0),
            candle(1, 115.0, 112.0, 113.0),
            candle(2, 120.0, 118.0, 119.0),   // swing high #1 (~120)
            candle(3, 116.0, 113.0, 114.0),
            candle(4, 111.0, 108.0, 109.0),
            candle(5, 114.0, 111.0, 112.0),
            candle(6, 118.0, 115.0, 116.0),
            candle(7, 120.1, 118.0, 119.0),   // swing high #2 (~120.1, clusters with #1)
            candle(8, 115.0, 112.0, 113.0),
            candle(9, 110.0, 107.0, 108.0),
            candle(10, 108.0, 105.0, 106.0),  // padding so #2 keeps its trailing window
            candle(11, 107.0, 104.0, 105.0)   // becomes "latest" candle, dropped for level detection
        )
        val result = analyzer.analyze(candles)

        val clustered = result.resistanceLevels.firstOrNull { it.touchCount >= 2 }
        assertTrue("expected the two nearby highs to cluster into one level", clustered != null)
    }

    @Test
    fun `closing above the nearest resistance level is a breakout`() {
        val priorCandles = listOf(
            candle(0, 110.0, 108.0, 109.0),
            candle(1, 115.0, 112.0, 113.0),
            candle(2, 120.0, 118.0, 119.0), // swing high (~120)
            candle(3, 116.0, 113.0, 114.0),
            candle(4, 111.0, 108.0, 109.0)
        )
        val breakoutCandle = candle(5, 126.0, 119.0, 125.0) // closes well above 120
        val result = analyzer.analyze(priorCandles + breakoutCandle)

        assertEquals(BreakoutStatus.BROKE_ABOVE_RESISTANCE, result.breakoutStatus)
    }

    @Test
    fun `wicking above resistance but closing back below it is a rejection`() {
        val priorCandles = listOf(
            candle(0, 110.0, 108.0, 109.0),
            candle(1, 115.0, 112.0, 113.0),
            candle(2, 120.0, 118.0, 119.0), // swing high (~120)
            candle(3, 116.0, 113.0, 114.0),
            candle(4, 111.0, 108.0, 109.0)
        )
        val rejectionCandle = candle(5, 121.0, 115.0, 116.0) // wicks to 121, closes back at 116
        val result = analyzer.analyze(priorCandles + rejectionCandle)

        assertEquals(RejectionStatus.REJECTED_AT_RESISTANCE, result.rejectionStatus)
    }

    @Test
    fun `an empty candle list produces no levels and no breakout or rejection`() {
        val result = analyzer.analyze(emptyList())
        assertEquals(BreakoutStatus.NONE, result.breakoutStatus)
        assertEquals(RejectionStatus.NONE, result.rejectionStatus)
        assertTrue(result.supportLevels.isEmpty())
        assertTrue(result.resistanceLevels.isEmpty())
    }
}
