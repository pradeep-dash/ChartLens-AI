package com.chartlens.ai.indicators

import com.chartlens.ai.analysis.PriceCandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ATRTest {

    private fun candle(index: Int, high: Double, low: Double, close: Double) =
        PriceCandle(index, null, open = close, high = high, low = low, close = close)

    @Test
    fun `returns null before enough history exists`() {
        val candles = (0..5).map { candle(it, 105.0, 95.0, 100.0) }
        assertEquals(List(candles.size) { null }, ATR.calculate(candles, period = 14))
    }

    @Test
    fun `a constant true range produces an ATR exactly equal to that range`() {
        // high-low = 10 for every candle, close stays within range so no gap ever
        // dominates the true-range calculation -> ATR should settle exactly at 10.
        val candles = (0..20).map { candle(it, 105.0, 95.0, 100.0) }
        val result = ATR.calculate(candles, period = 14)

        assertEquals(10.0, result[14]!!, 1e-9)
        assertEquals(10.0, result[20]!!, 1e-9)
    }

    @Test
    fun `a sudden gap increases ATR`() {
        val base = (0..14).map { candle(it, 105.0, 95.0, 100.0) }
        // A large gap up on the next candle: true range now includes |high - prevClose|.
        val gapped = base + candle(15, 150.0, 145.0, 148.0)
        val result = ATR.calculate(gapped, period = 14)

        val beforeGap = result[14]!!
        val afterGap = result[15]!!
        assertTrue("ATR should rise after a volatility spike", afterGap > beforeGap)
    }
}
