package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDirection
import com.chartlens.ai.ocr.OcrTextBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TimeframeDetectorTest {

    private val detector = TimeframeDetector()

    private fun candle(index: Int, xStart: Int, isForming: Boolean = false) = Candle(
        index = index,
        xStart = xStart,
        xEnd = xStart + 20,
        bodyTopY = 10,
        bodyBottomY = 20,
        wickTopY = 5,
        wickBottomY = 25,
        direction = CandleDirection.BULLISH,
        isForming = isForming,
        confidence = 1f
    )

    @Test
    fun `matching pixel spacing to a known interval detects the timeframe exactly`() {
        // 0.02 minutes per pixel (10:00 at x=0, 10:10 at x=500), candles spaced exactly
        // 50px apart -> 0.02 * 50 = 1.0 minute per candle -> exact M1 match.
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val candles = listOf(
            candle(0, xStart = 0),
            candle(1, xStart = 50),
            candle(2, xStart = 100),
            candle(3, xStart = 150),
            candle(4, xStart = 200, isForming = true)
        )

        val result = detector.detect(timeLabels, candles)

        assertEquals(Timeframe.M1, result.timeframe)
        assertEquals(1.0, result.estimatedMinutesPerCandle!!, 1e-6)
    }

    @Test
    fun `an estimate that falls between two known intervals returns null timeframe but keeps the estimate`() {
        // Same 0.02 min/px, candles spaced 150px apart -> 3.0 min/candle, which is too
        // far from both M1 and M5 to confidently snap to either.
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val candles = listOf(
            candle(0, xStart = 0),
            candle(1, xStart = 150),
            candle(2, xStart = 300),
            candle(3, xStart = 450, isForming = true)
        )

        val result = detector.detect(timeLabels, candles)

        assertNull(result.timeframe)
        assertNotNull("the estimate should still be surfaced even when unmatched", result.estimatedMinutesPerCandle)
        assertEquals(3.0, result.estimatedMinutesPerCandle!!, 1e-6)
    }

    @Test
    fun `fewer than two time labels yields no result`() {
        val candles = listOf(candle(0, 0), candle(1, 50), candle(2, 100, isForming = true))
        val result = detector.detect(listOf(OcrTextBlock("10:00", 0, 0)), candles)
        assertNull(result.timeframe)
        assertNull(result.estimatedMinutesPerCandle)
    }

    @Test
    fun `fewer than two closed candles yields no result`() {
        val timeLabels = listOf(
            OcrTextBlock("10:00", centerX = 0, centerY = 0),
            OcrTextBlock("10:10", centerX = 500, centerY = 0)
        )
        val result = detector.detect(timeLabels, listOf(candle(0, 0, isForming = true)))
        assertNull(result.timeframe)
    }
}
