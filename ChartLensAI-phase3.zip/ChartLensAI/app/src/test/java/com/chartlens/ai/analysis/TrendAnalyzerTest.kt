package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Test

class TrendAnalyzerTest {

    private val analyzer = TrendAnalyzer()

    private fun flatCandle(index: Int, price: Double) =
        PriceCandle(index, null, price, price, price, price)

    /** A zigzag where each rally goes higher than the last and each pullback low is
     * also higher than the last — classic higher-highs/higher-lows uptrend structure. */
    private fun buildZigzagUptrend(): List<PriceCandle> {
        val prices = mutableListOf<Double>()
        var base = 100.0
        repeat(5) { leg ->
            val upStep = 10.0 + leg * 2
            prices += base + upStep * 0.33
            prices += base + upStep * 0.66
            prices += base + upStep
            base += upStep
            val downStep = 4.0
            prices += base - downStep * 0.33
            prices += base - downStep * 0.66
            prices += base - downStep
            base -= downStep
        }
        return prices.mapIndexed { i, p -> flatCandle(i, p) }
    }

    /** Mirror image of the uptrend builder — lower highs, lower lows. */
    private fun buildZigzagDowntrend(): List<PriceCandle> {
        val prices = mutableListOf<Double>()
        var base = 200.0
        repeat(5) { leg ->
            val downStep = 10.0 + leg * 2
            prices += base - downStep * 0.33
            prices += base - downStep * 0.66
            prices += base - downStep
            base -= downStep
            val upStep = 4.0
            prices += base + upStep * 0.33
            prices += base + upStep * 0.66
            prices += base + upStep
            base += upStep
        }
        return prices.mapIndexed { i, p -> flatCandle(i, p) }
    }

    @Test
    fun `a rising zigzag with higher highs and higher lows is classified as an uptrend`() {
        val result = analyzer.analyze(buildZigzagUptrend())
        assertEquals(Trend.UPTREND, result.trend)
    }

    @Test
    fun `a falling zigzag with lower highs and lower lows is classified as a downtrend`() {
        val result = analyzer.analyze(buildZigzagDowntrend())
        assertEquals(Trend.DOWNTREND, result.trend)
    }

    @Test
    fun `a perfectly flat price series has no confirmable swings`() {
        val candles = (0..20).map { flatCandle(it, 100.0) }
        val result = analyzer.analyze(candles)
        assertEquals(Trend.UNKNOWN, result.trend)
    }

    @Test
    fun `too few candles to confirm swings is UNKNOWN, not a guess`() {
        val candles = (0..3).map { flatCandle(it, 100.0 + it) }
        val result = analyzer.analyze(candles)
        assertEquals(Trend.UNKNOWN, result.trend)
    }
}
