package com.chartlens.ai.candle

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CandlePatternDetectorTest {

    private val detector = CandlePatternDetector()

    private fun candle(
        index: Int,
        bodyTopY: Int,
        bodyBottomY: Int,
        wickTopY: Int,
        wickBottomY: Int,
        direction: CandleDirection,
        isForming: Boolean = false
    ) = Candle(
        index = index,
        xStart = index * 10,
        xEnd = index * 10 + 5,
        bodyTopY = bodyTopY,
        bodyBottomY = bodyBottomY,
        wickTopY = wickTopY,
        wickBottomY = wickBottomY,
        direction = direction,
        isForming = isForming,
        confidence = 1f
    )

    @Test
    fun `a candle with a tiny body relative to its range is flagged as doji`() {
        val doji = candle(0, bodyTopY = 48, bodyBottomY = 52, wickTopY = 0, wickBottomY = 100, direction = CandleDirection.BULLISH)

        val result = detector.detect(listOf(doji)).single()

        assertTrue(result.patterns.contains(CandlePattern.DOJI))
        assertFalse(result.patterns.contains(CandlePattern.HAMMER))
    }

    @Test
    fun `a small body near the top with a long lower wick is flagged as a hammer shape`() {
        // range = wickTop(40)..wickBottom(100) = 60. body = 40..50 (height 10, ratio 0.167).
        // upper wick = 0 (negligible). lower wick = 50 (ratio 0.833, >= 2x body height).
        val hammer = candle(0, bodyTopY = 40, bodyBottomY = 50, wickTopY = 40, wickBottomY = 100, direction = CandleDirection.BULLISH)

        val result = detector.detect(listOf(hammer)).single()

        assertTrue(result.patterns.contains(CandlePattern.HAMMER))
        assertTrue(result.patterns.contains(CandlePattern.LONG_WICK_REJECTION))
        assertFalse(result.patterns.contains(CandlePattern.SPINNING_TOP))
        assertFalse(result.patterns.contains(CandlePattern.DOJI))
    }

    @Test
    fun `a long upper wick on a bearish candle is labeled shooting star`() {
        val shootingStar = candle(0, bodyTopY = 50, bodyBottomY = 60, wickTopY = 0, wickBottomY = 60, direction = CandleDirection.BEARISH)

        val result = detector.detect(listOf(shootingStar)).single()

        assertTrue(result.patterns.contains(CandlePattern.SHOOTING_STAR))
        assertFalse(result.patterns.contains(CandlePattern.INVERTED_HAMMER))
    }

    @Test
    fun `a long upper wick on a bullish candle is labeled inverted hammer`() {
        val invertedHammer = candle(0, bodyTopY = 50, bodyBottomY = 60, wickTopY = 0, wickBottomY = 60, direction = CandleDirection.BULLISH)

        val result = detector.detect(listOf(invertedHammer)).single()

        assertTrue(result.patterns.contains(CandlePattern.INVERTED_HAMMER))
        assertFalse(result.patterns.contains(CandlePattern.SHOOTING_STAR))
    }

    @Test
    fun `a larger opposite-colored body fully containing the previous body is engulfing`() {
        val previous = candle(0, bodyTopY = 40, bodyBottomY = 50, wickTopY = 35, wickBottomY = 55, direction = CandleDirection.BEARISH)
        val current = candle(1, bodyTopY = 35, bodyBottomY = 55, wickTopY = 30, wickBottomY = 60, direction = CandleDirection.BULLISH)

        val results = detector.detect(listOf(previous, current))

        assertTrue(results[1].patterns.contains(CandlePattern.BULLISH_ENGULFING))
        assertFalse(results[0].patterns.contains(CandlePattern.BULLISH_ENGULFING))
    }

    @Test
    fun `a candle fully within the previous candle's range is an inside bar`() {
        val previous = candle(0, bodyTopY = 20, bodyBottomY = 80, wickTopY = 10, wickBottomY = 90, direction = CandleDirection.BULLISH)
        val current = candle(1, bodyTopY = 40, bodyBottomY = 60, wickTopY = 30, wickBottomY = 70, direction = CandleDirection.BEARISH)

        val results = detector.detect(listOf(previous, current))

        assertTrue(results[1].patterns.contains(CandlePattern.INSIDE_BAR))
    }

    @Test
    fun `a large body with small wicks well above the average is strong momentum`() {
        val fillers = (0..2).map {
            candle(it, bodyTopY = 40, bodyBottomY = 50, wickTopY = 38, wickBottomY = 52, direction = CandleDirection.BULLISH)
        }
        val strongCandle = candle(3, bodyTopY = 20, bodyBottomY = 50, wickTopY = 18, wickBottomY = 52, direction = CandleDirection.BULLISH)

        val results = detector.detect(fillers + strongCandle)

        assertTrue(results.last().patterns.contains(CandlePattern.STRONG_MOMENTUM))
    }
}
