package com.chartlens.ai.indicators

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RSITest {

    @Test
    fun `returns null before enough history exists`() {
        val result = RSI.calculate(listOf(1.0, 2.0, 3.0), period = 14)
        assertEquals(listOf(null, null, null), result)
    }

    @Test
    fun `a strictly increasing series has RSI of exactly 100`() {
        val closes = (0..15).map { it.toDouble() } // 16 values, all gains, no losses
        val result = RSI.calculate(closes, period = 14)
        assertEquals(100.0, result[14]!!, 1e-9)
        assertEquals(100.0, result[15]!!, 1e-9)
    }

    @Test
    fun `a strictly decreasing series has RSI of exactly 0`() {
        val closes = (15 downTo 0).map { it.toDouble() } // all losses, no gains
        val result = RSI.calculate(closes, period = 14)
        assertEquals(0.0, result[14]!!, 1e-9)
        assertEquals(0.0, result[15]!!, 1e-9)
    }

    @Test
    fun `a mixed series produces RSI strictly between 0 and 100`() {
        val closes = listOf(10.0, 11.0, 10.5, 12.0, 11.5, 13.0, 12.5, 14.0, 13.5, 15.0, 14.5, 16.0, 15.5, 17.0, 16.5, 18.0)
        val result = RSI.calculate(closes, period = 14)
        val value = result[14]!!
        assertTrue("RSI should be between 0 and 100", value in 0.0..100.0)
    }
}
