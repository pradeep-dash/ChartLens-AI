package com.chartlens.ai.indicators

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EMATest {

    @Test
    fun `returns null before enough history exists`() {
        val result = EMA.calculate(listOf(1.0, 2.0), period = 3)
        assertEquals(listOf(null, null), result)
    }

    @Test
    fun `matches hand-calculated values for a simple increasing series`() {
        // period=3, smoothing=2/(3+1)=0.5
        // seed (index2) = avg(1,2,3) = 2.0
        // index3 = 4*0.5 + 2*0.5 = 3.0
        // index4 = 5*0.5 + 3*0.5 = 4.0
        // index5 = 6*0.5 + 4*0.5 = 5.0
        val result = EMA.calculate(listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0), period = 3)

        assertNull(result[0])
        assertNull(result[1])
        assertEquals(2.0, result[2]!!, 1e-9)
        assertEquals(3.0, result[3]!!, 1e-9)
        assertEquals(4.0, result[4]!!, 1e-9)
        assertEquals(5.0, result[5]!!, 1e-9)
    }

    @Test
    fun `a flat price series produces a flat EMA equal to that price`() {
        val result = EMA.calculate(List(10) { 50.0 }, period = 5)
        result.filterNotNull().forEach { assertEquals(50.0, it, 1e-9) }
    }

    @Test
    fun `a shorter EMA period tracks recent price changes faster than a longer one`() {
        val prices = List(30) { i -> 100.0 + i } // steadily rising
        val shortEma = EMA.calculate(prices, period = 5).last()!!
        val longEma = EMA.calculate(prices, period = 20).last()!!
        assertTrue("shorter EMA should be closer to the latest (highest) price", shortEma > longEma)
    }
}
