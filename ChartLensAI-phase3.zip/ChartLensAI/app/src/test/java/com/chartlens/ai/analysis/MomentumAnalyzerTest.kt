package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MomentumAnalyzerTest {

    private val analyzer = MomentumAnalyzer(rocPeriod = 5, neutralThresholdPercent = 0.05)

    private fun candle(index: Int, open: Double, close: Double) =
        PriceCandle(index, null, open, maxOf(open, close), minOf(open, close), close)

    @Test
    fun `an empty candle list is neutral with no data`() {
        val result = analyzer.analyze(emptyList())
        assertEquals(MomentumDirection.NEUTRAL, result.direction)
        assertEquals(0, result.consecutiveSameDirectionCandles)
    }

    @Test
    fun `a steadily rising price series is bullish with positive rate of change`() {
        val candles = (0..10).map { candle(it, 100.0 + it, 100.0 + it + 1) }
        val result = analyzer.analyze(candles)
        assertEquals(MomentumDirection.BULLISH, result.direction)
        assertTrue(result.rateOfChangePercent!! > 0)
    }

    @Test
    fun `a steadily falling price series is bearish with negative rate of change`() {
        val candles = (0..10).map { candle(it, 200.0 - it, 200.0 - it - 1) }
        val result = analyzer.analyze(candles)
        assertEquals(MomentumDirection.BEARISH, result.direction)
        assertTrue(result.rateOfChangePercent!! < 0)
    }

    @Test
    fun `counts consecutive same-direction candles correctly`() {
        val candles = listOf(
            candle(0, 100.0, 95.0),  // bearish
            candle(1, 95.0, 100.0),  // bullish (streak starts)
            candle(2, 100.0, 102.0), // bullish
            candle(3, 102.0, 105.0), // bullish
            candle(4, 105.0, 108.0)  // bullish
        )
        val result = analyzer.analyze(candles)
        assertEquals(4, result.consecutiveSameDirectionCandles)
    }

    @Test
    fun `an accelerating move has a larger recent rate of change than the prior one`() {
        // Flat for a while, then a sharp recent move — the most recent rate of change
        // should be larger in magnitude than the one computed one candle earlier.
        val flat = (0..10).map { candle(it, 100.0, 100.0) }
        val sharpMove = candle(11, 100.0, 130.0)
        val result = analyzer.analyze(flat + sharpMove)
        assertEquals(true, result.isAccelerating)
    }
}
