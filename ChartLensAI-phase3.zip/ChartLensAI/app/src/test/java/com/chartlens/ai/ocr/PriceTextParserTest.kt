package com.chartlens.ai.ocr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PriceTextParserTest {

    @Test
    fun `parses a simple decimal price`() {
        assertEquals(61.4, PriceTextParser.parse("61.400")!!, 1e-9)
    }

    @Test
    fun `parses a small decimal price with leading zero`() {
        assertEquals(0.19773, PriceTextParser.parse("0.19773")!!, 1e-9)
    }

    @Test
    fun `trims surrounding whitespace`() {
        assertEquals(61.4, PriceTextParser.parse("  61.400  ")!!, 1e-9)
    }

    @Test
    fun `parses a US-style thousands-separated price`() {
        assertEquals(1234.56, PriceTextParser.parse("1,234.56")!!, 1e-9)
    }

    @Test
    fun `a comma without a thousands grouping is treated as a decimal comma`() {
        // "61,4" doesn't match the thousands pattern (needs 3-digit groups), so it
        // falls through to the simple pattern which treats the comma as a decimal point.
        assertEquals(61.4, PriceTextParser.parse("61,4")!!, 1e-9)
    }

    @Test
    fun `documented ambiguity - a comma with exactly 3 trailing digits is read as thousands, not decimal`() {
        // "61,400" is genuinely ambiguous (could mean 61400 or a European-style 61.400).
        // PriceTextParser documents that it prefers the thousands-separator reading —
        // this test locks in that documented behavior so it can't silently regress.
        assertEquals(61400.0, PriceTextParser.parse("61,400")!!, 1e-9)
    }

    @Test
    fun `text with no recognizable number returns null`() {
        assertNull(PriceTextParser.parse("Deposit"))
        assertNull(PriceTextParser.parse(""))
    }
}
