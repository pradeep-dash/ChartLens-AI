package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDirection
import org.junit.Assert.assertEquals
import org.junit.Test

class DataQualityCalculatorTest {

    private fun candle(confidence: Float, isForming: Boolean = false) = Candle(
        index = 0,
        xStart = 0,
        xEnd = 10,
        bodyTopY = 0,
        bodyBottomY = 10,
        wickTopY = 0,
        wickBottomY = 10,
        direction = CandleDirection.BULLISH,
        isForming = isForming,
        confidence = confidence
    )

    @Test
    fun `no candles is always invalid`() {
        assertEquals(DataQuality.INVALID, DataQualityCalculator.calculate(1f, emptyList()))
    }

    @Test
    fun `high confidence and enough closed candles is GOOD without a price mapping`() {
        val candles = List(20) { candle(1f) }
        assertEquals(DataQuality.GOOD, DataQualityCalculator.calculate(1f, candles))
    }

    @Test
    fun `a weak price mapping downgrades an otherwise-GOOD result to FAIR`() {
        val candles = List(20) { candle(1f) }
        val result = DataQualityCalculator.calculate(1f, candles, priceScaleConfidence = 0.2f)
        assertEquals(DataQuality.FAIR, result)
    }

    @Test
    fun `a strong price mapping leaves a GOOD result unchanged`() {
        val candles = List(20) { candle(1f) }
        val result = DataQualityCalculator.calculate(1f, candles, priceScaleConfidence = 0.9f)
        assertEquals(DataQuality.GOOD, result)
    }

    @Test
    fun `a weak price mapping never upgrades a poor result`() {
        val candles = List(3) { candle(0.3f) }
        val baseline = DataQualityCalculator.calculate(0.3f, candles)
        val withWeakPrice = DataQualityCalculator.calculate(0.3f, candles, priceScaleConfidence = 0.2f)
        assertEquals(baseline, withWeakPrice)
    }
}
