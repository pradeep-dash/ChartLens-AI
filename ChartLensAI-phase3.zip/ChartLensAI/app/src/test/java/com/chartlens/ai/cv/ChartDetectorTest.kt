package com.chartlens.ai.cv

import com.chartlens.ai.testutil.MutablePixelGrid
import com.chartlens.ai.testutil.MutablePixelGrid.Companion.BACKGROUND_COLOR
import com.chartlens.ai.testutil.MutablePixelGrid.Companion.BEARISH_COLOR
import com.chartlens.ai.testutil.MutablePixelGrid.Companion.BULLISH_COLOR
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChartDetectorTest {

    private val detector = ChartDetector()

    @Test
    fun `an all-background frame produces no detection`() {
        val buffer = MutablePixelGrid(200, 100, BACKGROUND_COLOR).toPixelBuffer()
        assertNull(detector.detect(buffer))
    }

    @Test
    fun `a single small colored icon is not mistaken for a chart`() {
        val grid = MutablePixelGrid(200, 100, BACKGROUND_COLOR)
        // One small solid block — a plausible stand-in for a colored button/icon, far too
        // few columns and zero color transitions to look like a candlestick chart.
        grid.fillRect(left = 90, top = 40, right = 100, bottom = 50, color = BULLISH_COLOR)

        assertNull(detector.detect(grid.toPixelBuffer()))
    }

    @Test
    fun `a cluster of alternating candle-colored bars is detected as a chart region`() {
        val grid = MutablePixelGrid(200, 100, BACKGROUND_COLOR)

        // 15 alternating bullish/bearish bars, 4px wide with 2px gaps, starting at x=40,
        // each spanning rows 20..80 — a stand-in for a real candlestick cluster.
        var x = 40
        repeat(15) { i ->
            val color = if (i % 2 == 0) BULLISH_COLOR else BEARISH_COLOR
            grid.fillRect(left = x, top = 20, right = x + 4, bottom = 80, color = color)
            x += 6
        }

        val region = detector.detect(grid.toPixelBuffer())

        assertTrue("expected a region to be detected", region != null)
        region!!
        assertTrue("left bound should be near the first bar", region.left in 38..42)
        assertTrue("right bound should be near the last bar", region.right in x - 4..x + 2)
        assertTrue("top bound should be near the bars' top", region.top in 10..24)
        assertTrue("bottom bound should be near the bars' bottom", region.bottom in 76..90)
        assertTrue("confidence should be reasonably high for a clean synthetic chart", region.confidence > 0.5f)
        assertTrue(region.isUsable())
    }

    @Test
    fun `bars separated by a gap wider than the tolerance are treated as separate clusters`() {
        val grid = MutablePixelGrid(300, 100, BACKGROUND_COLOR)

        // A small 5-bar cluster on the left...
        var x = 10
        repeat(5) { i ->
            val color = if (i % 2 == 0) BULLISH_COLOR else BEARISH_COLOR
            grid.fillRect(left = x, top = 20, right = x + 4, bottom = 80, color = color)
            x += 6
        }

        // ...and a larger 20-bar cluster far to the right, well beyond the gap tolerance.
        var x2 = 150
        repeat(20) { i ->
            val color = if (i % 2 == 0) BULLISH_COLOR else BEARISH_COLOR
            grid.fillRect(left = x2, top = 20, right = x2 + 4, bottom = 80, color = color)
            x2 += 6
        }

        val region = detector.detect(grid.toPixelBuffer())

        assertTrue("expected the larger cluster to be selected", region != null)
        assertTrue("should have picked the right-hand (larger) cluster", region!!.left >= 150)
    }
}
