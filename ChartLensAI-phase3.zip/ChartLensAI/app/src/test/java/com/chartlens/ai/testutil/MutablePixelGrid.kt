package com.chartlens.ai.testutil

import com.chartlens.ai.common.PixelBuffer

/** Test-only helper for painting synthetic candlestick-chart pixel data. */
class MutablePixelGrid(private val width: Int, private val height: Int, background: Int) {
    private val pixels = IntArray(width * height) { background }

    /** [left]/[top] inclusive, [right]/[bottom] exclusive — same convention as PixelBuffer.crop. */
    fun fillRect(left: Int, top: Int, right: Int, bottom: Int, color: Int) {
        for (y in top until bottom) {
            for (x in left until right) {
                if (x in 0 until width && y in 0 until height) {
                    pixels[y * width + x] = color
                }
            }
        }
    }

    fun toPixelBuffer(): PixelBuffer = PixelBuffer(width, height, pixels.copyOf())

    companion object {
        // Passes CandleColorProfile's default hue ranges (see CandleColorProfile.kt).
        const val BULLISH_COLOR = 0xFF00CC88.toInt() // hue ~160 (teal-green)
        const val BEARISH_COLOR = 0xFFFF0000.toInt() // hue 0 (red)
        const val BACKGROUND_COLOR = 0xFF303030.toInt() // low saturation -> classifies OTHER
    }
}
