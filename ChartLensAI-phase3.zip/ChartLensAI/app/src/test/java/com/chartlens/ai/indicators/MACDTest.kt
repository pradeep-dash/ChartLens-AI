package com.chartlens.ai.indicators

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MACDTest {

    @Test
    fun `returns null before enough history exists for the slow EMA`() {
        val result = MACD.calculate(List(10) { it.toDouble() }, slowPeriod = 26)
        assertEquals(List(10) { null }, result)
    }

    @Test
    fun `a sustained uptrend produces a positive MACD line`() {
        val closes = List(60) { i -> 100.0 + i * 0.5 }
        val result = MACD.calculate(closes).last()!!
        assertTrue("fast EMA should be above slow EMA in a sustained uptrend", result.macd > 0)
    }

    @Test
    fun `a sustained downtrend produces a negative MACD line`() {
        val closes = List(60) { i -> 200.0 - i * 0.5 }
        val result = MACD.calculate(closes).last()!!
        assertTrue("fast EMA should be below slow EMA in a sustained downtrend", result.macd < 0)
    }

    @Test
    fun `histogram is the difference between macd and signal`() {
        val closes = List(60) { i -> 100.0 + i * 0.3 + (if (i % 4 == 0) 2.0 else 0.0) }
        val result = MACD.calculate(closes).last()!!
        assertEquals(result.macd - result.signal, result.histogram, 1e-9)
    }
}
