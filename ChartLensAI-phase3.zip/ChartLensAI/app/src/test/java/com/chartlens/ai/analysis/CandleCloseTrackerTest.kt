package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CandleCloseTrackerTest {

    private fun candle(index: Int, xStart: Int, isForming: Boolean) = Candle(
        index = index,
        xStart = xStart,
        xEnd = xStart + 20,
        bodyTopY = 10,
        bodyBottomY = 20,
        wickTopY = 5,
        wickBottomY = 25,
        direction = CandleDirection.BULLISH,
        isForming = isForming,
        confidence = 1f
    )

    @Test
    fun `the first update never emits an event, only establishes a baseline`() {
        val tracker = CandleCloseTracker()
        val event = tracker.update(listOf(candle(0, 0, false), candle(1, 50, true)))
        assertNull(event)
    }

    @Test
    fun `a forming candle that becomes closed on the next frame is reported`() {
        val tracker = CandleCloseTracker()
        tracker.update(listOf(candle(0, 0, false), candle(1, 50, true)))

        val event = tracker.update(
            listOf(candle(0, 0, false), candle(1, 50, false), candle(2, 100, true))
        )

        assertEquals(50, event?.closedCandle?.xStart)
    }

    @Test
    fun `no event when the candle count doesn't grow`() {
        val tracker = CandleCloseTracker()
        tracker.update(listOf(candle(0, 0, false), candle(1, 50, true)))
        tracker.update(listOf(candle(0, 0, false), candle(1, 50, false), candle(2, 100, true)))

        // Same shape again — nothing new closed.
        val event = tracker.update(
            listOf(candle(0, 0, false), candle(1, 50, false), candle(2, 100, true))
        )
        assertNull(event)
    }

    @Test
    fun `a position jump inconsistent with the tracked forming candle is not reported as a close`() {
        val tracker = CandleCloseTracker()
        tracker.update(listOf(candle(0, 0, false), candle(1, 50, true)))

        // Candle count grew, but the "closed" candle's position is nowhere near where
        // the forming candle was — looks like a re-detection jump, not a real close.
        val event = tracker.update(
            listOf(candle(0, 0, false), candle(1, 500, false), candle(2, 600, true))
        )
        assertNull(event)
    }

    @Test
    fun `reset clears state so the next update behaves like the first one`() {
        val tracker = CandleCloseTracker()
        tracker.update(listOf(candle(0, 0, false), candle(1, 50, true)))
        tracker.reset()

        val event = tracker.update(
            listOf(candle(0, 0, false), candle(1, 50, false), candle(2, 100, true))
        )
        assertNull(event)
    }
}
