package com.chartlens.ai.capture

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class FrameChangeDetectorTest {

    private lateinit var detector: FrameChangeDetector

    @Before
    fun setUp() {
        detector = FrameChangeDetector(changeThreshold = 0.015)
    }

    @Test
    fun `first frame is always treated as changed`() {
        val frame = solidColorSample(color = 0xFF112233.toInt(), size = 32)
        assertTrue(detector.hasMateriallyChanged(frame))
    }

    @Test
    fun `identical consecutive frames are not treated as changed`() {
        val frame = solidColorSample(color = 0xFF112233.toInt(), size = 32)
        detector.hasMateriallyChanged(frame) // seed as "previous"

        val identical = solidColorSample(color = 0xFF112233.toInt(), size = 32)
        assertFalse(detector.hasMateriallyChanged(identical))
    }

    @Test
    fun `small noise below threshold is not treated as changed`() {
        val base = solidColorSample(color = 0xFF808080.toInt(), size = 32)
        detector.hasMateriallyChanged(base)

        // Nudge a single pixel by a tiny amount — well under the per-pixel and
        // fractional thresholds.
        val nudged = base.copyOf()
        nudged[0] = 0xFF818181.toInt()
        assertFalse(detector.hasMateriallyChanged(nudged))
    }

    @Test
    fun `large region change is treated as changed`() {
        val base = solidColorSample(color = 0xFF000000.toInt(), size = 32)
        detector.hasMateriallyChanged(base)

        // A new candle appearing (a red block) changes a meaningful fraction of pixels.
        val withCandle = base.copyOf()
        for (i in 0 until (base.size / 4)) {
            withCandle[i] = 0xFFEF5350.toInt()
        }
        assertTrue(detector.hasMateriallyChanged(withCandle))
    }

    @Test
    fun `resolution change forces a changed result even with same content`() {
        val base = solidColorSample(color = 0xFF445566.toInt(), size = 32)
        detector.hasMateriallyChanged(base)

        val differentSize = solidColorSample(color = 0xFF445566.toInt(), size = 16)
        assertTrue(detector.hasMateriallyChanged(differentSize))
    }

    @Test
    fun `reset forgets previous frame so next call is treated as first frame`() {
        val base = solidColorSample(color = 0xFF445566.toInt(), size = 32)
        detector.hasMateriallyChanged(base)
        detector.reset()

        val identical = solidColorSample(color = 0xFF445566.toInt(), size = 32)
        assertTrue(detector.hasMateriallyChanged(identical))
    }

    private fun solidColorSample(color: Int, size: Int): IntArray =
        IntArray(size * size) { color }
}
