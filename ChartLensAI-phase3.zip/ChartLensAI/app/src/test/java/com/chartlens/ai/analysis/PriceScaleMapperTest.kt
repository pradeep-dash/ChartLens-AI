package com.chartlens.ai.analysis

import com.chartlens.ai.ocr.OcrTextBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PriceScaleMapperTest {

    private val mapper = PriceScaleMapper()

    @Test
    fun `fewer than two valid labels produces no mapping`() {
        val labels = listOf(OcrTextBlock("Deposit", centerX = 0, centerY = 100))
        assertNull(mapper.fit(labels))
    }

    @Test
    fun `three perfectly linear labels fit exactly with high confidence`() {
        // price decreases by 0.1 for every 100px of Y, matching real screen behavior
        // (higher on screen = smaller Y = higher price).
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 0, centerY = 200),
            OcrTextBlock("61.300", centerX = 0, centerY = 300)
        )
        val mapping = mapper.fit(labels)!!

        assertEquals(1.0, mapping.rSquared, 1e-6)
        assertEquals(3, mapping.sampleCount)
        assertTrue("a clean 3-point fit should be highly confident", mapping.confidence > 0.9f)
        assertEquals(61.45, mapping.priceAt(150.0), 1e-6)
    }

    @Test
    fun `a two-point fit is always geometrically perfect but capped at lower confidence`() {
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.300", centerX = 0, centerY = 300)
        )
        val mapping = mapper.fit(labels)!!

        assertEquals(1.0, mapping.rSquared, 1e-6) // any 2 points fit a line perfectly
        assertTrue("a 2-point fit should never be treated as fully confident", mapping.confidence <= 0.5f)
    }

    @Test
    fun `an inconsistent label among three lowers the fit quality`() {
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 0, centerY = 200),
            OcrTextBlock("59.000", centerX = 0, centerY = 300) // a badly misread label
        )
        val mapping = mapper.fit(labels)!!

        assertTrue("a bad label should visibly hurt the fit", mapping.rSquared < 0.95)
    }

    @Test
    fun `unparseable labels are ignored, valid ones still fit`() {
        val labels = listOf(
            OcrTextBlock("Deposit", centerX = 0, centerY = 50),
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("50%", centerX = 0, centerY = 150),
            OcrTextBlock("61.300", centerX = 0, centerY = 300)
        )
        val mapping = mapper.fit(labels)!!
        assertEquals(2, mapping.sampleCount)
    }

    @Test
    fun `labels all at the same Y position cannot fit a line`() {
        val labels = listOf(
            OcrTextBlock("61.500", centerX = 0, centerY = 100),
            OcrTextBlock("61.400", centerX = 10, centerY = 100)
        )
        assertNull(mapper.fit(labels))
    }
}
