package com.chartlens.ai.indicators

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BollingerBandsTest {

    @Test
    fun `returns null before enough history exists`() {
        val result = BollingerBands.calculate(List(5) { 100.0 }, period = 20)
        assertNull(result.last())
    }

    @Test
    fun `a constant price series has zero-width bands equal to the price`() {
        val result = BollingerBands.calculate(List(20) { 100.0 }, period = 20).last()!!
        assertEquals(100.0, result.middle, 1e-9)
        assertEquals(100.0, result.upper, 1e-9)
        assertEquals(100.0, result.lower, 1e-9)
    }

    @Test
    fun `an alternating series matches the hand-calculated mean and standard deviation`() {
        // 10 values of 90, 10 of 110: mean = 100, variance = 100, stdDev = 10.
        val closes = List(20) { i -> if (i % 2 == 0) 90.0 else 110.0 }
        val result = BollingerBands.calculate(closes, period = 20, standardDeviations = 2.0).last()!!

        assertEquals(100.0, result.middle, 1e-9)
        assertEquals(120.0, result.upper, 1e-9) // 100 + 2*10
        assertEquals(80.0, result.lower, 1e-9)  // 100 - 2*10
    }
}
