package com.chartlens.ai.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TechnicalAnalysisEngineTest {

    private val engine = TechnicalAnalysisEngine()

    private fun candle(index: Int, price: Double) =
        PriceCandle(index, null, price, price + 1, price - 1, price)

    @Test
    fun `insufficient history yields null indicators rather than fabricated values`() {
        val candles = (0..4).map { candle(it, 100.0 + it) }
        val result = engine.analyze(candles)

        assertEquals(5, result.candleCount)
        assertNull(result.ema9)
        assertNull(result.ema21)
        assertNull(result.ema50)
        assertNull(result.rsi14)
        assertNull(result.macd)
        assertNull(result.atr)
        assertNull(result.bollinger)
        assertEquals(Trend.UNKNOWN, result.trend.trend)
    }

    @Test
    fun `sufficient history produces real values for every indicator`() {
        // 60 candles, enough for EMA50, RSI14, MACD(12,26,9), ATR14, and Bollinger(20).
        val candles = (0..59).map { i -> candle(i, 100.0 + i * 0.7) }
        val result = engine.analyze(candles)

        assertEquals(60, result.candleCount)
        assertNotNull(result.ema9)
        assertNotNull(result.ema21)
        assertNotNull(result.ema50)
        assertNotNull(result.rsi14)
        assertNotNull(result.macd)
        assertNotNull(result.atr)
        assertNotNull(result.bollinger)
    }

    @Test
    fun `an empty candle list does not crash and yields a clearly-unknown result`() {
        val result = engine.analyze(emptyList())

        assertEquals(0, result.candleCount)
        assertEquals(Trend.UNKNOWN, result.trend.trend)
        assertEquals(MomentumDirection.NEUTRAL, result.momentum.direction)
        assertNull(result.rsi14)
    }
}
