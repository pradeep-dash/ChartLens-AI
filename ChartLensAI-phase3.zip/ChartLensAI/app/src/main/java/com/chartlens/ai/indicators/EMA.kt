package com.chartlens.ai.indicators

/**
 * Standard EMA: seeded with a simple moving average of the first [period]
 * values, then the recursive EMA formula for every value after that.
 *
 * Returns `null` for every index before enough history exists — per the "only
 * calculate indicators when enough historical candles exist" requirement,
 * this never backfills or approximates values it doesn't have real data for.
 */
object EMA {

    fun calculate(values: List<Double>, period: Int): List<Double?> {
        require(period > 0) { "period must be positive" }
        if (values.size < period) return List(values.size) { null }

        val result = MutableList<Double?>(values.size) { null }
        val smoothing = 2.0 / (period + 1)

        var ema = values.subList(0, period).average()
        result[period - 1] = ema

        for (i in period until values.size) {
            ema = values[i] * smoothing + ema * (1 - smoothing)
            result[i] = ema
        }
        return result
    }
}
