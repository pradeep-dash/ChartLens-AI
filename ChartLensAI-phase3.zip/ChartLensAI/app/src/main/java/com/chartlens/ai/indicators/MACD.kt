package com.chartlens.ai.indicators

data class MacdPoint(val macd: Double, val signal: Double, val histogram: Double)

/**
 * Standard MACD: fast EMA minus slow EMA, with a signal line that is itself an
 * EMA of the MACD line. The signal EMA is seeded from the first index where
 * the MACD line becomes defined (i.e. once both the fast and slow EMAs have
 * enough history) — not from index 0, since the MACD line itself doesn't
 * exist before that point.
 */
object MACD {

    fun calculate(
        closes: List<Double>,
        fastPeriod: Int = 12,
        slowPeriod: Int = 26,
        signalPeriod: Int = 9
    ): List<MacdPoint?> {
        require(fastPeriod > 0 && slowPeriod > 0 && signalPeriod > 0)
        if (closes.size < slowPeriod) return List(closes.size) { null }

        val fastEma = EMA.calculate(closes, fastPeriod)
        val slowEma = EMA.calculate(closes, slowPeriod)

        val macdValues = DoubleArray(closes.size)
        val macdDefined = BooleanArray(closes.size)
        for (i in closes.indices) {
            val fast = fastEma[i]
            val slow = slowEma[i]
            if (fast != null && slow != null) {
                macdValues[i] = fast - slow
                macdDefined[i] = true
            }
        }

        val firstDefinedIndex = macdDefined.indexOfFirst { it }
        if (firstDefinedIndex == -1) return List(closes.size) { null }

        val macdSeries = macdValues.toList().subList(firstDefinedIndex, closes.size)
        val signalEma = EMA.calculate(macdSeries, signalPeriod)

        val result = MutableList<MacdPoint?>(closes.size) { null }
        for (i in macdSeries.indices) {
            val signal = signalEma[i] ?: continue
            val macd = macdSeries[i]
            result[firstDefinedIndex + i] = MacdPoint(macd, signal, macd - signal)
        }
        return result
    }
}
