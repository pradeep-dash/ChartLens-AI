package com.chartlens.ai.analysis

enum class MomentumDirection { BULLISH, BEARISH, NEUTRAL }

data class MomentumResult(
    val direction: MomentumDirection,
    val consecutiveSameDirectionCandles: Int,
    /** Percent change in close over the last [MomentumAnalyzer]'s period. Null if not enough history. */
    val rateOfChangePercent: Double?,
    /** Null if there isn't enough history to compare against a prior rate of change. */
    val isAccelerating: Boolean?
)

class MomentumAnalyzer(
    private val rocPeriod: Int = 5,
    private val neutralThresholdPercent: Double = 0.05
) {

    fun analyze(candles: List<PriceCandle>): MomentumResult {
        if (candles.isEmpty()) {
            return MomentumResult(MomentumDirection.NEUTRAL, 0, null, null)
        }

        val roc = rateOfChange(candles)
        val priorRoc = if (candles.size > 1) rateOfChange(candles.dropLast(1)) else null
        val accelerating = if (roc != null && priorRoc != null) {
            kotlin.math.abs(roc) > kotlin.math.abs(priorRoc)
        } else {
            null
        }

        val direction = when {
            roc == null -> MomentumDirection.NEUTRAL
            roc > neutralThresholdPercent -> MomentumDirection.BULLISH
            roc < -neutralThresholdPercent -> MomentumDirection.BEARISH
            else -> MomentumDirection.NEUTRAL
        }

        return MomentumResult(
            direction = direction,
            consecutiveSameDirectionCandles = countConsecutiveSameDirection(candles),
            rateOfChangePercent = roc,
            isAccelerating = accelerating
        )
    }

    private fun rateOfChange(candles: List<PriceCandle>): Double? {
        if (candles.size <= rocPeriod) return null
        val current = candles.last().close
        val past = candles[candles.size - 1 - rocPeriod].close
        if (past == 0.0) return null
        return (current - past) / past * 100.0
    }

    private fun countConsecutiveSameDirection(candles: List<PriceCandle>): Int {
        if (candles.isEmpty()) return 0
        val lastUp = candles.last().close >= candles.last().open
        var count = 1
        for (i in candles.size - 2 downTo 0) {
            val up = candles[i].close >= candles[i].open
            if (up == lastUp) count++ else break
        }
        return count
    }
}
