package com.chartlens.ai.analysis

import com.chartlens.ai.indicators.ATR
import com.chartlens.ai.indicators.BollingerBands
import com.chartlens.ai.indicators.BollingerPoint
import com.chartlens.ai.indicators.EMA
import com.chartlens.ai.indicators.MACD
import com.chartlens.ai.indicators.MacdPoint
import com.chartlens.ai.indicators.RSI

/**
 * Every indicator field is nullable and simply reflects whatever
 * [EMA]/[RSI]/[MACD]/[ATR]/[BollingerBands] returned for the last candle in
 * the input — null means "not enough history yet," never a fabricated or
 * interpolated value.
 */
data class TechnicalAnalysisResult(
    val candleCount: Int,
    val trend: TrendResult,
    val momentum: MomentumResult,
    val ema9: Double?,
    val ema21: Double?,
    val ema50: Double?,
    val rsi14: Double?,
    val macd: MacdPoint?,
    val atr: Double?,
    val bollinger: BollingerPoint?,
    val supportResistance: SupportResistanceResult
)

/**
 * Orchestrates every Phase 4 analyzer/indicator into one result, evaluated as
 * of the last candle in [candles].
 *
 * Callers decide what "as of" means: pass only closed candles for a fully
 * confirmed technical read, or include the currently-forming candle if a
 * live/provisional read is acceptable for the use case — this class doesn't
 * enforce either policy, consistent with the rest of the pipeline treating
 * "which candles count as closed" as the caller's responsibility (see
 * [com.chartlens.ai.candle.Candle.isForming]).
 */
class TechnicalAnalysisEngine(
    private val trendAnalyzer: TrendAnalyzer = TrendAnalyzer(),
    private val momentumAnalyzer: MomentumAnalyzer = MomentumAnalyzer(),
    private val supportResistanceAnalyzer: SupportResistanceAnalyzer = SupportResistanceAnalyzer()
) {

    fun analyze(candles: List<PriceCandle>): TechnicalAnalysisResult {
        val closes = candles.map { it.close }

        return TechnicalAnalysisResult(
            candleCount = candles.size,
            trend = trendAnalyzer.analyze(candles),
            momentum = momentumAnalyzer.analyze(candles),
            ema9 = EMA.calculate(closes, 9).lastOrNull(),
            ema21 = EMA.calculate(closes, 21).lastOrNull(),
            ema50 = EMA.calculate(closes, 50).lastOrNull(),
            rsi14 = RSI.calculate(closes, 14).lastOrNull(),
            macd = MACD.calculate(closes).lastOrNull(),
            atr = ATR.calculate(candles, 14).lastOrNull(),
            bollinger = BollingerBands.calculate(closes, 20).lastOrNull(),
            supportResistance = supportResistanceAnalyzer.analyze(candles)
        )
    }
}
