package com.chartlens.ai.analysis

enum class Trend { UPTREND, DOWNTREND, SIDEWAYS, UNKNOWN }
enum class SwingType { HIGH, LOW }

data class SwingPoint(val index: Int, val price: Double, val type: SwingType)

data class TrendResult(
    val trend: Trend,
    /** 0..1 — how consistently recent swings maintain the higher-highs/higher-lows
     * (or lower-highs/lower-lows) pattern. Not a statistically validated probability. */
    val trendStrength: Float,
    val swingHighs: List<SwingPoint>,
    val swingLows: List<SwingPoint>,
    val isConsolidating: Boolean
)

/**
 * Classifies trend from swing structure (higher highs + higher lows = uptrend,
 * lower highs + lower lows = downtrend), rather than a single moving-average
 * slope — this is what the spec's "swing structure" requirement asks for, and
 * it's more robust to short-term noise than a slope-only approach.
 *
 * Swing points are found with a simple fractal method: a candle is a swing
 * high if its high is strictly the maximum within a [swingLookback]-candle
 * window on both sides (and symmetrically for swing lows). This means a swing
 * point can only be confirmed once [swingLookback] candles exist *after* it —
 * which is fine for support/resistance and trend-structure analysis (both are
 * inherently about confirmed historical structure), but callers must not treat
 * the most recent 1-2 candles as having confirmed swing status yet.
 */
class TrendAnalyzer(
    private val swingLookback: Int = 2,
    private val swingsConsidered: Int = 3,
    private val trendScoreThreshold: Float = 0.6f,
    private val consolidationRangeFraction: Double = 0.02
) {

    fun analyze(candles: List<PriceCandle>): TrendResult {
        val highs = findSwingHighs(candles).takeLast(swingsConsidered)
        val lows = findSwingLows(candles).takeLast(swingsConsidered)

        if (highs.size < 2 || lows.size < 2) {
            return TrendResult(Trend.UNKNOWN, 0f, highs, lows, isConsolidating = false)
        }

        val higherHighsScore = consecutivePairScore(highs.map { it.price }) { a, b -> b > a }
        val lowerHighsScore = consecutivePairScore(highs.map { it.price }) { a, b -> b < a }
        val higherLowsScore = consecutivePairScore(lows.map { it.price }) { a, b -> b > a }
        val lowerLowsScore = consecutivePairScore(lows.map { it.price }) { a, b -> b < a }

        val uptrendScore = (higherHighsScore + higherLowsScore) / 2f
        val downtrendScore = (lowerHighsScore + lowerLowsScore) / 2f

        return when {
            uptrendScore >= trendScoreThreshold && uptrendScore > downtrendScore ->
                TrendResult(Trend.UPTREND, uptrendScore, highs, lows, isConsolidating = false)

            downtrendScore >= trendScoreThreshold && downtrendScore > uptrendScore ->
                TrendResult(Trend.DOWNTREND, downtrendScore, highs, lows, isConsolidating = false)

            else -> {
                val maxHigh = highs.maxOf { it.price }
                val minLow = lows.minOf { it.price }
                val midpoint = (maxHigh + minLow) / 2
                val range = maxHigh - minLow
                val isConsolidating = midpoint > 0 && range / midpoint < consolidationRangeFraction
                TrendResult(Trend.SIDEWAYS, maxOf(uptrendScore, downtrendScore), highs, lows, isConsolidating)
            }
        }
    }

    private fun consecutivePairScore(values: List<Double>, predicate: (Double, Double) -> Boolean): Float {
        if (values.size < 2) return 0f
        val pairs = values.zipWithNext()
        return pairs.count { (a, b) -> predicate(a, b) }.toFloat() / pairs.size
    }

    fun findSwingHighs(candles: List<PriceCandle>): List<SwingPoint> {
        if (candles.size < swingLookback * 2 + 1) return emptyList()
        val swings = mutableListOf<SwingPoint>()
        for (i in swingLookback until candles.size - swingLookback) {
            val window = candles.subList(i - swingLookback, i + swingLookback + 1)
            val maxHigh = window.maxOf { it.high }
            if (candles[i].high == maxHigh && window.count { it.high == maxHigh } == 1) {
                swings += SwingPoint(i, candles[i].high, SwingType.HIGH)
            }
        }
        return swings
    }

    fun findSwingLows(candles: List<PriceCandle>): List<SwingPoint> {
        if (candles.size < swingLookback * 2 + 1) return emptyList()
        val swings = mutableListOf<SwingPoint>()
        for (i in swingLookback until candles.size - swingLookback) {
            val window = candles.subList(i - swingLookback, i + swingLookback + 1)
            val minLow = window.minOf { it.low }
            if (candles[i].low == minLow && window.count { it.low == minLow } == 1) {
                swings += SwingPoint(i, candles[i].low, SwingType.LOW)
            }
        }
        return swings
    }
}
