package com.chartlens.ai.common

/**
 * A width/height ARGB pixel grid with no Android framework dependency.
 *
 * Every CV/candle-detection class in this app operates on [PixelBuffer], never
 * directly on `android.graphics.Bitmap`. `Bitmap` methods are stubbed to throw in
 * plain JVM unit tests (no Robolectric configured), so this is what makes
 * [com.chartlens.ai.candle.CandleDetector] and [com.chartlens.ai.cv.ChartDetector]
 * testable with synthetic data instead of requiring a device for every change.
 *
 * The only place that touches `Bitmap` is [com.chartlens.ai.cv.FrameAnalyzer],
 * which converts at the Android boundary and is reviewed by hand rather than
 * unit tested, same as the rest of the capture pipeline.
 */
class PixelBuffer(
    val width: Int,
    val height: Int,
    private val pixels: IntArray
) {
    init {
        require(pixels.size == width * height) {
            "pixels.size (${pixels.size}) must equal width*height (${width * height})"
        }
    }

    fun get(x: Int, y: Int): Int {
        require(x in 0 until width && y in 0 until height) { "($x,$y) out of bounds for ${width}x$height" }
        return pixels[y * width + x]
    }

    /** Returns a new PixelBuffer restricted to the given rectangle (all bounds inclusive of start, exclusive of end). */
    fun crop(left: Int, top: Int, right: Int, bottom: Int): PixelBuffer {
        val cropWidth = (right - left).coerceAtLeast(0)
        val cropHeight = (bottom - top).coerceAtLeast(0)
        val out = IntArray(cropWidth * cropHeight)
        for (y in 0 until cropHeight) {
            for (x in 0 until cropWidth) {
                out[y * cropWidth + x] = get(left + x, top + y)
            }
        }
        return PixelBuffer(cropWidth, cropHeight, out)
    }

    companion object {
        fun solid(width: Int, height: Int, color: Int): PixelBuffer =
            PixelBuffer(width, height, IntArray(width * height) { color })
    }
}
