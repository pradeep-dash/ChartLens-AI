package com.chartlens.ai.analysis

/**
 * A candle in real price space (Double OHLC), independent of how those prices
 * were obtained. This is deliberately a separate model from
 * [com.chartlens.ai.candle.Candle] (Phase 2's pixel-geometry model) — the
 * technical analysis engine should be usable with real price data from any
 * source (Phase 3's price-axis mapper once it exists, a backtest data file,
 * historical downloaded candles, etc.), not hardwired to the CV pipeline.
 *
 * [com.chartlens.ai.analysis.TechnicalAnalysisEngine] never fabricates a
 * `PriceCandle` — nothing in this phase converts Phase 2's pixel-Y candles into
 * `PriceCandle`s, since doing so without a real price-axis mapping would mean
 * inventing prices. That conversion is Phase 3's job.
 */
data class PriceCandle(
    val index: Int,
    val timestampMillis: Long?,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)
