package com.chartlens.ai.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.chartlens.ai.settings.NormalizedRect

/**
 * Lets the user drag out a rectangle over the most recently captured frame to
 * manually mark the chart region, for when [com.chartlens.ai.cv.ChartDetector]'s
 * automatic detection doesn't find it (spec §5's required fallback).
 *
 * Requires a frame to already exist in [com.chartlens.ai.common.LatestFrameHolder]
 * — i.e. the user must have started analysis at least once — since there is no
 * other source of "what the trading app's screen looks like" to select against.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChartRegionSelectionScreen(
    previewBitmap: Bitmap?,
    existingSelection: NormalizedRect?,
    onSave: (NormalizedRect) -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Select Chart Region") })
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (previewBitmap == null) {
                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No captured frame yet. Start Analysis first, then come back " +
                            "here to select the chart region.",
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                var imageSizePx by remember { mutableStateOf(IntSize.Zero) }
                var dragStart by remember { mutableStateOf<Offset?>(null) }
                var dragCurrent by remember { mutableStateOf<Offset?>(null) }
                var confirmedRect by remember { mutableStateOf<Rect?>(null) }
                var userModifiedSelection by remember { mutableStateOf(false) }

                LaunchedEffect(imageSizePx, existingSelection) {
                    if (!userModifiedSelection && existingSelection != null &&
                        imageSizePx.width > 0 && imageSizePx.height > 0
                    ) {
                        confirmedRect = Rect(
                            left = existingSelection.left * imageSizePx.width,
                            top = existingSelection.top * imageSizePx.height,
                            right = existingSelection.right * imageSizePx.width,
                            bottom = existingSelection.bottom * imageSizePx.height
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(8.dp)
                ) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "Latest captured frame",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .onSizeChanged { imageSizePx = it }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        dragStart = offset
                                        dragCurrent = offset
                                    },
                                    onDrag = { change, _ ->
                                        dragCurrent = change.position
                                    },
                                    onDragEnd = {
                                        val start = dragStart
                                        val end = dragCurrent
                                        if (start != null && end != null) {
                                            confirmedRect = Rect(
                                                left = minOf(start.x, end.x),
                                                top = minOf(start.y, end.y),
                                                right = maxOf(start.x, end.x),
                                                bottom = maxOf(start.y, end.y)
                                            )
                                            userModifiedSelection = true
                                        }
                                        dragStart = null
                                        dragCurrent = null
                                    }
                                )
                            }
                    )

                    val liveRect = if (dragStart != null && dragCurrent != null) {
                        Rect(
                            left = minOf(dragStart!!.x, dragCurrent!!.x),
                            top = minOf(dragStart!!.y, dragCurrent!!.y),
                            right = maxOf(dragStart!!.x, dragCurrent!!.x),
                            bottom = maxOf(dragStart!!.y, dragCurrent!!.y)
                        )
                    } else null

                    val rectToDraw = liveRect ?: confirmedRect
                    if (rectToDraw != null) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(
                                color = Color(0xFF26A69A),
                                topLeft = rectToDraw.topLeft,
                                size = rectToDraw.size,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
                            )
                        }
                    }
                }

                Text(
                    text = "Drag a rectangle over the candlestick chart area, then tap Save.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(onClick = onClear, modifier = Modifier.weight(1f)) {
                        Text("Clear (use auto-detect)")
                    }
                    Button(
                        onClick = {
                            val rect = confirmedRect ?: return@Button
                            if (imageSizePx.width == 0 || imageSizePx.height == 0) return@Button
                            onSave(
                                NormalizedRect(
                                    left = (rect.left / imageSizePx.width).coerceIn(0f, 1f),
                                    top = (rect.top / imageSizePx.height).coerceIn(0f, 1f),
                                    right = (rect.right / imageSizePx.width).coerceIn(0f, 1f),
                                    bottom = (rect.bottom / imageSizePx.height).coerceIn(0f, 1f)
                                )
                            )
                        },
                        modifier = Modifier.weight(1f),
                        enabled = confirmedRect != null
                    ) {
                        Text("Save Selection")
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Text("Back to Dashboard")
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
