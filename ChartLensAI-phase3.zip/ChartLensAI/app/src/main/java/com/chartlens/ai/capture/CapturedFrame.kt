package com.chartlens.ai.capture

import android.graphics.Bitmap

/**
 * A single frame read from the screen, already cropped of row-stride padding.
 *
 * Ownership: the receiver of a [CapturedFrame] must not hold [bitmap] past the
 * current processing step without copying it — [ScreenCaptureController] reuses
 * a small pool of bitmaps to avoid per-frame allocation churn.
 */
data class CapturedFrame(
    val bitmap: Bitmap,
    val width: Int,
    val height: Int,
    val timestampMillis: Long,
    /**
     * True if [FrameChangeDetector] judged this frame materially different from the
     * last analyzed one. Phase 2's FrameAnalyzer should skip the CV pipeline when
     * false and only refresh freshness/fps counters.
     */
    val hasMaterialChange: Boolean
)
