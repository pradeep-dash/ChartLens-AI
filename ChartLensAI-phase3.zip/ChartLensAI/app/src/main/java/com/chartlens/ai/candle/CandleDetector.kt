package com.chartlens.ai.candle

import com.chartlens.ai.common.PixelBuffer
import com.chartlens.ai.cv.CandleColorProfile
import com.chartlens.ai.cv.PixelClassification
import kotlin.math.max
import kotlin.math.min

/**
 * Detects individual candles within a [PixelBuffer] that has already been cropped
 * to the chart region (see [com.chartlens.ai.cv.ChartDetector]).
 *
 * Algorithm, in two passes:
 *  1. Cluster columns into "bars" — contiguous runs of same-colored columns. A
 *     color change always starts a new bar immediately, even when candles are
 *     touching with no gap (common on real charts); only *background* gaps get
 *     tolerance (see [maxColumnGapPx]) since background gaps and color changes
 *     are different signals — a run of background columns might just be
 *     anti-aliasing/grid-line noise between two columns of the *same* candle.
 *  2. Within each bar, separate body rows from wick rows using row coverage: a
 *     wick is a thin (typically 1-3px) vertical line, so most rows it touches have
 *     candle color in only a few of the bar's columns. A body is wide, so its rows
 *     have candle color across most of the bar's width. The row-coverage-fraction
 *     threshold ([bodyRowCoverageFraction]) is what separates the two — this is
 *     real geometric reasoning, not a name/shape lookup, so it works regardless of
 *     candle width, color, or exact rendering style.
 *
 * Never uses information from columns to the right of a candle to decide that
 * candle's own geometry — each bar's body/wick split only looks at pixels within
 * its own column range, so nothing here depends on "future" candles.
 */
class CandleDetector(
    private val colorProfile: CandleColorProfile = CandleColorProfile(),
    private val maxColumnGapPx: Int = 2,
    private val minBarWidthPx: Int = 2,
    private val bodyRowCoverageFraction: Float = 0.55f
) {

    fun detect(chartRegion: PixelBuffer): List<Candle> {
        if (chartRegion.width < minBarWidthPx || chartRegion.height < 2) return emptyList()

        val columnClass = Array(chartRegion.width) { x -> classifyColumn(chartRegion, x) }
        val bars = clusterIntoBars(columnClass)
            .filter { (start, end, _) -> end - start + 1 >= minBarWidthPx }

        // bars.lastIndex is taken AFTER filtering, so "isForming" correctly marks the
        // last surviving bar rather than the last bar before short ones were dropped.
        return bars.mapIndexedNotNull { index, (start, end, direction) ->
            buildCandle(chartRegion, index, start, end, direction, isLast = index == bars.lastIndex)
        }
    }

    /** @return the dominant candle-color class for a column, or null if the column has none. */
    private fun classifyColumn(buffer: PixelBuffer, x: Int): PixelClassification? {
        var bullish = 0
        var bearish = 0
        for (y in 0 until buffer.height) {
            when (colorProfile.classify(buffer.get(x, y))) {
                PixelClassification.BULLISH -> bullish++
                PixelClassification.BEARISH -> bearish++
                PixelClassification.OTHER -> Unit
            }
        }
        return when {
            bullish == 0 && bearish == 0 -> null
            bullish >= bearish -> PixelClassification.BULLISH
            else -> PixelClassification.BEARISH
        }
    }

    private data class BarSpan(val start: Int, val end: Int, val direction: PixelClassification)

    private fun clusterIntoBars(columnClass: Array<PixelClassification?>): List<BarSpan> {
        val bars = mutableListOf<BarSpan>()
        var barStart = -1
        var barDirection: PixelClassification? = null
        var lastColoredColumn = -1

        fun closeBar(endColumn: Int) {
            if (barStart != -1 && barDirection != null) {
                bars += BarSpan(barStart, endColumn, barDirection!!)
            }
            barStart = -1
            barDirection = null
        }

        for (x in columnClass.indices) {
            val cls = columnClass[x]
            if (cls == null) {
                if (barStart != -1 && x - lastColoredColumn > maxColumnGapPx) {
                    closeBar(lastColoredColumn)
                }
                continue
            }

            if (barStart == -1) {
                barStart = x
                barDirection = cls
            } else if (cls != barDirection) {
                // A color change always starts a new candle, regardless of how close it
                // is to the previous one. Real charts routinely render adjacent candles
                // touching or nearly touching with no background gap between them — gap
                // distance alone cannot be used to decide "this is still the same candle."
                // (A single stray anti-aliased column of the "wrong" color self-corrects:
                // it either matches whichever neighboring color has more pixels in that
                // column via classifyColumn's majority vote, or forms its own sub-minimum-
                // width bar that gets filtered out by minBarWidthPx.)
                closeBar(lastColoredColumn)
                barStart = x
                barDirection = cls
            }
            lastColoredColumn = x
        }
        closeBar(lastColoredColumn)

        return bars
    }

    private fun buildCandle(
        buffer: PixelBuffer,
        index: Int,
        xStart: Int,
        xEndInclusive: Int,
        direction: PixelClassification,
        isLast: Boolean
    ): Candle? {
        val xEnd = xEndInclusive + 1
        val barWidth = xEnd - xStart

        var wickTop = Int.MAX_VALUE
        var wickBottom = Int.MIN_VALUE
        val rowCoverage = IntArray(buffer.height)

        for (x in xStart until xEnd) {
            for (y in 0 until buffer.height) {
                val matches = colorProfile.classify(buffer.get(x, y)) == direction
                if (matches) {
                    rowCoverage[y]++
                    wickTop = min(wickTop, y)
                    wickBottom = max(wickBottom, y)
                }
            }
        }
        if (wickBottom < wickTop) return null // no matching pixels at all — defensive, shouldn't happen

        val coverageThreshold = barWidth * bodyRowCoverageFraction
        var bodyTop = -1
        var bodyBottom = -1
        for (y in wickTop..wickBottom) {
            if (rowCoverage[y] >= coverageThreshold) {
                if (bodyTop == -1) bodyTop = y
                bodyBottom = y
            }
        }
        // No row met the body-coverage threshold (e.g. an all-wick sliver, or a doji
        // rendered as a near-flat line) — treat the whole span as a minimal body at
        // its midpoint rather than fabricating a body that isn't visually there.
        if (bodyTop == -1) {
            val mid = (wickTop + wickBottom) / 2
            bodyTop = mid
            bodyBottom = mid
        }

        val totalPixelsInBar = barWidth * (wickBottom - wickTop + 1)
        val coloredPixels = rowCoverage.sliceArray(wickTop..wickBottom).sum()
        val purity = if (totalPixelsInBar > 0) coloredPixels.toFloat() / totalPixelsInBar else 0f
        val widthConfidence = (barWidth.toFloat() / MIN_CONFIDENT_WIDTH_PX).coerceAtMost(1f)
        val confidence = (0.7f * purity + 0.3f * widthConfidence).coerceIn(0f, 1f)

        return Candle(
            index = index,
            xStart = xStart,
            xEnd = xEnd,
            bodyTopY = bodyTop,
            bodyBottomY = bodyBottom,
            wickTopY = wickTop,
            wickBottomY = wickBottom,
            direction = if (direction == PixelClassification.BULLISH) CandleDirection.BULLISH else CandleDirection.BEARISH,
            isForming = isLast,
            confidence = confidence
        )
    }

    private companion object {
        const val MIN_CONFIDENT_WIDTH_PX = 6f
    }
}
