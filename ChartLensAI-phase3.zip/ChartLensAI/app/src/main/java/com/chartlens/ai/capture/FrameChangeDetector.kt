package com.chartlens.ai.capture

import kotlin.math.abs

/**
 * Decides whether a new frame differs enough from the previously analyzed frame
 * to be worth running through the (expensive) CV pipeline.
 *
 * Deliberately simple for Phase 1: downsampled luminance-bucket comparison rather
 * than full perceptual hashing. This is real logic (not a stub) but is expected to
 * be replaced/tuned once real chart footage is available to test against — see
 * README "Known limitations".
 *
 * Pure Kotlin, no Android/Bitmap dependency, so it is directly unit-testable with
 * synthetic pixel arrays.
 */
class FrameChangeDetector(
    private val changeThreshold: Double = 0.015 // fraction of sampled pixels that must differ
) {
    private var previousSample: IntArray? = null

    /**
     * @param pixelSample a downsampled ARGB pixel array of the current frame
     *   (caller is responsible for downsampling — this class does not touch Bitmap).
     * @return true if this frame should be analyzed.
     */
    fun hasMateriallyChanged(pixelSample: IntArray): Boolean {
        val previous = previousSample
        previousSample = pixelSample.copyOf()

        if (previous == null || previous.size != pixelSample.size) {
            return true // first frame, or resolution changed — always analyze
        }

        var differing = 0
        for (i in pixelSample.indices) {
            if (colorDistance(previous[i], pixelSample[i]) > PER_PIXEL_DIFF_THRESHOLD) {
                differing++
            }
        }

        val differingFraction = differing.toDouble() / pixelSample.size
        return differingFraction >= changeThreshold
    }

    fun reset() {
        previousSample = null
    }

    private fun colorDistance(a: Int, b: Int): Int {
        val rDiff = abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF))
        val gDiff = abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF))
        val bDiff = abs((a and 0xFF) - (b and 0xFF))
        return rDiff + gDiff + bDiff
    }

    private companion object {
        const val PER_PIXEL_DIFF_THRESHOLD = 24 // sum of RGB channel deltas
    }
}
