package com.chartlens.ai.common

/**
 * Minimal RGB->HSV conversion in pure Kotlin (no android.graphics.Color), so the
 * candle-color classification logic in [com.chartlens.ai.cv.CandleColorProfile]
 * can be unit tested on the JVM without an Android runtime or Robolectric.
 */
object ColorMath {

    /** @return hue in degrees [0, 360), saturation [0, 1], value [0, 1] for an ARGB int. */
    fun rgbToHsv(argb: Int): FloatArray {
        val r = ((argb shr 16) and 0xFF) / 255f
        val g = ((argb shr 8) and 0xFF) / 255f
        val b = (argb and 0xFF) / 255f

        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val delta = max - min

        val hue = when {
            delta == 0f -> 0f
            max == r -> 60f * (((g - b) / delta) % 6f)
            max == g -> 60f * (((b - r) / delta) + 2f)
            else -> 60f * (((r - g) / delta) + 4f)
        }.let { if (it < 0f) it + 360f else it }

        val saturation = if (max == 0f) 0f else delta / max
        val value = max

        return floatArrayOf(hue, saturation, value)
    }

    fun alpha(argb: Int): Int = (argb shr 24) and 0xFF
}
