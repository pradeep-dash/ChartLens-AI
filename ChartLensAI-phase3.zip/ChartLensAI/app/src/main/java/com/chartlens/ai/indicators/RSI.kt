package com.chartlens.ai.indicators

/**
 * RSI using Wilder's original smoothing (not a plain moving average of gains/
 * losses) — the standard, most widely implemented RSI variant. Returns `null`
 * for indices before [period] + 1 closes exist, since RSI needs at least
 * [period] price changes (period+1 closes) to compute its first value.
 */
object RSI {

    fun calculate(closes: List<Double>, period: Int = 14): List<Double?> {
        require(period > 0) { "period must be positive" }
        if (closes.size < period + 1) return List(closes.size) { null }

        val result = MutableList<Double?>(closes.size) { null }

        var gainSum = 0.0
        var lossSum = 0.0
        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change > 0) gainSum += change else lossSum += -change
        }
        var avgGain = gainSum / period
        var avgLoss = lossSum / period
        result[period] = rsiFromAverages(avgGain, avgLoss)

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
            result[i] = rsiFromAverages(avgGain, avgLoss)
        }
        return result
    }

    private fun rsiFromAverages(avgGain: Double, avgLoss: Double): Double {
        if (avgLoss == 0.0) return 100.0
        val relativeStrength = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + relativeStrength))
    }
}
