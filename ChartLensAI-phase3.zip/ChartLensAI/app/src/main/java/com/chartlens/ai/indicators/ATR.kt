package com.chartlens.ai.indicators

import com.chartlens.ai.analysis.PriceCandle
import kotlin.math.abs

/**
 * ATR using Wilder's smoothing. True range needs the previous candle's close
 * (to catch gaps), so the very first candle has no true range and is excluded
 * from both the input window and the output.
 */
object ATR {

    fun calculate(candles: List<PriceCandle>, period: Int = 14): List<Double?> {
        require(period > 0) { "period must be positive" }
        if (candles.size < period + 1) return List(candles.size) { null }

        val trueRanges = DoubleArray(candles.size)
        for (i in candles.indices) {
            trueRanges[i] = if (i == 0) {
                candles[i].high - candles[i].low
            } else {
                val highLow = candles[i].high - candles[i].low
                val highPrevClose = abs(candles[i].high - candles[i - 1].close)
                val lowPrevClose = abs(candles[i].low - candles[i - 1].close)
                maxOf(highLow, highPrevClose, lowPrevClose)
            }
        }

        val result = MutableList<Double?>(candles.size) { null }
        // Wilder seeds from TR[1..period] (index 0's true range has no prior close, so
        // it's a less reliable seed value and is conventionally excluded).
        var atr = trueRanges.toList().subList(1, period + 1).average()
        result[period] = atr

        for (i in (period + 1) until candles.size) {
            atr = (atr * (period - 1) + trueRanges[i]) / period
            result[i] = atr
        }
        return result
    }
}
