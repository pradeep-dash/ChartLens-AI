package com.chartlens.ai.common

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Holds a small, downscaled copy of the most recently captured frame, purely so
 * the manual chart-region selection screen has something to show the user to
 * drag a crop rectangle over. This is a UI convenience copy, not part of the
 * analysis pipeline — [com.chartlens.ai.cv.FrameAnalyzer] never reads from here,
 * it receives frames directly from the capture flow.
 *
 * Kept intentionally small (see [MAX_PREVIEW_DIMENSION_PX]) since it's held in
 * memory for as long as the app process lives.
 */
@Singleton
class LatestFrameHolder @Inject constructor() {

    private val _preview = MutableStateFlow<Bitmap?>(null)
    val preview: StateFlow<Bitmap?> = _preview.asStateFlow()

    /** Original (full) frame dimensions, needed so a selection can be normalized correctly. */
    private val _originalDimensions = MutableStateFlow<Pair<Int, Int>?>(null)
    val originalDimensions: StateFlow<Pair<Int, Int>?> = _originalDimensions.asStateFlow()

    fun update(fullFrame: Bitmap) {
        val previous = _preview.value
        val scale = MAX_PREVIEW_DIMENSION_PX.toFloat() / maxOf(fullFrame.width, fullFrame.height)
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                fullFrame,
                (fullFrame.width * scale).toInt().coerceAtLeast(1),
                (fullFrame.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else {
            fullFrame.copy(fullFrame.config ?: Bitmap.Config.ARGB_8888, false)
        }
        _originalDimensions.value = fullFrame.width to fullFrame.height
        _preview.value = scaled
        previous?.takeIf { !it.isRecycled }?.recycle()
    }

    private companion object {
        const val MAX_PREVIEW_DIMENSION_PX = 720
    }
}
