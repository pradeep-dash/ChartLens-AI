package com.chartlens.ai.indicators

import kotlin.math.sqrt

data class BollingerPoint(val middle: Double, val upper: Double, val lower: Double)

object BollingerBands {

    fun calculate(
        closes: List<Double>,
        period: Int = 20,
        standardDeviations: Double = 2.0
    ): List<BollingerPoint?> {
        require(period > 0) { "period must be positive" }
        if (closes.size < period) return List(closes.size) { null }

        val result = MutableList<BollingerPoint?>(closes.size) { null }
        for (i in (period - 1) until closes.size) {
            val window = closes.subList(i - period + 1, i + 1)
            val mean = window.average()
            val variance = window.sumOf { (it - mean) * (it - mean) } / period
            val stdDev = sqrt(variance)
            result[i] = BollingerPoint(
                middle = mean,
                upper = mean + standardDeviations * stdDev,
                lower = mean - standardDeviations * stdDev
            )
        }
        return result
    }
}
