package com.chartlens.ai.common

/**
 * Represents the real, observable state of the screen-capture pipeline.
 *
 * IMPORTANT: This intentionally does NOT include chart/candle/prediction fields.
 * Those belong to later phases (CV, analysis, prediction) and must not be
 * fabricated here. A [CaptureState.Capturing] value means "frames are being
 * read from the screen" — nothing more. Do not infer analysis readiness from it.
 */
sealed interface CaptureState {

    /** No capture session exists. Initial state and state after a clean stop. */
    data object Idle : CaptureState

    /** Waiting on the user to grant notification / overlay / MediaProjection permissions. */
    data object AwaitingPermission : CaptureState

    /** MediaProjection is active and frames are being read from the screen. */
    data class Capturing(
        val frameWidth: Int,
        val frameHeight: Int,
        val capturedFrameCount: Long,
        val analyzedFrameCount: Long,
        val lastFrameAtMillis: Long,
        val startedAtMillis: Long
    ) : CaptureState

    /** The user or the system stopped capture (e.g. "Stop casting" from system UI). */
    data object Stopped : CaptureState

    /** Something in the capture pipeline failed. [recoverable] hints whether retrying start() is reasonable. */
    data class Error(val message: String, val recoverable: Boolean) : CaptureState
}
