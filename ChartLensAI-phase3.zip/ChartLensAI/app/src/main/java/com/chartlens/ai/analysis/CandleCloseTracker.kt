package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import kotlin.math.abs

data class CandleCloseEvent(val closedCandle: Candle)

/**
 * Detects the moment a candle stops forming and becomes closed, by comparing
 * consecutive [Candle] lists over time. Never uses OCR/timeframe — the signal
 * is purely "the candle that used to be forming is now counted as closed,"
 * matched by X position with tolerance (detection geometry can shift a few
 * pixels frame to frame even for the same real candle).
 *
 * Per the spec's "detect when candle closes → freeze OHLC → generate
 * prediction for next candle" flow: this class only detects the transition.
 * Freezing state, generating a prediction, and journaling are later phases'
 * responsibility (Phase 5/7) — this class deliberately does one thing.
 */
class CandleCloseTracker(private val xPositionToleranceRatio: Double = 0.5) {

    private var previousClosedCount = 0
    private var previousFormingXStart: Int? = null

    fun update(candles: List<Candle>): CandleCloseEvent? {
        val closed = candles.filterNot { it.isForming }
        val forming = candles.firstOrNull { it.isForming }

        val event = if (previousFormingXStart != null && closed.size > previousClosedCount) {
            val candidate = closed.lastOrNull()
            val tolerancePx = (candidate?.bodyWidthPx ?: 1) * xPositionToleranceRatio
            if (candidate != null && abs(candidate.xStart - previousFormingXStart!!) <= tolerancePx) {
                CandleCloseEvent(candidate)
            } else {
                null // count grew, but geometry doesn't match — likely a re-detection jump, not a real close
            }
        } else {
            null
        }

        previousClosedCount = closed.size
        previousFormingXStart = forming?.xStart
        return event
    }

    /** Call when the chart region changes (manual selection, re-detection jump) to avoid a false "close" event. */
    fun reset() {
        previousClosedCount = 0
        previousFormingXStart = null
    }
}
