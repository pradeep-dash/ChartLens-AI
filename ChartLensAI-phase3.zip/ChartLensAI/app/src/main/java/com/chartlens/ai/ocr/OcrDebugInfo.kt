package com.chartlens.ai.ocr

/**
 * Diagnostic-only snapshot of what the last OCR pass actually saw, before any
 * price/time parsing. Exists purely to make remote debugging possible without
 * device log access — this distinguishes "ML Kit found zero text in the
 * cropped strip" (crop region or image quality problem) from "ML Kit found
 * text but none of it parsed as a price/time" (format/regex problem), which
 * otherwise look identical from the outside ("Price: unmapped").
 */
data class OcrDebugInfo(
    val priceAxisRawTexts: List<String>,
    val timeAxisRawTexts: List<String>
)
