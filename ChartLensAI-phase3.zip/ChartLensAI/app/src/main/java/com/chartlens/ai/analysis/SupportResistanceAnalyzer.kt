package com.chartlens.ai.analysis

data class PriceLevel(val price: Double, val touchCount: Int)

enum class BreakoutStatus { NONE, BROKE_ABOVE_RESISTANCE, BROKE_BELOW_SUPPORT }
enum class RejectionStatus { NONE, REJECTED_AT_RESISTANCE, REJECTED_AT_SUPPORT }

data class SupportResistanceResult(
    val supportLevels: List<PriceLevel>,
    val resistanceLevels: List<PriceLevel>,
    val nearestSupport: Double?,
    val nearestResistance: Double?,
    val breakoutStatus: BreakoutStatus,
    val rejectionStatus: RejectionStatus
)

/**
 * Clusters swing highs/lows into repeated reaction levels (using a price-
 * distance tolerance rather than exact equality, per the spec) and evaluates
 * the most recent candle against levels established by the candles *before*
 * it — never against a level that candle itself contributed to, which would
 * be circular ("this candle broke a level built partly from its own high").
 */
class SupportResistanceAnalyzer(
    private val swingLookback: Int = 2,
    private val clusterTolerancePercent: Double = 0.15,
    private val rejectionWickTolerancePercent: Double = 0.1
) {
    private val trendAnalyzer = TrendAnalyzer(swingLookback = swingLookback)

    fun analyze(candles: List<PriceCandle>): SupportResistanceResult {
        if (candles.isEmpty()) {
            return SupportResistanceResult(emptyList(), emptyList(), null, null, BreakoutStatus.NONE, RejectionStatus.NONE)
        }

        val priorCandles = candles.dropLast(1)
        val highs = trendAnalyzer.findSwingHighs(priorCandles)
        val lows = trendAnalyzer.findSwingLows(priorCandles)

        val resistanceLevels = clusterLevels(highs.map { it.price })
        val supportLevels = clusterLevels(lows.map { it.price })

        val currentPrice = candles.last().close
        val nearestResistance = resistanceLevels.map { it.price }.filter { it >= currentPrice }.minOrNull()
            ?: resistanceLevels.map { it.price }.maxOrNull()
        val nearestSupport = supportLevels.map { it.price }.filter { it <= currentPrice }.maxOrNull()
            ?: supportLevels.map { it.price }.minOrNull()

        val latest = candles.last()
        val breakout = detectBreakout(latest, nearestSupport, nearestResistance)
        val rejection = detectRejection(latest, nearestSupport, nearestResistance)

        return SupportResistanceResult(
            supportLevels = supportLevels,
            resistanceLevels = resistanceLevels,
            nearestSupport = nearestSupport,
            nearestResistance = nearestResistance,
            breakoutStatus = breakout,
            rejectionStatus = rejection
        )
    }

    private fun detectBreakout(latest: PriceCandle, support: Double?, resistance: Double?): BreakoutStatus {
        if (resistance != null && latest.close > resistance) return BreakoutStatus.BROKE_ABOVE_RESISTANCE
        if (support != null && latest.close < support) return BreakoutStatus.BROKE_BELOW_SUPPORT
        return BreakoutStatus.NONE
    }

    private fun detectRejection(latest: PriceCandle, support: Double?, resistance: Double?): RejectionStatus {
        if (resistance != null) {
            val touchedResistance = latest.high >= resistance * (1 - rejectionWickTolerancePercent / 100.0)
            if (touchedResistance && latest.close < resistance) return RejectionStatus.REJECTED_AT_RESISTANCE
        }
        if (support != null) {
            val touchedSupport = latest.low <= support * (1 + rejectionWickTolerancePercent / 100.0)
            if (touchedSupport && latest.close > support) return RejectionStatus.REJECTED_AT_SUPPORT
        }
        return RejectionStatus.NONE
    }

    private fun clusterLevels(prices: List<Double>): List<PriceLevel> {
        if (prices.isEmpty()) return emptyList()
        val sorted = prices.sorted()
        val clusters = mutableListOf<MutableList<Double>>()

        for (price in sorted) {
            val lastCluster = clusters.lastOrNull()
            val clusterAverage = lastCluster?.average()
            val withinTolerance = clusterAverage != null &&
                clusterAverage > 0 &&
                kotlin.math.abs(price - clusterAverage) / clusterAverage <= clusterTolerancePercent / 100.0

            if (lastCluster != null && withinTolerance) {
                lastCluster += price
            } else {
                clusters += mutableListOf(price)
            }
        }

        return clusters
            .map { PriceLevel(price = it.average(), touchCount = it.size) }
            .sortedByDescending { it.touchCount }
    }
}
