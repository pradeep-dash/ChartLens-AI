package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle

enum class DataQuality { GOOD, FAIR, POOR, INVALID }

/**
 * Combines chart-region confidence, candle-detection confidence, and — now
 * that Phase 3 exists — price-scale mapping confidence into one tier. Price
 * mapping confidence is optional (null when OCR hasn't run yet or found
 * nothing usable) and, when present, is factored in but never allowed to
 * upgrade a POOR chart/candle read into GOOD — a confident price axis doesn't
 * make up for not actually finding the candles.
 */
object DataQualityCalculator {

    fun calculate(
        chartRegionConfidence: Float,
        candles: List<Candle>,
        priceScaleConfidence: Float? = null
    ): DataQuality {
        if (candles.isEmpty()) return DataQuality.INVALID

        val averageCandleConfidence = candles.map { it.confidence }.average().toFloat()
        val closedCandleCount = candles.count { !it.isForming }
        val combinedConfidence = 0.5f * chartRegionConfidence + 0.5f * averageCandleConfidence

        val baseTier = when {
            combinedConfidence >= 0.75f && closedCandleCount >= 20 -> DataQuality.GOOD
            combinedConfidence >= 0.55f && closedCandleCount >= 8 -> DataQuality.FAIR
            combinedConfidence > 0f -> DataQuality.POOR
            else -> DataQuality.INVALID
        }

        if (priceScaleConfidence == null) return baseTier

        // A weak price mapping can only pull the tier down, never up.
        return if (priceScaleConfidence < 0.5f && baseTier == DataQuality.GOOD) {
            DataQuality.FAIR
        } else {
            baseTier
        }
    }
}

