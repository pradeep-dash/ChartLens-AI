package com.chartlens.ai.settings

import android.content.Context
import androidx.core.content.edit
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Persists the user's manual chart-region selection (see spec §5 "Manual Chart
 * Selection" fallback). Deliberately global rather than per-app: identifying
 * which app is currently in the foreground would require the
 * `PACKAGE_USAGE_STATS` permission (a separate, fairly invasive special-access
 * grant) that this project doesn't otherwise need. A global selection is a real
 * limitation — switching trading apps means re-selecting — documented in the
 * README rather than silently assumed away.
 */
@Singleton
class ManualChartRegionStore @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun save(rect: NormalizedRect) {
        prefs.edit {
            putFloat(KEY_LEFT, rect.left)
            putFloat(KEY_TOP, rect.top)
            putFloat(KEY_RIGHT, rect.right)
            putFloat(KEY_BOTTOM, rect.bottom)
        }
    }

    fun load(): NormalizedRect? {
        if (!prefs.contains(KEY_LEFT)) return null
        return NormalizedRect(
            left = prefs.getFloat(KEY_LEFT, 0f),
            top = prefs.getFloat(KEY_TOP, 0f),
            right = prefs.getFloat(KEY_RIGHT, 1f),
            bottom = prefs.getFloat(KEY_BOTTOM, 1f)
        )
    }

    fun clear() {
        prefs.edit { clear() }
    }

    private companion object {
        const val PREFS_NAME = "chartlens_manual_region"
        const val KEY_LEFT = "left"
        const val KEY_TOP = "top"
        const val KEY_RIGHT = "right"
        const val KEY_BOTTOM = "bottom"
    }
}
