package com.chartlens.ai.cv

import com.chartlens.ai.common.ColorMath
import com.chartlens.ai.common.PixelBuffer

/**
 * Classifies a pixel as belonging to a bullish candle, a bearish candle, or
 * neither (background/grid/text/UI chrome).
 *
 * Deliberately hue-range based rather than an exact RGB match, per the "do not
 * hardcode candle colors" rule — a trading platform's green/red (or teal/red, as
 * on the platform this was tested against) will vary in exact shade across
 * themes, but bullish colors cluster in the green/teal hue band and bearish
 * colors cluster in the red hue band almost universally. [thresholds] can be
 * overridden per-platform if a future auto-calibration step (sampling the
 * chart's actual dominant colors) proves more accurate than these defaults —
 * see [PixelClassification.OTHER] for what happens when neither band matches.
 */
data class CandleColorProfile(
    val bullishHueRange: ClosedFloatingPointRange<Float> = 140f..190f, // green/teal
    val bearishHueRange: ClosedFloatingPointRange<Float> = 345f..360f, // red band, part 1 (wraps 0)
    val bearishHueRangeWrap: ClosedFloatingPointRange<Float> = 0f..20f, // red band, part 2
    val minSaturation: Float = 0.35f,
    val minValue: Float = 0.25f,
    val minAlpha: Int = 200
) {
    fun classify(argb: Int): PixelClassification {
        if (ColorMath.alpha(argb) < minAlpha) return PixelClassification.OTHER

        val (hue, saturation, value) = ColorMath.rgbToHsv(argb)
        if (saturation < minSaturation || value < minValue) return PixelClassification.OTHER

        return when {
            hue in bullishHueRange -> PixelClassification.BULLISH
            hue in bearishHueRange || hue in bearishHueRangeWrap -> PixelClassification.BEARISH
            else -> PixelClassification.OTHER
        }
    }
}

enum class PixelClassification { BULLISH, BEARISH, OTHER }

/** Convenience destructuring for the FloatArray returned by [ColorMath.rgbToHsv]. */
private operator fun FloatArray.component1() = this[0]
private operator fun FloatArray.component2() = this[1]
private operator fun FloatArray.component3() = this[2]
