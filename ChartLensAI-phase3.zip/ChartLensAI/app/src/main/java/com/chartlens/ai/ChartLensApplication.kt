package com.chartlens.ai

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. Hilt generates the DI component graph from here.
 *
 * Kept intentionally thin — no capture/analysis logic lives at the Application
 * level so that ScreenCaptureService and OverlayService can be started, stopped,
 * and tested independently of app process lifecycle assumptions.
 */
@HiltAndroidApp
class ChartLensApplication : Application()
