package com.chartlens.ai.candle

/** Bullish (up/green) or bearish (down/red) — direction only, not a price claim. */
enum class CandleDirection { BULLISH, BEARISH }

/**
 * A single detected candle, described entirely in pixel geometry.
 *
 * IMPORTANT: there is no `open`/`high`/`low`/`close` price field here on purpose.
 * Phase 2 has no price-axis mapping yet (that is Phase 3's `PriceScaleMapper` job,
 * per the "never fabricate OHLC" rule) — so this model exposes Y pixel coordinates
 * (suffixed `Y`) instead of prices. [openY]/[closeY]/[highY]/[lowY] are the correct
 * pixel-space analogues (screen Y increases downward, so a smaller Y is a higher
 * price) and should be run through the price mapper once it exists, not treated
 * as prices themselves.
 */
data class Candle(
    val index: Int,
    val xStart: Int,
    val xEnd: Int,
    val bodyTopY: Int,
    val bodyBottomY: Int,
    val wickTopY: Int,
    val wickBottomY: Int,
    val direction: CandleDirection,
    /**
     * True for the rightmost detected candle only. Phase 2 has no time-axis/close
     * detection yet (that's Phase 3 §15), so this is a conservative convention —
     * "we cannot yet prove this candle has closed" — not a real close-time
     * determination. Callers must not treat this candle as historical data.
     */
    val isForming: Boolean,
    /** 0..1. See [com.chartlens.ai.candle.CandleDetector] for how this is derived. */
    val confidence: Float
) {
    val bodyWidthPx: Int get() = (xEnd - xStart).coerceAtLeast(0)
    val bodyHeightPx: Int get() = (bodyBottomY - bodyTopY).coerceAtLeast(0)
    val upperWickPx: Int get() = (bodyTopY - wickTopY).coerceAtLeast(0)
    val lowerWickPx: Int get() = (wickBottomY - bodyBottomY).coerceAtLeast(0)

    /** Pixel-Y analogue of "open". Smaller Y = higher on screen = higher price once mapped. */
    val openY: Int get() = if (direction == CandleDirection.BULLISH) bodyBottomY else bodyTopY

    /** Pixel-Y analogue of "close". */
    val closeY: Int get() = if (direction == CandleDirection.BULLISH) bodyTopY else bodyBottomY

    /** Pixel-Y analogue of "high" (top of the wick). */
    val highY: Int get() = wickTopY

    /** Pixel-Y analogue of "low" (bottom of the wick). */
    val lowY: Int get() = wickBottomY
}
