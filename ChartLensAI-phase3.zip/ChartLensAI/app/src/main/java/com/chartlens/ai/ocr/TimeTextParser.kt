package com.chartlens.ai.ocr

/**
 * Parses a time-axis label like "21:36" into minutes since midnight. Returns
 * null for anything that doesn't look like a valid 24-hour time — never
 * guesses at a partially-garbled reading.
 *
 * Known limitation: does not handle a chart spanning midnight (e.g. labels
 * "23:52" then "00:08") — [com.chartlens.ai.analysis.TimeframeDetector] fits a
 * simple linear regression over these values, which would see the wraparound
 * as a large negative jump rather than a small forward step. Documented rather
 * than silently handled; worth fixing if real testing shows charts commonly
 * cross midnight.
 */
object TimeTextParser {

    private val pattern = Regex("""(\d{1,2}):(\d{2})""")

    fun parseMinutesSinceMidnight(rawText: String): Int? {
        val match = pattern.find(rawText.trim()) ?: return null
        val hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        return hour * 60 + minute
    }
}
