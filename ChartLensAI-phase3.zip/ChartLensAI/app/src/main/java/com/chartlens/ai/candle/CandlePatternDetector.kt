package com.chartlens.ai.candle

/**
 * Scores candle patterns from geometry (body/wick ratios, and body-range
 * containment for multi-candle patterns) rather than matching against named
 * templates — per the "score patterns based on geometry rather than simply
 * matching names" requirement. Operates purely on already-detected [Candle]
 * data, so it's fully unit-testable without any pixel/bitmap input.
 */
class CandlePatternDetector(
    private val dojiBodyToRangeMax: Float = 0.10f,
    private val spinningTopBodyToRangeMax: Float = 0.35f,
    private val smallBodyToRangeMax: Float = 0.30f, // used by hammer/inverted-hammer/shooting-star
    private val longWickToBodyMin: Float = 2.0f,
    private val negligibleWickToRangeMax: Float = 0.10f,
    private val momentumBodyMultiplier: Float = 1.5f,
    private val momentumWickToBodyMax: Float = 0.3f,
    private val rejectionWickToRangeMin: Float = 0.5f
) {

    fun detect(candles: List<Candle>): List<CandlePatternMatch> {
        if (candles.isEmpty()) return emptyList()

        val averageBodyHeight = candles
            .filterNot { it.isForming }
            .map { it.bodyHeightPx.coerceAtLeast(1) }
            .let { heights -> if (heights.isEmpty()) 0.0 else heights.average() }

        return candles.mapIndexed { i, candle ->
            val patterns = mutableSetOf<CandlePattern>()

            patterns += singleCandlePatterns(candle)
            if (averageBodyHeight > 0 && isStrongMomentum(candle, averageBodyHeight)) {
                patterns += CandlePattern.STRONG_MOMENTUM
            }
            if (i > 0) {
                patterns += pairwisePatterns(previous = candles[i - 1], current = candle)
            }

            CandlePatternMatch(candleIndex = candle.index, patterns = patterns)
        }
    }

    private fun singleCandlePatterns(candle: Candle): Set<CandlePattern> {
        val range = (candle.wickBottomY - candle.wickTopY).coerceAtLeast(1)
        val bodyToRange = candle.bodyHeightPx.toFloat() / range
        val patterns = mutableSetOf<CandlePattern>()

        if (bodyToRange <= dojiBodyToRangeMax) {
            patterns += CandlePattern.DOJI
        } else if (bodyToRange <= spinningTopBodyToRangeMax) {
            val upperRatio = candle.upperWickPx.toFloat() / range
            val lowerRatio = candle.lowerWickPx.toFloat() / range
            val bothWicksPresent = upperRatio > negligibleWickToRangeMax && lowerRatio > negligibleWickToRangeMax
            val wicksComparable = smallerOf(upperRatio, lowerRatio) / largerOf(upperRatio, lowerRatio).coerceAtLeast(0.001f) > 0.4f
            if (bothWicksPresent && wicksComparable) {
                patterns += CandlePattern.SPINNING_TOP
            }
        }

        if (bodyToRange <= smallBodyToRangeMax && candle.bodyHeightPx > 0) {
            val upperRatio = candle.upperWickPx.toFloat() / range
            val lowerRatio = candle.lowerWickPx.toFloat() / range
            val longLowerWick = candle.lowerWickPx >= longWickToBodyMin * candle.bodyHeightPx && upperRatio <= negligibleWickToRangeMax
            val longUpperWick = candle.upperWickPx >= longWickToBodyMin * candle.bodyHeightPx && lowerRatio <= negligibleWickToRangeMax

            if (longLowerWick) {
                patterns += CandlePattern.HAMMER // shape-only label; see CandlePattern doc
            }
            if (longUpperWick) {
                patterns += if (candle.direction == CandleDirection.BULLISH) {
                    CandlePattern.INVERTED_HAMMER
                } else {
                    CandlePattern.SHOOTING_STAR
                }
            }
        }

        val upperRejection = candle.upperWickPx.toFloat() / range >= rejectionWickToRangeMin
        val lowerRejection = candle.lowerWickPx.toFloat() / range >= rejectionWickToRangeMin
        if ((upperRejection || lowerRejection) && candle.bodyHeightPx.toFloat() / range < smallBodyToRangeMax) {
            patterns += CandlePattern.LONG_WICK_REJECTION
        }

        return patterns
    }

    private fun isStrongMomentum(candle: Candle, averageBodyHeight: Double): Boolean {
        if (candle.bodyHeightPx <= 0) return false
        val bodyIsLarge = candle.bodyHeightPx >= momentumBodyMultiplier * averageBodyHeight
        val totalWick = candle.upperWickPx + candle.lowerWickPx
        val wicksAreSmall = totalWick <= momentumWickToBodyMax * candle.bodyHeightPx
        return bodyIsLarge && wicksAreSmall
    }

    private fun pairwisePatterns(previous: Candle, current: Candle): Set<CandlePattern> {
        val patterns = mutableSetOf<CandlePattern>()

        val currentEngulfsPrevious =
            current.bodyTopY <= previous.bodyTopY &&
                current.bodyBottomY >= previous.bodyBottomY &&
                current.bodyHeightPx > previous.bodyHeightPx

        if (currentEngulfsPrevious && previous.direction != current.direction) {
            patterns += if (current.direction == CandleDirection.BULLISH) {
                CandlePattern.BULLISH_ENGULFING
            } else {
                CandlePattern.BEARISH_ENGULFING
            }
        }

        val currentInsidePrevious =
            current.wickTopY >= previous.wickTopY && current.wickBottomY <= previous.wickBottomY
        if (currentInsidePrevious) {
            patterns += CandlePattern.INSIDE_BAR
        }

        return patterns
    }

    private fun smallerOf(a: Float, b: Float) = if (a < b) a else b
    private fun largerOf(a: Float, b: Float) = if (a > b) a else b
}
