package com.chartlens.ai.common

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for capture pipeline state, shared in-process between
 * ScreenCaptureService (writer), OverlayService (reader), and MainActivity (reader/writer).
 *
 * All three components run in the same app process (no android:process split in the
 * manifest), so a Hilt-scoped singleton StateFlow is sufficient — no IPC/Binder needed.
 */
@Singleton
class CaptureStateRepository @Inject constructor() {

    private val _state = MutableStateFlow<CaptureState>(CaptureState.Idle)
    val state: StateFlow<CaptureState> = _state.asStateFlow()

    fun update(newState: CaptureState) {
        _state.value = newState
    }

    fun current(): CaptureState = _state.value
}
