package com.chartlens.ai.capture

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Owns the MediaProjection → VirtualDisplay → ImageReader chain and turns raw
 * [Image] callbacks into a throttled [Flow] of [CapturedFrame].
 *
 * Lifecycle contract (enforced by the caller, [com.chartlens.ai.service.ScreenCaptureService]):
 *  1. [start] must be called with an already-obtained, non-null [MediaProjection].
 *  2. Exactly one [release] must follow every [start], even on error paths.
 *  3. On screen rotation / density change, the caller must [release] and [start] again
 *     with new target dimensions — a VirtualDisplay's surface size is fixed at creation.
 *
 * This class deliberately does NOT touch MediaProjection permission/Intent handling —
 * that belongs to the Activity/Service boundary, not the capture engine.
 */
class ScreenCaptureController(
    private val minFrameIntervalMillis: Long = 200L, // caps raw acquisition at 5fps
    private val changeDetector: FrameChangeDetector = FrameChangeDetector()
) {
    private var handlerThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var lastAcceptedFrameAtMillis = 0L
    private var lastEmittedFrameAtMillis = 0L

    /**
     * Starts capturing and returns a cold-ish Flow (actually hot for the controller's
     * lifetime — call [release] to tear down; collecting a second time after release
     * requires a new [start] call).
     */
    fun start(
        mediaProjection: MediaProjection,
        targetWidthPx: Int,
        targetHeightPx: Int,
        screenDensityDpi: Int,
        onProjectionStopped: () -> Unit
    ): Flow<CapturedFrame> = callbackFlow {
        val thread = HandlerThread("ChartLensCapture").apply { start() }
        handlerThread = thread
        val handler = Handler(thread.looper)
        backgroundHandler = handler

        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "MediaProjection stopped by system/user")
                onProjectionStopped()
                close()
            }
        }
        projectionCallback = callback
        // Must be registered before createVirtualDisplay on modern Android versions.
        mediaProjection.registerCallback(callback, handler)

        val reader = ImageReader.newInstance(
            targetWidthPx,
            targetHeightPx,
            PixelFormat.RGBA_8888,
            /* maxImages = */ 2
        )
        imageReader = reader

        reader.setOnImageAvailableListener({ imageReaderRef ->
            val image = try {
                imageReaderRef.acquireLatestImage()
            } catch (t: Throwable) {
                Log.w(TAG, "acquireLatestImage failed", t)
                null
            } ?: return@setOnImageAvailableListener

            try {
                val now = System.currentTimeMillis()
                if (now - lastAcceptedFrameAtMillis < minFrameIntervalMillis) {
                    return@setOnImageAvailableListener // throttled — drop this frame
                }

                val bitmap = imageToBitmap(image, targetWidthPx, targetHeightPx)
                if (bitmap == null) {
                    return@setOnImageAvailableListener
                }

                val sample = downsampleForChangeDetection(bitmap)
                val changed = changeDetector.hasMateriallyChanged(sample)
                val isHeartbeat = now - lastEmittedFrameAtMillis >= HEARTBEAT_INTERVAL_MILLIS

                lastAcceptedFrameAtMillis = now

                // Only push a frame downstream when something actually changed, or when
                // enough time has passed that the UI needs a freshness heartbeat (so the
                // overlay's "Updated Xs ago" doesn't look frozen on a static chart).
                // This is the "avoid unnecessary processing" throttle from the spec —
                // real CV work in Phase 2 should further gate on `hasMaterialChange`.
                if (changed || isHeartbeat) {
                    lastEmittedFrameAtMillis = now
                    val result = trySend(
                        CapturedFrame(
                            bitmap = bitmap,
                            width = targetWidthPx,
                            height = targetHeightPx,
                            timestampMillis = now,
                            hasMaterialChange = changed
                        )
                    )
                    if (result.isFailure) {
                        Log.w(TAG, "Frame dropped — downstream not consuming fast enough")
                    }
                } else {
                    bitmap.recycle()
                }
            } finally {
                image.close()
            }
        }, handler)

        val display = mediaProjection.createVirtualDisplay(
            "ChartLensAI-Capture",
            targetWidthPx,
            targetHeightPx,
            screenDensityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            /* callback = */ null,
            handler
        )
        virtualDisplay = display

        if (display == null) {
            close(IllegalStateException("createVirtualDisplay returned null"))
        }

        awaitClose {
            releaseInternal()
        }
    }

    /** Explicit teardown — safe to call multiple times. */
    fun release() {
        releaseInternal()
    }

    private fun releaseInternal() {
        try {
            virtualDisplay?.release()
        } catch (t: Throwable) {
            Log.w(TAG, "Error releasing VirtualDisplay", t)
        }
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "Error closing ImageReader", t)
        }
        imageReader = null

        projectionCallback = null // MediaProjection.stop() (caller-owned) will drop the ref

        try {
            handlerThread?.quitSafely()
        } catch (t: Throwable) {
            Log.w(TAG, "Error quitting capture HandlerThread", t)
        }
        handlerThread = null
        backgroundHandler = null

        changeDetector.reset()
        lastAcceptedFrameAtMillis = 0L
        lastEmittedFrameAtMillis = 0L
    }

    /**
     * Converts an RGBA_8888 [Image] to a [Bitmap], accounting for row-stride padding
     * that ImageReader frequently adds (surface width is often wider than requested
     * width for alignment reasons).
     */
    private fun imageToBitmap(image: Image, requestedWidth: Int, requestedHeight: Int): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * requestedWidth

            val bitmap = Bitmap.createBitmap(
                requestedWidth + rowPadding / pixelStride,
                requestedHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            if (rowPadding == 0) {
                bitmap
            } else {
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, requestedWidth, requestedHeight)
                bitmap.recycle()
                cropped
            }
        } catch (t: Throwable) {
            Log.w(TAG, "imageToBitmap failed", t)
            null
        }
    }

    /**
     * Produces a small (e.g. 32x32) ARGB sample of the frame for cheap change detection.
     * Real candle-region-aware sampling arrives in Phase 2's ChartDetector; this is a
     * coarse whole-frame check sufficient for "did anything at all change" gating.
     */
    private fun downsampleForChangeDetection(bitmap: Bitmap): IntArray {
        val sampleSize = SAMPLE_DIMENSION
        val scaled = Bitmap.createScaledBitmap(bitmap, sampleSize, sampleSize, false)
        val pixels = IntArray(sampleSize * sampleSize)
        scaled.getPixels(pixels, 0, sampleSize, 0, 0, sampleSize, sampleSize)
        scaled.recycle()
        return pixels
    }

    private companion object {
        const val TAG = "ScreenCaptureCtrl"
        const val SAMPLE_DIMENSION = 32
        const val HEARTBEAT_INTERVAL_MILLIS = 3000L
    }
}
