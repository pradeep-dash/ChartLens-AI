package com.chartlens.ai.analysis

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Shared in-process holder for the latest [AnalysisFrame], written by
 * [com.chartlens.ai.cv.FrameAnalyzer] (via ScreenCaptureService) and read by the
 * overlay and dashboard UI. Null until the first frame has been analyzed.
 */
@Singleton
class AnalysisStateRepository @Inject constructor() {

    private val _latestFrame = MutableStateFlow<AnalysisFrame?>(null)
    val latestFrame: StateFlow<AnalysisFrame?> = _latestFrame.asStateFlow()

    fun update(frame: AnalysisFrame) {
        _latestFrame.value = frame
    }
}
