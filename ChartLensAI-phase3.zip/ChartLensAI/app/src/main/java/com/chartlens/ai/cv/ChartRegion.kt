package com.chartlens.ai.cv

/**
 * The rectangular sub-region of a captured frame believed to contain the
 * candlestick chart, in pixel coordinates of the frame it was detected against.
 */
data class ChartRegion(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val confidence: Float,
    val source: Source
) {
    val width: Int get() = (right - left).coerceAtLeast(0)
    val height: Int get() = (bottom - top).coerceAtLeast(0)

    enum class Source { AUTO_DETECTED, MANUAL }

    fun isUsable(): Boolean = width > MIN_USABLE_DIMENSION && height > MIN_USABLE_DIMENSION

    private companion object {
        const val MIN_USABLE_DIMENSION = 40
    }
}
