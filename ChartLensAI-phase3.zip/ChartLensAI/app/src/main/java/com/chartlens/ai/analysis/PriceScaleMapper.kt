package com.chartlens.ai.analysis

import com.chartlens.ai.ocr.OcrTextBlock
import com.chartlens.ai.ocr.PriceTextParser

/**
 * pixelY -> price is linear (screen coordinates map to a price axis linearly
 * within the visible viewport), fitted as `price = slope * pixelY + intercept`.
 *
 * [confidence] combines fit quality (R²) with sample count: any 2 points fit a
 * line perfectly (R²=1.0) whether or not the OCR readings are actually
 * correct, so a 2-point fit is deliberately never treated as fully confident —
 * only 3+ points can reveal an inconsistent/misread label through a worse fit.
 */
data class PriceScaleMapping(
    val slope: Double,
    val intercept: Double,
    val rSquared: Double,
    val sampleCount: Int,
    val confidence: Float
) {
    fun priceAt(pixelY: Double): Double = slope * pixelY + intercept
}

/**
 * Fits a [PriceScaleMapping] from OCR'd price-axis labels using ordinary
 * least-squares linear regression — not a fixed price increment (per the "do
 * not assume a fixed price increment" requirement), and not just the first two
 * labels found, so that a single misread label among 3+ shows up as a worse
 * fit (lower R²) rather than silently corrupting the whole mapping.
 *
 * Pure Kotlin — every input here is already-recognized text with a pixel
 * position, so this is fully unit-testable without ML Kit, a Bitmap, or a
 * device. The only Android-touching part of price mapping is
 * [com.chartlens.ai.ocr.OcrEngine], which produces the [OcrTextBlock]s this
 * class consumes.
 */
class PriceScaleMapper {

    fun fit(labels: List<OcrTextBlock>): PriceScaleMapping? {
        val points = labels.mapNotNull { block ->
            PriceTextParser.parse(block.text)?.let { price -> block.centerY.toDouble() to price }
        }
        if (points.size < 2) return null

        val distinctYCount = points.map { it.first }.distinct().size
        if (distinctYCount < 2) return null // can't fit a line through a single Y position

        val n = points.size
        val meanX = points.sumOf { it.first } / n
        val meanY = points.sumOf { it.second } / n

        val ssXX = points.sumOf { (it.first - meanX) * (it.first - meanX) }
        val ssXY = points.sumOf { (it.first - meanX) * (it.second - meanY) }
        if (ssXX == 0.0) return null

        val slope = ssXY / ssXX
        val intercept = meanY - slope * meanX

        val ssTot = points.sumOf { (it.second - meanY) * (it.second - meanY) }
        val ssRes = points.sumOf { pair ->
            val predicted = slope * pair.first + intercept
            (pair.second - predicted) * (pair.second - predicted)
        }
        val rSquared = if (ssTot == 0.0) 1.0 else 1.0 - (ssRes / ssTot)

        // A 2-point fit is always a perfect line (R²=1.0) regardless of whether the
        // readings are correct, so it's capped well below full confidence; 3+ points
        // let a bad reading actually show up as a worse fit.
        val confidence = if (n >= 3) {
            rSquared.coerceIn(0.0, 1.0)
        } else {
            (rSquared * 0.5).coerceIn(0.0, 1.0)
        }.toFloat()

        return PriceScaleMapping(slope, intercept, rSquared, n, confidence)
    }
}
