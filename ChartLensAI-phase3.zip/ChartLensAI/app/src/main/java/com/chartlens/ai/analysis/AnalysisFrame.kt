package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandlePatternMatch
import com.chartlens.ai.cv.ChartRegion

/**
 * Everything the pipeline knows about a single analyzed frame.
 *
 * [priceScaleMapping]/[timeframeResult]/[priceCandles]/[technicalAnalysis] are
 * all null/empty until Phase 3's OCR successfully reads the price and time
 * axes — there is no fallback that fabricates them. [priceCandles] only ever
 * contains CLOSED candles (see [Candle.isForming]), consistent with never
 * treating an unfinished candle as confirmed data.
 *
 * Still deliberately has no bias/prediction/confidence-to-trade field, even
 * though [technicalAnalysis] now carries real indicator values — turning
 * indicator readings into a directional signal is Phase 5's job
 * (`PredictionEngine`), not this pipeline's.
 */
data class AnalysisFrame(
    val timestampMillis: Long,
    val chartRegion: ChartRegion?,
    val candles: List<Candle>,
    val patternMatches: List<CandlePatternMatch>,
    val dataQuality: DataQuality,
    val priceScaleMapping: PriceScaleMapping? = null,
    val timeframeResult: TimeframeResult? = null,
    val priceCandles: List<PriceCandle> = emptyList(),
    val technicalAnalysis: TechnicalAnalysisResult? = null,
    val candleCloseEvent: CandleCloseEvent? = null
) {
    val closedCandleCount: Int get() = candles.count { !it.isForming }
}

