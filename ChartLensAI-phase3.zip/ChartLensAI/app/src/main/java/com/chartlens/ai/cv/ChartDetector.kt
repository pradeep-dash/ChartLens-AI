package com.chartlens.ai.cv

import com.chartlens.ai.common.PixelBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Locates the most probable candlestick-chart region in a full-frame [PixelBuffer]
 * using candle-color density and bar-spacing regularity — never fixed coordinates,
 * per the "do not hardcode chart location" requirement. Works across different
 * trading apps/layouts because it only looks for the visual signature of a
 * candlestick chart (clustered, evenly-spaced, alternating bullish/bearish
 * vertical bars), not any particular app's UI structure.
 *
 * This is intentionally a coarse, cheap heuristic — good enough to find "roughly
 * where the candles are" so [com.chartlens.ai.candle.CandleDetector] can work on a
 * cropped region instead of the whole screen. It is not pixel-perfect and will
 * sometimes return null (below-confidence) on unusual layouts; the manual crop
 * fallback ([ManualChartRegionStore]) exists specifically for that case.
 */
class ChartDetector(
    private val colorProfile: CandleColorProfile = CandleColorProfile(),
    private val minColumnDensityFraction: Float = 0.04f, // fraction of column height that must be candle-colored
    private val maxColumnGapPx: Int = 24, // gap tolerance when clustering candle columns horizontally
    private val minCandleColumns: Int = 30,
    private val minColorTransitions: Int = 3, // guards against a single colored icon/button
    private val verticalPaddingPx: Int = 6
) {

    fun detect(frame: PixelBuffer): ChartRegion? {
        if (frame.width < minCandleColumns || frame.height < 20) return null

        val columnHasCandleColor = BooleanArray(frame.width)
        val columnDominantClass = arrayOfNulls<PixelClassification>(frame.width)
        val columnMinRow = IntArray(frame.width) { frame.height }
        val columnMaxRow = IntArray(frame.width) { -1 }

        for (x in 0 until frame.width) {
            var bullishCount = 0
            var bearishCount = 0
            for (y in 0 until frame.height) {
                when (colorProfile.classify(frame.get(x, y))) {
                    PixelClassification.BULLISH -> {
                        bullishCount++
                        columnMinRow[x] = min(columnMinRow[x], y)
                        columnMaxRow[x] = max(columnMaxRow[x], y)
                    }
                    PixelClassification.BEARISH -> {
                        bearishCount++
                        columnMinRow[x] = min(columnMinRow[x], y)
                        columnMaxRow[x] = max(columnMaxRow[x], y)
                    }
                    PixelClassification.OTHER -> Unit
                }
            }
            val total = bullishCount + bearishCount
            val density = total.toFloat() / frame.height
            columnHasCandleColor[x] = density >= minColumnDensityFraction
            if (columnHasCandleColor[x]) {
                columnDominantClass[x] =
                    if (bullishCount >= bearishCount) PixelClassification.BULLISH else PixelClassification.BEARISH
            }
        }

        val bestCluster = findBestColumnCluster(columnHasCandleColor) ?: return null
        val (clusterStart, clusterEnd) = bestCluster

        val candleColumnCount = (clusterStart..clusterEnd).count { columnHasCandleColor[it] }
        if (candleColumnCount < minCandleColumns) return null

        val transitions = countColorTransitions(columnDominantClass, clusterStart, clusterEnd)
        if (transitions < minColorTransitions) return null

        var top = Int.MAX_VALUE
        var bottom = Int.MIN_VALUE
        for (x in clusterStart..clusterEnd) {
            if (columnMaxRow[x] >= 0) {
                top = min(top, columnMinRow[x])
                bottom = max(bottom, columnMaxRow[x])
            }
        }
        if (top == Int.MAX_VALUE) return null

        top = (top - verticalPaddingPx).coerceAtLeast(0)
        bottom = (bottom + verticalPaddingPx).coerceAtMost(frame.height)

        val densityScore = candleColumnCount.toFloat() / (clusterEnd - clusterStart + 1)
        val transitionScore = (transitions.toFloat() / minColorTransitions).coerceAtMost(1.5f) / 1.5f
        val confidence = (0.6f * densityScore + 0.4f * transitionScore).coerceIn(0f, 1f)

        val region = ChartRegion(
            left = clusterStart,
            top = top,
            right = clusterEnd + 1,
            bottom = bottom,
            confidence = confidence,
            source = ChartRegion.Source.AUTO_DETECTED
        )
        return if (region.isUsable()) region else null
    }

    /** Finds the widest run of candle-colored columns, tolerating gaps up to [maxColumnGapPx]. */
    private fun findBestColumnCluster(columnHasCandleColor: BooleanArray): Pair<Int, Int>? {
        var bestStart = -1
        var bestEnd = -1
        var bestScore = 0

        var clusterStart = -1
        var lastCandleColumn = -1

        for (x in columnHasCandleColor.indices) {
            if (columnHasCandleColor[x]) {
                if (clusterStart == -1) {
                    clusterStart = x
                } else if (x - lastCandleColumn > maxColumnGapPx) {
                    // gap too large — close current cluster, evaluate, start a new one
                    val score = lastCandleColumn - clusterStart
                    if (score > bestScore) {
                        bestScore = score
                        bestStart = clusterStart
                        bestEnd = lastCandleColumn
                    }
                    clusterStart = x
                }
                lastCandleColumn = x
            }
        }
        if (clusterStart != -1) {
            val score = lastCandleColumn - clusterStart
            if (score > bestScore) {
                bestScore = score
                bestStart = clusterStart
                bestEnd = lastCandleColumn
            }
        }

        return if (bestStart == -1) null else bestStart to bestEnd
    }

    private fun countColorTransitions(
        columnDominantClass: Array<PixelClassification?>,
        start: Int,
        end: Int
    ): Int {
        var transitions = 0
        var previous: PixelClassification? = null
        for (x in start..end) {
            val current = columnDominantClass[x] ?: continue
            if (previous != null && current != previous) transitions++
            previous = current
        }
        return transitions
    }
}
