package com.chartlens.ai.cv

import android.graphics.Bitmap
import android.util.Log
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.CandleCloseTracker
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.analysis.DataQualityCalculator
import com.chartlens.ai.analysis.PriceCandle
import com.chartlens.ai.analysis.PriceScaleMapper
import com.chartlens.ai.analysis.PriceScaleMapping
import com.chartlens.ai.analysis.TechnicalAnalysisEngine
import com.chartlens.ai.analysis.TimeframeDetector
import com.chartlens.ai.analysis.TimeframeResult
import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandleDetector
import com.chartlens.ai.candle.CandlePatternDetector
import com.chartlens.ai.common.PixelBuffer
import com.chartlens.ai.ocr.OcrEngine
import com.chartlens.ai.ocr.OcrTextBlock

/**
 * The only class in the pipeline that touches `android.graphics.Bitmap` or ML
 * Kit — everything downstream (ChartDetector, CandleDetector,
 * CandlePatternDetector, PriceScaleMapper, TimeframeDetector,
 * TechnicalAnalysisEngine) operates on pure-Kotlin models and is unit tested.
 * This class itself is reviewed by hand, same as the rest of the Bitmap/
 * MediaProjection/ML-Kit boundary.
 *
 * Performance notes (two independent caches, different intervals):
 *  - Chart-region detection is re-run every [rediscoverEveryNFrames] frames —
 *    the chart's on-screen position rarely moves between frames.
 *  - OCR (price + time axis) is re-run every [ocrEveryNFrames] frames, a
 *    longer interval than chart-region rediscovery, since text recognition is
 *    meaningfully more expensive than the pixel-geometry work and the visible
 *    price/time range changes far less often than individual candles do.
 * Neither interval has been tuned against real device measurements yet — see
 * README "Known limitations" for the Phase 9 follow-up.
 *
 * Price-axis/time-axis crop regions assume the common trading-app convention
 * this project was tested against: price labels along the right edge of the
 * chart, time labels along the bottom. A platform using the opposite
 * convention (price axis on the left) would need this adjusted — documented
 * as a known limitation, not silently handled.
 */
class FrameAnalyzer(
    private val chartDetector: ChartDetector = ChartDetector(),
    private val candleDetector: CandleDetector = CandleDetector(),
    private val patternDetector: CandlePatternDetector = CandlePatternDetector(),
    private val ocrEngine: OcrEngine = OcrEngine(),
    private val priceScaleMapper: PriceScaleMapper = PriceScaleMapper(),
    private val timeframeDetector: TimeframeDetector = TimeframeDetector(),
    private val technicalAnalysisEngine: TechnicalAnalysisEngine = TechnicalAnalysisEngine(),
    private val candleCloseTracker: CandleCloseTracker = CandleCloseTracker(),
    private val rediscoverEveryNFrames: Int = 20,
    private val ocrEveryNFrames: Int = 30,
    private val priceAxisStripWidthPx: Int = 130,
    private val timeAxisStripHeightPx: Int = 50
) {
    private var cachedAutoRegion: ChartRegion? = null
    private var framesSinceRediscovery = 0

    private var cachedPriceScaleMapping: PriceScaleMapping? = null
    private var cachedTimeframeResult: TimeframeResult? = null
    private var framesSinceOcr = Int.MAX_VALUE // force an OCR pass on the first eligible frame

    suspend fun analyze(bitmap: Bitmap, manualRegion: ChartRegion?, timestampMillis: Long): AnalysisFrame {
        val fullBuffer = bitmap.toPixelBuffer()
        val region = manualRegion ?: resolveAutoRegion(fullBuffer)

        if (region == null || !region.isUsable()) {
            return AnalysisFrame(
                timestampMillis = timestampMillis,
                chartRegion = region,
                candles = emptyList(),
                patternMatches = emptyList(),
                dataQuality = DataQuality.INVALID
            )
        }

        val cropped = fullBuffer.crop(
            left = region.left.coerceIn(0, fullBuffer.width),
            top = region.top.coerceIn(0, fullBuffer.height),
            right = region.right.coerceIn(0, fullBuffer.width),
            bottom = region.bottom.coerceIn(0, fullBuffer.height)
        )

        val candles = candleDetector.detect(cropped)
        val patterns = patternDetector.detect(candles)
        val closeEvent = candleCloseTracker.update(candles)

        runOcrIfDue(bitmap, region, candles)

        val priceMapping = cachedPriceScaleMapping
        val priceCandles = if (priceMapping != null) {
            candles.filterNot { it.isForming }.map { it.toPriceCandle(priceMapping) }
        } else {
            emptyList()
        }
        val technicalAnalysis = if (priceCandles.isNotEmpty()) {
            technicalAnalysisEngine.analyze(priceCandles)
        } else {
            null
        }

        val quality = DataQualityCalculator.calculate(region.confidence, candles, priceMapping?.confidence)

        return AnalysisFrame(
            timestampMillis = timestampMillis,
            chartRegion = region,
            candles = candles,
            patternMatches = patterns,
            dataQuality = quality,
            priceScaleMapping = priceMapping,
            timeframeResult = cachedTimeframeResult,
            priceCandles = priceCandles,
            technicalAnalysis = technicalAnalysis,
            candleCloseEvent = closeEvent
        )
    }

    /** Call when the user changes/clears the manual selection, or on a new capture session. */
    fun invalidateCache() {
        cachedAutoRegion = null
        framesSinceRediscovery = 0
        cachedPriceScaleMapping = null
        cachedTimeframeResult = null
        framesSinceOcr = Int.MAX_VALUE
        candleCloseTracker.reset()
    }

    fun close() {
        ocrEngine.close()
    }

    private fun resolveAutoRegion(fullBuffer: PixelBuffer): ChartRegion? {
        val shouldRediscover = cachedAutoRegion == null || framesSinceRediscovery >= rediscoverEveryNFrames
        return if (shouldRediscover) {
            framesSinceRediscovery = 0
            chartDetector.detect(fullBuffer).also { cachedAutoRegion = it }
        } else {
            framesSinceRediscovery++
            cachedAutoRegion
        }
    }

    private suspend fun runOcrIfDue(bitmap: Bitmap, region: ChartRegion, candles: List<Candle>) {
        if (framesSinceOcr < ocrEveryNFrames) {
            framesSinceOcr++
            return
        }
        framesSinceOcr = 0

        val priceAxisLabels = recognizeSafely(cropPriceAxisStrip(bitmap, region))
        val timeAxisLabels = recognizeSafely(cropTimeAxisStrip(bitmap, region))

        priceScaleMapper.fit(priceAxisLabels)?.let { cachedPriceScaleMapping = it }
        // If fit() returns null (not enough usable labels this pass), keep the previous
        // mapping rather than blank it out — a single bad OCR pass on an otherwise
        // stable price axis shouldn't throw away a good mapping from moments ago.

        val timeframe = timeframeDetector.detect(timeAxisLabels, candles)
        if (timeframe.timeframe != null || cachedTimeframeResult == null) {
            // Same "don't blank out a good cached result on one bad pass" policy as
            // price mapping above — but only once we have any cached result at all;
            // the very first attempt should always be recorded, even if inconclusive,
            // so the UI shows "estimated but unmatched" rather than nothing at all.
            cachedTimeframeResult = timeframe
        }
    }

    private suspend fun recognizeSafely(bitmap: Bitmap?): List<OcrTextBlock> {
        if (bitmap == null) return emptyList()
        return try {
            ocrEngine.recognize(bitmap)
        } catch (t: Throwable) {
            Log.w(TAG, "OCR recognition failed, treating as no labels found", t)
            emptyList()
        }
    }

    private fun cropPriceAxisStrip(bitmap: Bitmap, region: ChartRegion): Bitmap? {
        val left = region.right.coerceIn(0, bitmap.width)
        val right = (region.right + priceAxisStripWidthPx).coerceIn(0, bitmap.width)
        val top = region.top.coerceIn(0, bitmap.height)
        val bottom = region.bottom.coerceIn(0, bitmap.height)
        if (right <= left || bottom <= top) return null
        return safeCrop(bitmap, left, top, right - left, bottom - top)
    }

    private fun cropTimeAxisStrip(bitmap: Bitmap, region: ChartRegion): Bitmap? {
        val left = region.left.coerceIn(0, bitmap.width)
        val right = region.right.coerceIn(0, bitmap.width)
        val top = region.bottom.coerceIn(0, bitmap.height)
        val bottom = (region.bottom + timeAxisStripHeightPx).coerceIn(0, bitmap.height)
        if (right <= left || bottom <= top) return null
        return safeCrop(bitmap, left, top, right - left, bottom - top)
    }

    private fun safeCrop(bitmap: Bitmap, x: Int, y: Int, width: Int, height: Int): Bitmap? {
        return try {
            Bitmap.createBitmap(bitmap, x, y, width, height)
        } catch (t: Throwable) {
            Log.w(TAG, "Failed to crop OCR strip at ($x,$y,$width,$height)", t)
            null
        }
    }

    private fun Candle.toPriceCandle(mapping: PriceScaleMapping): PriceCandle = PriceCandle(
        index = index,
        timestampMillis = null, // real timestamps need timeframe + a reference clock — not derived here
        open = mapping.priceAt(openY.toDouble()),
        high = mapping.priceAt(highY.toDouble()),
        low = mapping.priceAt(lowY.toDouble()),
        close = mapping.priceAt(closeY.toDouble())
    )

    private fun Bitmap.toPixelBuffer(): PixelBuffer {
        val pixels = IntArray(width * height)
        getPixels(pixels, 0, width, 0, 0, width, height)
        return PixelBuffer(width, height, pixels)
    }

    private companion object {
        const val TAG = "FrameAnalyzer"
    }
}
