package com.chartlens.ai.ocr

/**
 * One recognized line of text from the OCR engine, with its pixel-space center
 * point. Deliberately plain data (no android.graphics.Rect, no ML Kit types) so
 * every downstream consumer — [PriceScaleMapper][com.chartlens.ai.analysis.PriceScaleMapper],
 * [com.chartlens.ai.analysis.TimeframeDetector] — is unit-testable with
 * directly-constructed instances, without needing a device or Bitmap at all.
 *
 * No confidence field: ML Kit's Text Recognition API doesn't expose a
 * per-line confidence score, so this doesn't fabricate one. Parse-level
 * confidence (does the text look like a valid price/time?) is computed
 * downstream by whichever parser consumes it.
 */
data class OcrTextBlock(
    val text: String,
    val centerX: Int,
    val centerY: Int
)
