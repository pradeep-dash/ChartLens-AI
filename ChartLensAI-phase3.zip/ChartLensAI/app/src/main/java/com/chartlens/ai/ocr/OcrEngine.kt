package com.chartlens.ai.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Wraps ML Kit's on-device text recognizer. This is the only class in the OCR
 * pipeline that touches Bitmap/ML Kit — everything downstream
 * ([PriceTextParser], [TimeTextParser],
 * [com.chartlens.ai.analysis.PriceScaleMapper],
 * [com.chartlens.ai.analysis.TimeframeDetector]) operates on the plain
 * [OcrTextBlock] this produces and is unit tested. This class itself is
 * reviewed by hand, same as the rest of the Bitmap/MediaProjection boundary.
 *
 * Uses line-level granularity (not block-level) — ML Kit can merge multiple
 * nearby short labels (e.g. two adjacent price ticks) into one text block,
 * which would corrupt their individual pixel positions. Lines are the
 * finest-grained bounding box ML Kit's API exposes.
 *
 * Processing happens fully on-device (no network call, no data leaves the
 * device) — relevant to this project's privacy requirements around not
 * transmitting captured screen content.
 */
class OcrEngine {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bitmap: Bitmap): List<OcrTextBlock> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val text = suspendCancellableCoroutine { continuation ->
            recognizer.process(image)
                .addOnSuccessListener { result -> continuation.resume(result) }
                .addOnFailureListener { error -> continuation.resumeWithException(error) }
        }

        return text.textBlocks.flatMap { block ->
            block.lines.mapNotNull { line ->
                val box = line.boundingBox ?: return@mapNotNull null
                OcrTextBlock(
                    text = line.text,
                    centerX = box.centerX(),
                    centerY = box.centerY()
                )
            }
        }
    }

    /** Releases the recognizer's native resources. Call from the owning component's teardown. */
    fun close() {
        recognizer.close()
    }
}
