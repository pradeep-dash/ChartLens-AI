package com.chartlens.ai.settings

import com.chartlens.ai.cv.ChartRegion

/**
 * A rectangle expressed as fractions (0f..1f) of frame width/height, rather than
 * absolute pixels. A manual chart-region selection is made against one captured
 * frame's dimensions but needs to keep working if the screen rotates or the
 * capture resolution otherwise changes — storing fractions instead of pixels is
 * what makes that possible without re-prompting the user every time.
 */
data class NormalizedRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    fun toChartRegion(frameWidth: Int, frameHeight: Int): ChartRegion = ChartRegion(
        left = (left * frameWidth).toInt(),
        top = (top * frameHeight).toInt(),
        right = (right * frameWidth).toInt(),
        bottom = (bottom * frameHeight).toInt(),
        confidence = 1f, // user-selected — treated as fully confident by definition
        source = ChartRegion.Source.MANUAL
    )
}
