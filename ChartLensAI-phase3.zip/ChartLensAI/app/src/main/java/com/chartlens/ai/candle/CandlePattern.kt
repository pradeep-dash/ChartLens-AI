package com.chartlens.ai.candle

/**
 * Geometric candle pattern labels. A candle can match more than one pattern at
 * once (e.g. a long-wick-rejection candle is very often also a hammer shape) —
 * see [CandlePatternDetector] for why matches are returned as a set, not a
 * single label.
 *
 * NOTE on HAMMER / INVERTED_HAMMER / SHOOTING_STAR: these three share only two
 * underlying shapes (long-lower-wick-small-body, and long-upper-wick-small-body).
 * Which name correctly applies depends on the preceding trend (a long-lower-wick
 * shape after a downtrend is a hammer; after an uptrend the same shape is a
 * "hanging man"), and trend context doesn't exist until Phase 4's
 * TechnicalAnalysisEngine. [CandlePatternDetector] labels by shape and the
 * candle's own color as a best-effort convention — treat these three labels as
 * "candidate shape, name not yet trend-confirmed" until Phase 4 is wired in.
 */
enum class CandlePattern {
    DOJI,
    SPINNING_TOP,
    HAMMER,
    INVERTED_HAMMER,
    SHOOTING_STAR,
    BULLISH_ENGULFING,
    BEARISH_ENGULFING,
    INSIDE_BAR,
    STRONG_MOMENTUM,
    LONG_WICK_REJECTION
}

data class CandlePatternMatch(
    val candleIndex: Int,
    val patterns: Set<CandlePattern>
)
