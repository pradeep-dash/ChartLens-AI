package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.ocr.OcrTextBlock
import com.chartlens.ai.ocr.TimeTextParser
import kotlin.math.abs

enum class Timeframe(val minutes: Int) {
    M1(1), M5(5), M15(15), M30(30), H1(60);

    companion object {
        /** Snaps to the nearest common interval only if within [toleranceFraction] — otherwise null. */
        fun nearestOrNull(estimatedMinutes: Double, toleranceFraction: Double = 0.25): Timeframe? {
            if (estimatedMinutes <= 0) return null
            val best = entries.minByOrNull { abs(it.minutes - estimatedMinutes) } ?: return null
            val relativeError = abs(best.minutes - estimatedMinutes) / best.minutes
            return if (relativeError <= toleranceFraction) best else null
        }
    }
}

/**
 * [timeframe] is null when detection isn't confident enough to snap to a
 * known interval — the spec's "Timeframe: Unknown rather than guessing"
 * requirement (§8). [estimatedMinutesPerCandle] is still surfaced even when
 * [timeframe] is null, so a caller/debug view can see *why* it didn't match
 * (e.g. "estimated 3.2 min/candle" makes clear it's between two known
 * intervals rather than the detector having failed outright).
 */
data class TimeframeResult(
    val timeframe: Timeframe?,
    val estimatedMinutesPerCandle: Double?,
    val confidence: Float
)

/**
 * Infers the candle interval by combining two independently-measured
 * quantities: minutes-per-pixel (from time-axis OCR labels) and pixels-per-
 * candle (from Phase 2's detected candle spacing) — never inferred from screen
 * dimensions alone, per the "do not assume the interval from screen
 * dimensions" requirement.
 */
class TimeframeDetector {

    fun detect(timeLabels: List<OcrTextBlock>, candles: List<Candle>): TimeframeResult {
        val points = timeLabels.mapNotNull { block ->
            TimeTextParser.parseMinutesSinceMidnight(block.text)?.let { minutes ->
                block.centerX.toDouble() to minutes.toDouble()
            }
        }
        if (points.size < 2) return TimeframeResult(null, null, 0f)

        val distinctXCount = points.map { it.first }.distinct().size
        if (distinctXCount < 2) return TimeframeResult(null, null, 0f)

        val n = points.size
        val meanX = points.sumOf { it.first } / n
        val meanY = points.sumOf { it.second } / n
        val ssXX = points.sumOf { (it.first - meanX) * (it.first - meanX) }
        val ssXY = points.sumOf { (it.first - meanX) * (it.second - meanY) }
        if (ssXX == 0.0) return TimeframeResult(null, null, 0f)
        val minutesPerPixel = ssXY / ssXX

        val closedCandles = candles.filterNot { it.isForming }
        if (closedCandles.size < 2) return TimeframeResult(null, null, 0f)

        val spacings = closedCandles.zipWithNext { a, b -> (b.xStart - a.xStart).toDouble() }.filter { it > 0 }
        if (spacings.isEmpty()) return TimeframeResult(null, null, 0f)
        val avgSpacingPx = spacings.average()

        val estimatedMinutes = abs(minutesPerPixel) * avgSpacingPx
        val matched = Timeframe.nearestOrNull(estimatedMinutes)
        val confidence = if (matched != null) 0.8f else 0.3f

        return TimeframeResult(matched, estimatedMinutes, confidence)
    }
}
