# ChartLens AI — Phases 1, 2, 4 (Foundation + Vision + Technical Analysis)

Analysis/decision-support only. This app never places trades, clicks buttons, or
interacts with any trading platform — it only reads the screen and displays
information.

This milestone covers **Phases 1, 2, and 4 of 9**. Phase 3 (price-axis OCR) was
deliberately skipped for now — see section 2. Also not present: the prediction
engine (Phase 5) and AI reasoning layer (Phase 6).

---

## 1. What was implemented

### Phase 1 — Foundation (capture, overlay, permissions)
- Full runtime permission sequence (`POST_NOTIFICATIONS` → `SYSTEM_ALERT_WINDOW`
  → MediaProjection consent), orchestrated in `MainActivity`
- `ScreenCaptureService`: foreground service owning the MediaProjection session,
  correctly sequenced for Android 14's "must be foreground before projection is
  granted" requirement
- `ScreenCaptureController`: real `ImageReader`/`VirtualDisplay` frame
  acquisition with throttling (~5fps ceiling) and change detection
  (`FrameChangeDetector`) so unchanged frames skip downstream work
- Screen rotation handling, graceful permission-denial/stop handling
- `OverlayService`: a `WindowManager`-attached floating card (draggable,
  collapsible, opacity slider), showing only real, currently-implemented state

### Phase 2 — Vision (chart/candle detection)
- `ChartDetector`: automatic chart-region detection from candle-color density
  and bar-spacing/color-transition patterns — no hardcoded coordinates for any
  specific trading app
- `CandleColorProfile`: hue-range based bullish/bearish classification (not a
  fixed RGB match), since exact shades vary by chart theme
- `CandleDetector`: per-candle geometry via column clustering + row-coverage
  body/wick separation
- `CandlePatternDetector`: doji, spinning top, hammer, inverted hammer,
  shooting star, bullish/bearish engulfing, inside bar, strong momentum,
  long-wick rejection — geometry-ratio scored, patterns can overlap
- `DataQuality` (partial — chart + candle detection confidence only; OCR/
  timeframe confidence join in Phase 3)
- Manual chart-region selection fallback (`ChartRegionSelectionScreen`):
  drag-to-crop over the last captured frame, persisted as a normalized
  (resolution-independent) rectangle
- Wired into the live pipeline: `ScreenCaptureService` runs `FrameAnalyzer` on
  every materially-changed frame, off the main thread, with overlap-guarding

**Architecture decision:** Phase 2 is pure Kotlin/Android pixel processing, not
OpenCV, despite the original spec listing OpenCV. This was deliberate — getting
Phase 1's CI build green took three iterations of real failures (a YAML
quoting issue, a missing `gradle.properties`, an AndroidX/Jetifier conflict),
and adding OpenCV means configuring its Maven repo or vendoring its SDK, a
realistic source of a similar build-failure loop for capability not needed at
this scale. The modular design (`ChartDetector`/`CandleDetector` behind their
own interfaces) means swapping in OpenCV later doesn't require touching the
surrounding pipeline.

**Two real bugs were found and fixed after Phase 2 shipped**, both worth
knowing about directly:
1. **`isForming` index bug** (caught in review, before device testing): the
   "which candle is currently forming" check compared an index from a
   *filtered* bar list against the *unfiltered* list's last index, silently
   mislabeling the forming candle whenever a too-narrow bar got filtered out.
   The original synthetic tests didn't exercise that path, so they passed
   despite the bug — a dedicated regression test was added once it was spotted.
2. **Candle-merging bug** (caught on first real-device test, against an actual
   trading app): the column-clustering logic tolerated a color change between
   close-together columns as "probably anti-aliasing noise," intending to
   handle rendering artifacts — but real charts routinely render adjacent
   candles touching with zero gap, which hit the exact same code path and
   caused entire rows of candles to merge into one bar (symptom: "0 candles
   detected" on a chart that clearly had dozens). Fixed by making any color
   change close the bar immediately, regardless of column distance — only
   *background* gaps get tolerance now. Verified working on a real chart
   afterward (53/54 candles, 98% region confidence, GOOD quality).

Both bugs illustrate the same lesson: a synthetic-only test suite is necessary
but not sufficient. Worth keeping in mind for Phase 3, which will touch even
messier real-world data (OCR).

### Phase 4 — Technical Analysis Engine
- `indicators/`: `EMA`, `RSI` (Wilder smoothing), `MACD` (12/26/9, EMA-chain),
  `ATR` (Wilder smoothing), `BollingerBands` — pure Kotlin, every one returns
  `null` rather than a guessed value when there isn't enough history
- `TrendAnalyzer`: swing-high/swing-low detection via a fractal method (a
  candle only becomes a confirmed swing point once enough candles exist on
  both sides of it), then higher-highs/higher-lows vs lower-highs/lower-lows
  classification — not a single moving-average-slope shortcut
- `MomentumAnalyzer`: rate of change, consecutive same-direction candle
  streaks, acceleration/deceleration
- `SupportResistanceAnalyzer`: clusters swing points into levels using a
  price-distance tolerance (never exact equality); evaluates the latest candle
  against levels established by *prior* candles only, never one it contributed
  to itself
- `TechnicalAnalysisEngine`: orchestrates all of the above into one
  `TechnicalAnalysisResult`

**Why this uses a new `PriceCandle` model, not Phase 2's `Candle`:** Phase 2's
`Candle` is deliberately pixel-geometry-only (no price fields), since there's
no price-axis mapping yet. Feeding pixel-Y coordinates into these indicators as
a price proxy was considered and rejected: RSI and trend direction happen to be
invariant to a monotonic linear transform, but ATR and Bollinger Band *width*
are not — their output would be a real number that looks like a real
price/range but isn't, which is exactly the kind of ambiguous half-real result
the "never fabricate" rule exists to prevent. `TechnicalAnalysisEngine` is
fully built and fully tested, but not wired to the live pixel pipeline —
that's Phase 3's job, once `PriceScaleMapper` exists to legitimately produce
`PriceCandle`s. This also means the HAMMER/INVERTED_HAMMER/SHOOTING_STAR
shape-only ambiguity flagged in Phase 2 (see `CandlePattern.kt`) is still
unresolved — `TrendAnalyzer` could disambiguate it, but only once real prices
exist to feed it.

## 2. Why Phase 3 was skipped this round

Phase 3 (price-axis OCR, timeframe/candle-close detection) is the harder,
device-iteration-heavy phase — similar to Phase 2's candle detection, but with
ML Kit text recognition added, which will need several rounds of you testing
against the real app's price labels and reporting back what it reads correctly
vs. garbles. Phase 4 was picked instead to bank another fully-verifiable,
device-independent milestone. Phase 3 is the natural next step now.

## 3. Project structure

```
app/src/main/java/com/chartlens/ai/
  common/            ColorMath, PixelBuffer, CaptureState(+Repository), LatestFrameHolder
  capture/           CapturedFrame, FrameChangeDetector, ScreenCaptureController
  service/           ScreenCaptureService
  overlay/           OverlayService, OverlayLifecycleOwner
  ui/                MainActivity, MainViewModel, DashboardScreen, ChartRegionSelectionScreen
  cv/                CandleColorProfile, ChartRegion, ChartDetector, FrameAnalyzer
  candle/            Candle, CandleDetector, CandlePattern(+Detector)
  settings/          NormalizedRect, ManualChartRegionStore
  indicators/        EMA, RSI, MACD, ATR, BollingerBands
  analysis/          PriceCandle, DataQuality, AnalysisFrame(+Repository),
                      TrendAnalyzer, MomentumAnalyzer, SupportResistanceAnalyzer,
                      TechnicalAnalysisEngine
```

`ocr/`, `prediction/`, `ai/`, `data/`, `database/`, `replay/` remain unbuilt.

## 4. Configuring the build

- **Gradle wrapper**: `gradle/wrapper/gradle-wrapper.properties` is pinned to
  Gradle 8.9, but the binary wrapper jar isn't checked in (couldn't be
  generated without network access). Open in Android Studio (it'll offer to
  generate it), or run `gradle wrapper --gradle-version 8.9` once yourself.
- **OpenCV**: not currently a dependency (see Phase 2's architecture note
  above). If you add it back for a future phase, you'll need either the
  OpenCV Maven repo (`https://maven.opencv.org`) or a vendored SDK module.
- **`gradle.properties`**: must include `android.useAndroidX=true` — this was
  missing in an early iteration and caused a real build failure
  (`AndroidXDisabledJetifierDisabled`); it's fixed now, just noting it since
  it's an easy thing to lose if the file is hand-edited later.
- **KSP/Kotlin version pairing**: pinned to `2.0.20-1.0.24` in
  `gradle/libs.versions.toml` — verify against
  https://github.com/google/ksp/releases if bumping Kotlin versions.
- No secrets/backend config needed yet (Phase 6).

## 5. How to build / install

```
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Requires the Gradle wrapper jar (section 4) and a device/emulator on API 29+.

## 6. Permissions required

`SYSTEM_ALERT_WINDOW` (overlay), `FOREGROUND_SERVICE` +
`FOREGROUND_SERVICE_MEDIA_PROJECTION`, `POST_NOTIFICATIONS` (Android 13+),
`INTERNET`/`ACCESS_NETWORK_STATE` (reserved for Phase 6, unused so far). Screen
capture itself is granted at runtime via the system `MediaProjectionManager`
dialog — no static manifest permission covers it.

## 7. Known limitations

- **Phase 2's CV pipeline has been verified on exactly one real chart
  (QX Broker, AUD/NZD OTC).** It works well there now, but accuracy against
  other trading apps/themes is unverified — different chart libraries render
  candles differently enough that further tuning is likely needed.
- **Chart region is cached, not re-detected every frame** (every 20 analyzed
  frames by default) — a deliberate perf tradeoff that means a layout change
  (e.g. switching timeframes) may take a few seconds to notice.
- **Manual chart selection is global, not per-app** — switching trading apps
  means re-selecting, since per-app detection needs the separate
  `PACKAGE_USAGE_STATS` permission.
- **Phase 4's engine has never processed real price data** — every test uses
  synthetic series. Real behavior against actual OHLC once Phase 3 exists is
  unverified, same caveat Phase 2 had before its first real-device test.
- **MACD's exact values are sanity-checked, not hand-verified** — unlike
  EMA/RSI/ATR/Bollinger, MACD's full EMA-chain math wasn't independently
  recomputed by hand; tests check direction/sign correctness only.
- No accessibility-service-based foreground-app detection — the app only ever
  sees pixels, never which app is on screen.

## 8. Tests performed

**Phase 1:** `FrameChangeDetectorTest` (6 cases).

**Phase 2:** `CandleDetectorTest` (6 cases, including two regression tests for
the bugs above), `ChartDetectorTest` (4 cases), `CandlePatternDetectorTest`
(7 cases).

**Phase 4** (all pure Kotlin, genuinely unit tested — not "reviewed by hand"):
- `EMATest` (4): insufficient-history null, exact hand-calculated values,
  flat-series stability, short-vs-long period responsiveness
- `RSITest` (4): insufficient-history null, exact RSI=100/0 for all-gain/
  all-loss series, bounded range for mixed data
- `ATRTest` (3): insufficient-history null, exact ATR = constant true range,
  ATR rise after a volatility spike
- `BollingerBandsTest` (3): insufficient-history null, zero-width bands on a
  constant series, exact hand-calculated mean/stdDev/bands for known data
- `MACDTest` (4): insufficient-history null, positive/negative MACD in
  sustained trends, histogram = macd - signal
- `TrendAnalyzerTest` (4): synthetic higher-highs/higher-lows zigzag → UPTREND,
  mirror image → DOWNTREND, flat series → UNKNOWN, too-few-candles → UNKNOWN
- `MomentumAnalyzerTest` (5): empty-list handling, bullish/bearish direction,
  exact consecutive-streak counting, acceleration detection
- `SupportResistanceAnalyzerTest` (4): level clustering with touch count,
  breakout detection, rejection detection, empty-list handling
- `TechnicalAnalysisEngineTest` (3): insufficient history → nulls throughout,
  sufficient history (60 candles) → real values throughout, empty input
  doesn't crash

`FrameAnalyzer`, `OverlayService`, `ChartRegionSelectionScreen`, and the rest
of the Android-framework-dependent boundary remain reviewed-by-hand rather
than unit tested, as with Phase 1.

## 9. Remaining work (next phases)

- **Phase 3** — Price-axis OCR (ML Kit), `PriceScaleMapper`, timeframe
  detection, candle-close detection. The biggest unblocking piece left —
  needed before Phase 4's engine or Phase 2's patterns can operate on real
  data. Expect real device iteration, like Phase 2's candle detection needed.
- **Phase 5** — `PredictionEngine`: weighted scoring across trend/momentum/
  support-resistance/EMA-RSI-MACD alignment/candle patterns, confidence,
  NO-TRADE state
- **Phase 6** — AI backend + `AiAnalysisProvider`
- **Phase 7** — Room prediction journal, outcome evaluation, accuracy analytics
- **Phase 8** — Replay/backtest mode, look-ahead-bias prevention tests
- **Phase 9** — Battery/performance tuning, accessibility, polish
