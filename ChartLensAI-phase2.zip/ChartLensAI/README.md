# ChartLens AI — Phase 1 + 2 (Foundation + Vision)

Analysis/decision-support only. This app never places trades, clicks buttons, or
interacts with any trading platform — it only reads the screen and displays
information.

This milestone covers **Phases 1 and 2 of 9**: project setup, permissions,
MediaProjection screen capture, the foreground service, the floating overlay
(Phase 1) — plus chart-region detection, candle detection, and candle pattern
scoring (Phase 2). It does **not** yet include price-axis OCR, timeframe
detection, technical indicators, predictions, or AI reasoning.

---

## 1. What was implemented

**Phase 1 (capture/overlay):** see the original Phase 1 notes below — unchanged.

**Phase 2 (vision):**
- `ChartDetector`: automatic chart-region detection from candle-color density and
  bar-spacing/color-transition patterns — no hardcoded coordinates for any
  particular trading app
- `CandleColorProfile`: hue-range based bullish/bearish pixel classification
  (not a fixed RGB match), since exact shades vary by chart theme
- `CandleDetector`: per-candle geometry via column clustering + row-coverage
  body/wick separation — real geometric reasoning, not a shape/name lookup
- `CandlePatternDetector`: doji, spinning top, hammer, inverted hammer,
  shooting star, bullish/bearish engulfing, inside bar, strong momentum, and
  long-wick rejection — all scored from geometry ratios, patterns can overlap
  (a candle can match more than one label)
- `DataQuality` (partial): combines chart-detection and candle-detection
  confidence into GOOD/FAIR/POOR/INVALID — will incorporate OCR/timeframe
  confidence once Phase 3 exists
- **Manual chart-region selection fallback**: drag-to-crop UI
  (`ChartRegionSelectionScreen`) over the most recently captured frame,
  persisted as a normalized (resolution-independent) rectangle
- Wired into the live pipeline: `ScreenCaptureService` now runs `FrameAnalyzer`
  on every materially-changed frame, off the main thread, with overlap-guarding
  so slow analysis on a given device doesn't pile up work
- Overlay and dashboard now show real candle counts and data quality — no
  bias/prediction display, since that logic doesn't exist yet (Phase 5)

**Architecture decision worth knowing about:** Phase 2 is pure Kotlin/Android
pixel processing, not OpenCV, despite the original spec listing OpenCV as the
intended CV engine. This was a deliberate tradeoff: getting a single green CI
build for Phase 1 took three iterations (a YAML quoting issue, then a missing
`gradle.properties`, then an AndroidX/Jetifier conflict from an unrelated ML Kit
dependency) — adding OpenCV means either configuring its Maven repository or
vendoring its SDK as a module, both realistic sources of a similar multi-round
build-failure loop for capability that isn't needed at this chart-detection
scale. If accuracy against real charts proves the pure-Kotlin approach
insufficient, OpenCV remains a valid escalation for Phase 2.1 — but the modular
architecture (`ChartDetector`/`CandleDetector` behind their own interfaces)
means swapping the implementation later doesn't require touching the pipeline
around them.

## 2. What was deliberately NOT implemented (by design, this phase)

Price-axis OCR and price mapping, timeframe/candle-close detection, technical
indicators (EMA/RSI/MACD/ATR), the prediction engine, and the AI reasoning
layer. `Candle` has no price fields on purpose — it exposes pixel-Y coordinates
(`openY`/`closeY`/`highY`/`lowY`) instead, since fabricating a price without a
price-axis mapping would violate the "never fabricate OHLC" rule. Phase 3's
`PriceScaleMapper` is what turns these into real prices.

## 3. Project structure (additions this phase)

```
app/src/main/java/com/chartlens/ai/
  common/
    ColorMath.kt              Pure-Kotlin RGB->HSV, no Android dependency
    PixelBuffer.kt             Pure-Kotlin pixel grid — the CV/candle testability boundary
    LatestFrameHolder.kt       Downscaled frame copy for the manual-crop preview UI
  cv/
    CandleColorProfile.kt      Hue-range candle color classification
    ChartRegion.kt
    ChartDetector.kt           Automatic chart-region detection
    FrameAnalyzer.kt           Android boundary: Bitmap -> pipeline -> AnalysisFrame
  candle/
    Candle.kt                  Pixel-space geometry, no price fields
    CandleDetector.kt          Column clustering + body/wick row-coverage separation
    CandlePattern.kt
    CandlePatternDetector.kt   Geometry-ratio pattern scoring
  analysis/
    DataQuality.kt
    AnalysisFrame.kt
    AnalysisStateRepository.kt
  settings/
    NormalizedRect.kt
    ManualChartRegionStore.kt  SharedPreferences-backed manual selection
  ui/
    ChartRegionSelectionScreen.kt   Drag-to-crop manual selection UI
```

`ocr/`, `indicators/`, `prediction/`, `ai/`, `data/`, `database/`, `replay/`
remain unbuilt, per the modular pipeline design.

## 4. Configuring the build

Unchanged from Phase 1 (see section 4 below) — Phase 2 added zero new Gradle
dependencies. Everything new this phase is either pure Kotlin or built on
Android APIs already in use (Bitmap, SharedPreferences, Compose).

## 5. How to build / install

Unchanged from Phase 1 — see sections 5-6 below.

## 6. Known limitations (Phase 2 specific)

- **Never tested against a real chart.** Every CV algorithm in this phase was
  built and verified against hand-constructed synthetic pixel data (see
  section 9) — real chart footage has anti-aliasing, gradients, overlapping UI
  chrome, and rendering quirks that synthetic rectangles don't. Expect
  `ChartDetector`/`CandleDetector` accuracy to need real tuning once you test
  against an actual trading app; the manual-selection fallback exists
  specifically for when auto-detection falls short.
- **Chart region is cached, not re-detected every frame** (every 20 analyzed
  frames by default, in `FrameAnalyzer`) as a deliberate perf tradeoff — if a
  trading app changes layout (e.g. switching timeframes moves the chart), it
  may take up to that many frames to notice, or you may need to re-open the
  manual selection screen.
- **Manual selection is global, not per-app** — switching trading apps means
  re-selecting the chart region, since detecting the foreground app package
  would require the separate `PACKAGE_USAGE_STATS` permission.
- **HAMMER / INVERTED_HAMMER / SHOOTING_STAR are shape-only labels.** Correctly
  distinguishing a hammer from a hanging man (same shape) requires knowing the
  preceding trend, which doesn't exist until Phase 4. See `CandlePattern.kt`'s
  doc comment for the exact convention used in the meantime.
- **No accessibility-service-based foreground-app detection** — this app has no
  way to know which app is currently on screen; it only sees pixels.

## 7. Permissions required

Unchanged from Phase 1 — Phase 2 added no new permissions.

## 8. Tests performed

**Phase 1:** `FrameChangeDetectorTest` (6 cases) — unchanged.

**Phase 2:**
- `CandleDetectorTest` (5 cases): empty buffer, two-candle body/wick geometry
  and direction verified against hand-computed pixel coordinates, open/close/
  high/low pixel-semantics correctness, a regression test for a real bug caught
  during review (see below), and minimum-width filtering
- `ChartDetectorTest` (4 cases): all-background frame rejected, a single small
  colored icon correctly NOT mistaken for a chart, a 15-bar synthetic cluster
  correctly detected with region bounds and confidence, and cluster selection
  when two separate bar groups exist far apart
- `CandlePatternDetectorTest` (7 cases): doji, hammer, shooting star, inverted
  hammer, bullish engulfing, inside bar, strong momentum — each constructed
  from specific hand-computed geometry ratios

**A real bug was caught and fixed during this phase's review**, worth noting
directly: `CandleDetector`'s "is this the last (forming) candle" check compared
an index from the *filtered* bar list against `lastIndex` of the *unfiltered*
list, which would silently mislabel which candle is "forming" whenever a
too-narrow bar got filtered out earlier in the frame. The synthetic test cases
originally written didn't include a filtered bar, so they passed despite the
bug — a dedicated regression test (`isForming correctly targets the last
surviving bar even when an earlier bar is filtered out`) was added specifically
to cover that path. Flagging this because it's the kind of bug that a
device-independent test suite can still miss if the test data doesn't happen to
exercise the right code path — worth keeping in mind when judging how much
confidence to place in "all tests pass."

As with Phase 1's Android-framework-dependent classes, `FrameAnalyzer` (the
Bitmap-touching boundary) and the manual-selection UI were reviewed by hand,
not unit tested — genuinely testable only with a device or Robolectric.

## 9. Post-Phase-2 fix: candle-merging bug found on real-device testing

The first real-device test (against an actual trading app chart) surfaced a
genuine bug the synthetic-data test suite had missed: `CandleDetector`'s
column-clustering logic treated a color change between close-together columns
as "probably anti-aliasing noise, keep the same bar" rather than "a new
candle." Real charts routinely render adjacent candles touching or nearly
touching with no background gap between them — exactly the case that
tolerance was meant for background gaps, not color changes, but the code
conflated the two. Result: entire rows of candles could collapse into a single
merged bar, producing the "0 candles / quality POOR" symptom.

Fixed by making any color change close the current bar immediately, regardless
of column distance — only background (non-candle-colored) gaps get tolerance
now. A regression test (`directly adjacent candles of different colors with no
gap are still split apart`) was added and confirmed to fail against the old
code, pass against the fix.

This is the second real bug this project has caught that the synthetic-only
test suite missed (the first was the `isForming`/filtered-list index bug found
during Phase 2's own review) — both were real, both were caught, but neither
was caught by "tests pass" alone; one needed a code-path-specific test written
after noticing the risk, the other needed actual device data. Worth keeping
that pattern in mind for Phase 3 onward, which will touch real, messy pixel
data (OCR) even more directly.

## 10. Remaining work (next phases)

- **Phase 3** — Price-axis OCR, `PriceScaleMapper`, timeframe detection,
  candle-close detection
- **Phase 4** — `TechnicalAnalysisEngine`: trend, momentum, EMA/RSI/MACD/ATR/
  Bollinger, support/resistance (pure Kotlin, fully unit-testable — a good next
  milestone if you want another device-independent, high-confidence phase
  before Phase 3's OCR work, which will need real testing against your actual
  trading app either way)
- **Phase 5** — `PredictionEngine`: weighted scoring, confidence, NO-TRADE state
- **Phase 6** — AI backend + `AiAnalysisProvider`
- **Phase 7** — Room prediction journal, outcome evaluation, accuracy analytics
- **Phase 8** — Replay/backtest mode, look-ahead-bias prevention tests
- **Phase 9** — Battery/performance tuning, accessibility, polish

---

## Appendix: original Phase 1 notes



- Android project scaffold (Gradle version catalog, Hilt, Compose/Material 3, KSP)
- Full runtime permission sequence: `POST_NOTIFICATIONS` → `SYSTEM_ALERT_WINDOW`
  (overlay) → `MediaProjection` consent, orchestrated in `MainActivity`
- `ScreenCaptureService`: a foreground service (`FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION`)
  that owns the MediaProjection session, correctly sequenced for Android 14's
  requirement that the service be in foreground state *before* the projection is
  granted
- `ScreenCaptureController`: real `ImageReader` + `VirtualDisplay` frame acquisition,
  with row-stride-safe Bitmap conversion, frame-rate throttling (~5fps ceiling),
  and a `FrameChangeDetector` that skips downstream work when the screen hasn't
  materially changed
- Screen rotation handling (`onConfigurationChanged` tears down and recreates the
  capture surface at the new dimensions)
- `OverlayService`: a `WindowManager`-attached floating card (not hosted by an
  Activity) that is draggable, collapsible, has an opacity slider, and shows
  **real** capture status (resolution, frames analyzed, uptime) — no
  bias/confidence/pattern fields, because that layer doesn't exist yet
- Graceful handling of: permission denial at each step, the user stopping
  screen-sharing from system UI, and service teardown

## 2. What was deliberately NOT implemented (by design, this phase)

Everything downstream of "a frame was captured": chart-region detection, candle
detection, OCR, technical indicators, the prediction engine, the AI reasoning
layer, the overlay's bias/confidence display, Room persistence, and analytics.
The overlay and dashboard only ever show real capture-pipeline state — they do
not display placeholder or fabricated analysis, in line with the project's
no-fake-functionality rule.

## 3. Project structure

```
app/src/main/java/com/chartlens/ai/
  ChartLensApplication.kt      Hilt entry point
  common/
    CaptureState.kt            Sealed state model for the capture pipeline
    CaptureStateRepository.kt  Shared in-process StateFlow (Service ↔ Overlay ↔ UI)
  capture/
    CapturedFrame.kt
    FrameChangeDetector.kt     Pure Kotlin, unit tested
    ScreenCaptureController.kt MediaProjection/ImageReader/VirtualDisplay owner
  service/
    ScreenCaptureService.kt    Foreground service
  overlay/
    OverlayLifecycleOwner.kt   Manual Lifecycle/ViewModelStore/SavedStateRegistry
                                for a ComposeView with no Activity host
    OverlayService.kt          WindowManager-attached floating card
  ui/
    MainActivity.kt            Permission orchestration
    MainViewModel.kt
    DashboardScreen.kt
```

Empty package directories (`cv/`, `candle/`, `ocr/`, `analysis/`, `indicators/`,
`prediction/`, `ai/`, `data/`, `database/`, `settings/`, `analytics/`, `replay/`)
from the full architecture are not yet created — they'll be added as each phase
lands, per the modular pipeline design.

## 4. Configuring the build

### 4.1 Gradle wrapper
This environment couldn't generate the binary `gradle-wrapper.jar` (no network
access). `gradle/wrapper/gradle-wrapper.properties` is in place and pinned to
Gradle 8.9. To generate the jar, either:

- Open the project folder in **Android Studio** (Koala or newer) — it will offer
  to generate the wrapper automatically, or
- Run once from a machine with Gradle installed:
  ```
  gradle wrapper --gradle-version 8.9
  ```

### 4.2 OpenCV
`app/build.gradle.kts` declares `implementation(libs.opencv)`, but this Maven
coordinate only resolves if you either:
- add the OpenCV Maven repository (`https://maven.opencv.org`) to
  `settings.gradle.kts`, or
- vendor the OpenCV Android SDK as a local module (the more common approach in
  practice — download from https://opencv.org/releases/, import as a module).

Since Phase 1 doesn't use any CV code yet, you can safely comment out the OpenCV
dependency line until Phase 2 if you want a clean build sooner.

### 4.3 KSP/Kotlin version pairing
`gradle/libs.versions.toml` pins KSP to `2.0.20-1.0.24`. KSP releases are versioned
`<kotlin-version>-<ksp-patch>` and change frequently — verify the exact patch
against https://github.com/google/ksp/releases before building; a mismatch here
is a common source of confusing build failures unrelated to this project's code.

### 4.4 No secrets required yet
Phase 1 has no backend/AI calls, so there's nothing to configure in `local.properties`
for this milestone. When Phase 6 (AI backend) lands, the backend URL will be read
from `local.properties` / build config, never a hardcoded key in the APK, per the
security requirements in the original spec.

## 5. How to build

```
./gradlew assembleDebug
```
(after the wrapper jar exists — see 4.1). The debug APK will be at
`app/build/outputs/apk/debug/app-debug.apk`.

**Important:** none of this has been compiled in the environment that generated
it — there is no Android SDK or emulator available there. This has been reviewed
carefully by hand for API correctness (see notes below on things that were
actually caught and fixed this way), but the first `./gradlew assembleDebug` you
run is the first real compiler pass this code has ever had. Expect to fix a
handful of small issues — most likely Compose/Hilt/KSP version-alignment errors
rather than logic errors.

## 6. How to install on a device

```
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Or run directly from Android Studio with a device connected (USB debugging
enabled) or an emulator running **API 29+** with Google Play system image
(MediaProjection works on plain emulator images too, but overlay permission
UX is easiest to test on a real device).

## 7. Permissions required

| Permission | Why |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Draw the floating overlay above other apps |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Run the capture service while another app is in the foreground |
| `POST_NOTIFICATIONS` | Show the required foreground-service notification (Android 13+) |
| `INTERNET`, `ACCESS_NETWORK_STATE` | Reserved for Phase 6 (AI backend) — unused this phase |
| Screen capture itself | Granted at runtime via the system `MediaProjectionManager` dialog — there is no static manifest permission for it |

## 8. Known limitations

- **Not runnable as a real MVP yet** — this is the foundation phase only. There is
  no chart analysis of any kind.
- **Unverified build** — see section 5. Compose/Kotlin/KSP/Hilt version alignment
  in particular is the most likely first failure point; versions were chosen for
  mutual compatibility as of this writing but weren't verified against an actual
  Gradle sync.
- **MediaProjection consent is not persisted.** Every time the user taps "Start
  Analysis" after a full stop, Android will show the screen-capture consent
  dialog again — this is an OS-level restriction, not something the app can
  avoid.
- **Frame-change detection is coarse.** `FrameChangeDetector` does a whole-frame
  32×32 downsampled comparison. It's real, tested logic, but it's a placeholder
  for the chart-region-aware sampling that Phase 2's `ChartDetector` should do
  instead (comparing only the chart region, not the whole screen, will both be
  faster and more accurate).
- **No launcher icon art** — the mipmap/drawable icons are simple flat vector
  shapes so the project builds without needing binary PNG assets, not real
  branding.
- **Overlay manual selection / crop fallback** (spec section 5) isn't built yet —
  planned for Phase 2 alongside automatic chart detection.

## 9. Tests performed

- `FrameChangeDetectorTest` (6 cases): first-frame-always-changed, identical
  frames not flagged, sub-threshold noise not flagged, a large color-block change
  correctly flagged, a resolution change forcing a re-baseline, and `reset()`
  behavior. This is the only class in Phase 1 that's pure Kotlin logic and
  therefore genuinely unit-testable without an Android runtime or a device.
- Everything else in this phase (`ScreenCaptureController`, `ScreenCaptureService`,
  `OverlayService`) is fundamentally Android-framework-dependent (ImageReader,
  MediaProjection, WindowManager) and was reviewed by hand rather than
  build-verified. These are strong candidates for **instrumented tests**
  (`androidx.test`) once you have a device/emulator to run them on — not
  something that can be meaningfully faked with JVM unit tests.

## 10. Remaining work (next phases)

Per the original phase plan:
- **Phase 2** — Vision: chart-region detection, manual crop fallback, candle
  detection/tracking (OpenCV)
- **Phase 3** — Market reconstruction: OHLC, price-axis OCR mapping, timeframe
  detection, candle-close detection
- **Phase 4** — `TechnicalAnalysisEngine`: trend, momentum, EMA/RSI/MACD/ATR/
  Bollinger, support/resistance, candle patterns
- **Phase 5** — `PredictionEngine`: weighted scoring, confidence, NO-TRADE state
- **Phase 6** — AI backend + `AiAnalysisProvider`, structured request/response
- **Phase 7** — Room prediction journal, outcome evaluation, accuracy analytics
- **Phase 8** — Replay/backtest mode, look-ahead-bias prevention tests
- **Phase 9** — Battery/performance tuning, accessibility, polish

Recommended next step: Phase 4 (`TechnicalAnalysisEngine`) is pure Kotlin with no
Android dependency, so it can be built and fully unit-tested (RSI/MACD/EMA/ATR
against synthetic candle data) without needing a device at all — a good next
milestone if you want to keep making verifiable progress before tackling the
harder, device-dependent CV work in Phase 2.
