package com.chartlens.ai.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.AnalysisStateRepository
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.common.CaptureState
import com.chartlens.ai.common.CaptureStateRepository
import com.chartlens.ai.service.ScreenCaptureService
import dagger.hilt.android.AndroidEntryPoint
import kotlin.math.roundToInt
import javax.inject.Inject

/**
 * Draws the floating "ChartLens AI" status card above whatever app is currently in
 * the foreground, using [WindowManager] directly (not an Activity window).
 *
 * Phase 1 scope: shows real capture status only (fps, frame size, uptime) — no
 * bias/confidence/pattern fields, because that layer does not exist yet. Adding
 * those fields is Phase 6's job (AiAnalysisProvider) wired through the same
 * CaptureStateRepository pattern extended with a MarketState/PredictionState flow.
 */
@AndroidEntryPoint
class OverlayService : Service() {

    @Inject lateinit var captureStateRepository: CaptureStateRepository
    @Inject lateinit var analysisStateRepository: AnalysisStateRepository

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission not granted — cannot show floating status")
            stopSelf()
            return
        }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val owner = OverlayLifecycleOwner().also { it.onCreate() }
        lifecycleOwner = owner

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }
        layoutParams = params

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent {
                MaterialTheme {
                    OverlayCard(
                        captureStateRepository = captureStateRepository,
                        analysisStateRepository = analysisStateRepository,
                        onDrag = { dx, dy -> onOverlayDragged(dx, dy) },
                        onStop = { onStopRequested() }
                    )
                }
            }
        }
        composeView = view

        owner.onStart()
        wm.addView(view, params)
    }

    private fun onOverlayDragged(dx: Float, dy: Float) {
        val params = layoutParams ?: return
        val view = composeView ?: return
        params.x += dx.roundToInt()
        params.y += dy.roundToInt()
        try {
            windowManager?.updateViewLayout(view, params)
        } catch (t: Throwable) {
            Log.w(TAG, "updateViewLayout failed", t)
        }
    }

    private fun onStopRequested() {
        ScreenCaptureService.stop(this)
        stopSelf()
    }

    override fun onDestroy() {
        try {
            composeView?.let { windowManager?.removeView(it) }
        } catch (t: Throwable) {
            Log.w(TAG, "removeView failed (already detached?)", t)
        }
        lifecycleOwner?.onDestroy()
        composeView = null
        windowManager = null
        layoutParams = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "OverlayService"

        fun start(context: Context) {
            context.startService(Intent(context, OverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}

@Composable
private fun OverlayCard(
    captureStateRepository: CaptureStateRepository,
    analysisStateRepository: AnalysisStateRepository,
    onDrag: (Float, Float) -> Unit,
    onStop: () -> Unit
) {
    val state by captureStateRepository.state.collectAsState()
    val analysisFrame by analysisStateRepository.latestFrame.collectAsState()
    var expanded by remember { mutableStateOf(true) }
    var opacity by remember { mutableFloatStateOf(0.95f) }

    Surface(
        modifier = Modifier
            .widthIn(min = 200.dp, max = 260.dp)
            .alpha(opacity)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            },
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF121212),
        contentColor = Color.White,
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.widthIn(min = 180.dp)
            ) {
                Text(
                    text = "CHARTLENS AI",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFB0BEC5)
                )
                Row {
                    IconButton(onClick = { expanded = !expanded }, modifier = Modifier.width(28.dp)) {
                        Icon(
                            imageVector = if (expanded) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp,
                            contentDescription = if (expanded) "Collapse" else "Expand",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onStop, modifier = Modifier.width(28.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Stop analysis",
                            tint = Color(0xFFEF5350)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.padding(top = 4.dp))
            StatusLine(state)

            if (state is CaptureState.Capturing) {
                Spacer(modifier = Modifier.padding(top = 6.dp))
                AnalysisStatusLine(analysisFrame)
            }

            if (expanded) {
                Spacer(modifier = Modifier.padding(top = 8.dp))
                Text(
                    text = "Overlay opacity",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF90A4AE)
                )
                Slider(
                    value = opacity,
                    onValueChange = { opacity = it.coerceIn(0.3f, 1f) },
                    valueRange = 0.3f..1f
                )
            }
        }
    }
}

@Composable
private fun AnalysisStatusLine(frame: AnalysisFrame?) {
    if (frame == null) {
        Text(
            text = "Analyzing…",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF90A4AE)
        )
        return
    }

    val qualityColor = when (frame.dataQuality) {
        DataQuality.GOOD -> Color(0xFF26A69A)
        DataQuality.FAIR -> Color(0xFFFFA726)
        DataQuality.POOR -> Color(0xFFFF7043)
        DataQuality.INVALID -> Color(0xFFEF5350)
    }

    Column {
        if (frame.chartRegion == null || !frame.chartRegion.isUsable()) {
            Text(
                text = "No chart detected — try Manual Chart Selection",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFF7043)
            )
        } else {
            Text(
                text = "${frame.closedCandleCount} candles · quality ${frame.dataQuality.name}",
                style = MaterialTheme.typography.bodySmall,
                color = qualityColor
            )
        }
    }
}

@Composable
private fun StatusLine(state: CaptureState) {
    val (label, detail, color) = when (state) {
        is CaptureState.Idle -> Triple("IDLE", "Not analyzing", Color(0xFF90A4AE))
        is CaptureState.AwaitingPermission -> Triple("WAITING", "Awaiting permission", Color(0xFFFFA726))
        is CaptureState.Capturing -> Triple(
            "CAPTURING",
            "${state.frameWidth}×${state.frameHeight} · ${state.analyzedFrameCount} analyzed",
            Color(0xFF26A69A)
        )
        is CaptureState.Stopped -> Triple("STOPPED", "Capture ended", Color(0xFF90A4AE))
        is CaptureState.Error -> Triple("ERROR", state.message, Color(0xFFEF5350))
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(
            modifier = Modifier
                .padding(end = 6.dp)
                .size(8.dp)
        ) {
            drawCircle(color = color, radius = size.minDimension / 2)
        }
        Column {
            Text(text = label, style = MaterialTheme.typography.labelLarge, color = color)
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = Color(0xFFCFD8DC))
        }
    }
}
