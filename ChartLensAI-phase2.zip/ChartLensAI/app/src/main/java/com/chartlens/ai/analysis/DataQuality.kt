package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle

enum class DataQuality { GOOD, FAIR, POOR, INVALID }

/**
 * Phase 2 partial implementation of the spec's data-quality system (§19). Only
 * factors in what actually exists at this phase — chart-region detection
 * confidence and candle-detection confidence/count. OCR confidence, timeframe
 * confidence, and price-mapping confidence (the other listed factors) don't
 * exist until Phase 3 and will be folded into this calculation then, not
 * approximated here.
 */
object DataQualityCalculator {

    fun calculate(chartRegionConfidence: Float, candles: List<Candle>): DataQuality {
        if (candles.isEmpty()) return DataQuality.INVALID

        val averageCandleConfidence = candles.map { it.confidence }.average().toFloat()
        val closedCandleCount = candles.count { !it.isForming }
        val combinedConfidence = 0.5f * chartRegionConfidence + 0.5f * averageCandleConfidence

        return when {
            combinedConfidence >= 0.75f && closedCandleCount >= 20 -> DataQuality.GOOD
            combinedConfidence >= 0.55f && closedCandleCount >= 8 -> DataQuality.FAIR
            combinedConfidence > 0f -> DataQuality.POOR
            else -> DataQuality.INVALID
        }
    }
}
