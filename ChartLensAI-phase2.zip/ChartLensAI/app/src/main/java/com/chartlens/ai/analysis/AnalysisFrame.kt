package com.chartlens.ai.analysis

import com.chartlens.ai.candle.Candle
import com.chartlens.ai.candle.CandlePatternMatch
import com.chartlens.ai.cv.ChartRegion

/**
 * Everything Phase 2 knows about a single analyzed frame. Deliberately has no
 * bias/prediction/confidence-to-trade fields — those don't exist until Phase 5.
 */
data class AnalysisFrame(
    val timestampMillis: Long,
    val chartRegion: ChartRegion?,
    val candles: List<Candle>,
    val patternMatches: List<CandlePatternMatch>,
    val dataQuality: DataQuality
) {
    val closedCandleCount: Int get() = candles.count { !it.isForming }
}
