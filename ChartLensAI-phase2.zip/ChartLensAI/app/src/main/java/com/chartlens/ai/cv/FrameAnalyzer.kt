package com.chartlens.ai.cv

import android.graphics.Bitmap
import com.chartlens.ai.analysis.AnalysisFrame
import com.chartlens.ai.analysis.DataQuality
import com.chartlens.ai.analysis.DataQualityCalculator
import com.chartlens.ai.candle.CandleDetector
import com.chartlens.ai.candle.CandlePatternDetector
import com.chartlens.ai.common.PixelBuffer

/**
 * The only class in the CV pipeline that touches `android.graphics.Bitmap` —
 * everything downstream of this (ChartDetector, CandleDetector,
 * CandlePatternDetector) operates on the pure-Kotlin [PixelBuffer] and is unit
 * tested. This class itself is reviewed by hand, same as the rest of the
 * Bitmap/MediaProjection boundary in Phase 1.
 *
 * Performance note: a full-frame [ChartDetector] pass touches every pixel of the
 * captured screen, which is real cost worth avoiding on every single analyzed
 * frame — the chart's on-screen position rarely moves between frames. This class
 * caches the last-detected region and only re-runs full detection every
 * [rediscoverEveryNFrames] frames (or immediately, if a manual region is
 * provided/changes). This is a real perf decision, not yet tuned against actual
 * device measurements — see README "Known limitations" for Phase 9 follow-up.
 */
class FrameAnalyzer(
    private val chartDetector: ChartDetector = ChartDetector(),
    private val candleDetector: CandleDetector = CandleDetector(),
    private val patternDetector: CandlePatternDetector = CandlePatternDetector(),
    private val rediscoverEveryNFrames: Int = 20
) {
    private var cachedAutoRegion: ChartRegion? = null
    private var framesSinceRediscovery = 0

    fun analyze(bitmap: Bitmap, manualRegion: ChartRegion?, timestampMillis: Long): AnalysisFrame {
        val fullBuffer = bitmap.toPixelBuffer()

        val region = manualRegion ?: resolveAutoRegion(fullBuffer)

        if (region == null || !region.isUsable()) {
            return AnalysisFrame(
                timestampMillis = timestampMillis,
                chartRegion = region,
                candles = emptyList(),
                patternMatches = emptyList(),
                dataQuality = DataQuality.INVALID
            )
        }

        val cropped = fullBuffer.crop(
            left = region.left.coerceIn(0, fullBuffer.width),
            top = region.top.coerceIn(0, fullBuffer.height),
            right = region.right.coerceIn(0, fullBuffer.width),
            bottom = region.bottom.coerceIn(0, fullBuffer.height)
        )

        val candles = candleDetector.detect(cropped)
        val patterns = patternDetector.detect(candles)
        val quality = DataQualityCalculator.calculate(region.confidence, candles)

        return AnalysisFrame(
            timestampMillis = timestampMillis,
            chartRegion = region,
            candles = candles,
            patternMatches = patterns,
            dataQuality = quality
        )
    }

    /** Call when the user changes/clears the manual selection, to force a fresh auto-detect next time it's needed. */
    fun invalidateCache() {
        cachedAutoRegion = null
        framesSinceRediscovery = 0
    }

    private fun resolveAutoRegion(fullBuffer: PixelBuffer): ChartRegion? {
        val shouldRediscover = cachedAutoRegion == null || framesSinceRediscovery >= rediscoverEveryNFrames
        return if (shouldRediscover) {
            framesSinceRediscovery = 0
            chartDetector.detect(fullBuffer).also { cachedAutoRegion = it }
        } else {
            framesSinceRediscovery++
            cachedAutoRegion
        }
    }

    private fun Bitmap.toPixelBuffer(): PixelBuffer {
        val pixels = IntArray(width * height)
        getPixels(pixels, 0, width, 0, 0, width, height)
        return PixelBuffer(width, height, pixels)
    }
}
